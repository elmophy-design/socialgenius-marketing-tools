document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const buildBtn = document.getElementById('build-btn');
    const regenerateBtn = document.getElementById('regenerate-btn');
    const exportBtn = document.getElementById('export-btn');
    const saveBtn = document.getElementById('save-btn');
    const templateBtns = document.querySelectorAll('.template-btn');
    const resultsPlaceholder = document.getElementById('results-placeholder');
    const resultsContent = document.getElementById('results-content');
    const loadingIndicator = document.getElementById('loading-indicator');

    // Form Elements
    const businessNameInput = document.getElementById('business-name');
    const businessTypeSelect = document.getElementById('business-type');
    const targetAudienceInput = document.getElementById('target-audience');
    const primaryOfferInput = document.getElementById('primary-offer');
    const funnelGoalSelect = document.getElementById('funnel-goal');
    const budgetSelect = document.getElementById('budget');

    // Result Elements
    const funnelTitle = document.getElementById('funnel-title');
    const funnelType = document.getElementById('funnel-type');
    const funnelAudience = document.getElementById('funnel-audience');
    const awarenessContent = document.getElementById('awareness-content');
    const interestContent = document.getElementById('interest-content');
    const decisionContent = document.getElementById('decision-content');
    const actionContent = document.getElementById('action-content');
    const totalAudience = document.getElementById('total-audience');
    const conversionRate = document.getElementById('conversion-rate');
    const costPerLead = document.getElementById('cost-per-lead');
    const roi = document.getElementById('roi');
    const toolsGrid = document.getElementById('tools-grid');

    // Create tools links container
    const toolsContainer = document.createElement('div');
    toolsContainer.className = 'tools-links-container';
    toolsContainer.innerHTML = `
        <div class="tools-header">
            <h3>🚀 More Content Tools</h3>
            <p>Enhance your content creation workflow</p>
        </div>
        <div class="tools-grid">
            <a href="../social-media-generator/index.html" class="tool-link" data-tool="social-media">
                <div class="tool-icon">📱</div>
                <div class="tool-content">
                    <h4>AI Social Media Generator</h4>
                    <p>Create engaging social media posts and captions</p>
                </div>
            </a>
            
            <a href="../headline-Analyzer/index.html" class="tool-link" data-tool="ai-writer">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Headline Analyzer</h4>
                    <p>Generate full articles and blog posts</p>
                </div>
            </a>
            
            <a href="../seo-meta-generator/index.html" class="tool-link" data-tool="seo-analyzer">
                <div class="tool-icon">🔍</div>
                <div class="tool-content">
                    <h4>SEO Meta Generator</h4>
                    <p>Optimize content for search engines</p>
                </div>
            </a>
            
            <a href="../email-subject-line-tester/index.html" class="tool-link" data-tool="video-generator">
                <div class="tool-icon">✉️</div>
                <div class="tool-content">
                    <h4>Email Subject Line Tester</h4>
                    <p>analyze and scores subject effectiveness.</p>
                </div>
            </a>
            
            <a href="../Ad-Copy-Generator/index.html" class="tool-link" data-tool="content-planner">
                <div class="tool-icon">🎯</div>
                <div class="tool-content">
                    <h4>Ad Copy Generator</h4>
                    <p>create engaging, high-converting advertisements automatically.</p>
                </div>
            </a>
        </div>
    `;

    // Insert tools container after the main content
    const mainContainer = document.querySelector('.container') || document.querySelector('main');
    if (mainContainer) {
        mainContainer.appendChild(toolsContainer);
    }
    // Funnel configurations
    const funnelTemplates = {
        ecommerce: {
            name: "E-commerce Sales Funnel",
            stages: {
                awareness: {
                    content: [
                        {
                            type: "Social Media",
                            title: "Problem-Awareness Posts",
                            description: "Content highlighting pain points your product solves"
                        },
                        {
                            type: "Content",
                            title: "Educational Blog Posts",
                            description: "How-to guides and problem-solving articles"
                        },
                        {
                            type: "Ads",
                            title: "Interest-Based Targeting",
                            description: "Facebook/Instagram ads targeting user interests"
                        }
                    ]
                },
                interest: {
                    content: [
                        {
                            type: "Lead Magnet",
                            title: "Discount Code or Free Shipping",
                            description: "Offer first-time purchase incentives"
                        },
                        {
                            type: "Email",
                            title: "Welcome Sequence",
                            description: "Introduce your brand and products"
                        },
                        {
                            type: "Retargeting",
                            title: "Product Showcase Ads",
                            description: "Show products to website visitors"
                        }
                    ]
                },
                decision: {
                    content: [
                        {
                            type: "Social Proof",
                            title: "Customer Reviews & Testimonials",
                            description: "Showcase happy customer experiences"
                        },
                        {
                            type: "Urgency",
                            title: "Limited Time Offers",
                            description: "Create scarcity to drive purchases"
                        },
                        {
                            type: "Comparison",
                            title: "Product Benefits Highlight",
                            description: "Show why your product is the best choice"
                        }
                    ]
                },
                action: {
                    content: [
                        {
                            type: "Checkout",
                            title: "Streamlined Purchase Process",
                            description: "One-click upsells and cross-sells"
                        },
                        {
                            type: "Confirmation",
                            title: "Order Confirmation & Tracking",
                            description: "Keep customers informed post-purchase"
                        },
                        {
                            type: "Retention",
                            title: "Loyalty Program Invitation",
                            description: "Encourage repeat purchases"
                        }
                    ]
                }
            }
        },
        saas: {
            name: "SaaS Conversion Funnel",
            stages: {
                awareness: {
                    content: [
                        {
                            type: "Content",
                            title: "Problem-Solving Blog Content",
                            description: "Address specific pain points your SaaS solves"
                        },
                        {
                            type: "SEO",
                            title: "Keyword-Optimized Landing Pages",
                            description: "Target relevant search queries"
                        },
                        {
                            type: "Webinars",
                            title: "Educational Webinars",
                            description: "Teach solutions to common problems"
                        }
                    ]
                },
                interest: {
                    content: [
                        {
                            type: "Trial",
                            title: "Free Trial Offer",
                            description: "Let users experience your product"
                        },
                        {
                            type: "Demo",
                            title: "Product Demo Videos",
                            description: "Showcase key features and benefits"
                        },
                        {
                            type: "Case Studies",
                            title: "Success Stories",
                            description: "Show how others achieved results"
                        }
                    ]
                },
                decision: {
                    content: [
                        {
                            type: "Pricing",
                            title: "Clear Pricing Page",
                            description: "Transparent pricing with value highlights"
                        },
                        {
                            type: "Comparison",
                            title: "Feature Comparison",
                            description: "Show advantages over competitors"
                        },
                        {
                            type: "Social Proof",
                            title: "Customer Testimonials",
                            description: "Build trust with real user stories"
                        }
                    ]
                },
                action: {
                    content: [
                        {
                            type: "Onboarding",
                            title: "Welcome Sequence",
                            description: "Guide users through setup process"
                        },
                        {
                            type: "Support",
                            title: "Dedicated Support",
                            description: "Ensure successful implementation"
                        },
                        {
                            type: "Upsell",
                            title: "Premium Features Highlight",
                            description: "Show value of upgraded plans"
                        }
                    ]
                }
            }
        },
        service: {
            name: "Service Business Funnel",
            stages: {
                awareness: {
                    content: [
                        {
                            type: "Networking",
                            title: "LinkedIn Outreach",
                            description: "Connect with potential clients"
                        },
                        {
                            type: "Content",
                            title: "Expert Articles",
                            description: "Share industry insights and expertise"
                        },
                        {
                            type: "Referrals",
                            title: "Client Referral Program",
                            description: "Leverage existing relationships"
                        }
                    ]
                },
                interest: {
                    content: [
                        {
                            type: "Consultation",
                            title: "Free Discovery Call",
                            description: "Offer value before asking for commitment"
                        },
                        {
                            type: "Portfolio",
                            title: "Case Study Showcase",
                            description: "Demonstrate past success stories"
                        },
                        {
                            type: "Lead Magnet",
                            title: "Free Audit/Assessment",
                            description: "Provide immediate value"
                        }
                    ]
                },
                decision: {
                    content: [
                        {
                            type: "Proposal",
                            title: "Detailed Service Proposal",
                            description: "Clear scope, deliverables, and pricing"
                        },
                        {
                            type: "Testimonials",
                            title: "Client Success Stories",
                            description: "Build credibility and trust"
                        },
                        {
                            type: "Guarantee",
                            title: "Risk Reversal Offer",
                            description: "Reduce perceived risk for clients"
                        }
                    ]
                },
                action: {
                    content: [
                        {
                            type: "Contract",
                            title: "Clear Service Agreement",
                            description: "Professional onboarding process"
                        },
                        {
                            type: "Payment",
                            title: "Flexible Payment Options",
                            description: "Make it easy to get started"
                        },
                        {
                            type: "Delivery",
                            title: "Project Kickoff Process",
                            description: "Set expectations and timeline"
                        }
                    ]
                }
            }
        }
    };

    // Tool recommendations
    const toolRecommendations = {
        awareness: [
            { name: "Facebook Ads", icon: "📱", purpose: "Targeted audience reach" },
            { name: "Google Ads", icon: "🔍", purpose: "Search intent targeting" },
            { name: "LinkedIn", icon: "💼", purpose: "B2B audience engagement" },
            { name: "Instagram", icon: "📸", purpose: "Visual content marketing" }
        ],
        interest: [
            { name: "Mailchimp", icon: "✉️", purpose: "Email marketing automation" },
            { name: "HubSpot", icon: "🔄", purpose: "CRM and lead nurturing" },
            { name: "ActiveCampaign", icon: "🎯", purpose: "Advanced automation" },
            { name: "ConvertKit", icon: "📊", purpose: "Creator-focused email" }
        ],
        decision: [
            { name: "Calendly", icon: "📅", purpose: "Meeting scheduling" },
            { name: "Typeform", icon: "📝", purpose: "Lead qualification forms" },
            { name: "Hotjar", icon: "🔥", purpose: "Website behavior analytics" },
            { name: "Intercom", icon: "💬", purpose: "Live chat and support" }
        ],
        action: [
            { name: "Stripe", icon: "💳", purpose: "Payment processing" },
            { name: "PayPal", icon: "💰", purpose: "Alternative payments" },
            { name: "Zapier", icon: "⚡", purpose: "Workflow automation" },
            { name: "Slack", icon: "💻", purpose: "Team communication" }
        ]
    };

    // Event Listeners
    buildBtn.addEventListener('click', buildFunnel);
    regenerateBtn.addEventListener('click', buildFunnel);
    exportBtn.addEventListener('click', exportFunnel);
    saveBtn.addEventListener('click', saveFunnel);

    templateBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const template = this.dataset.template;
            useTemplate(template);
        });
    });

    // Build funnel function
    function buildFunnel() {
        const businessName = businessNameInput.value.trim();
        const targetAudience = targetAudienceInput.value.trim();
        const primaryOffer = primaryOfferInput.value.trim();

        if (!businessName || !targetAudience || !primaryOffer) {
            alert('Please fill in all required fields: Business Name, Target Audience, and Primary Offer');
            return;
        }

        setLoadingState(true);

        // Simulate API call delay
        setTimeout(() => {
            try {
                const funnel = generateFunnel();
                displayFunnel(funnel);
                setLoadingState(false);
            } catch (error) {
                console.error('Error building funnel:', error);
                alert('Error building marketing funnel. Please try again.');
                setLoadingState(false);
            }
        }, 2000);
    }

    // Generate funnel based on inputs
    function generateFunnel() {
        const businessType = businessTypeSelect.value;
        const funnelGoal = funnelGoalSelect.value;
        const budget = parseInt(budgetSelect.value);
        const businessName = businessNameInput.value;
        const targetAudience = targetAudienceInput.value;

        // Get template based on business type
        const template = funnelTemplates[businessType] || funnelTemplates.service;
        
        // Calculate metrics based on inputs
        const metrics = calculateFunnelMetrics(businessType, budget, funnelGoal);

        return {
            name: `${businessName} ${template.name}`,
            type: getFunnelTypeName(funnelGoal),
            audience: targetAudience,
            template: template,
            metrics: metrics,
            tools: toolRecommendations
        };
    }

    // Calculate funnel metrics
    function calculateFunnelMetrics(businessType, budget, goal) {
        const baseMetrics = {
            ecommerce: { audience: 10000, conversion: 3.5, cpl: 8, roi: 320 },
            saas: { audience: 5000, conversion: 7.2, cpl: 22, roi: 450 },
            service: { audience: 2000, conversion: 12.5, cpl: 45, roi: 280 },
            agency: { audience: 1500, conversion: 15.8, cpl: 65, roi: 380 },
            coach: { audience: 3000, conversion: 8.5, cpl: 35, roi: 420 },
            creator: { audience: 8000, conversion: 2.8, cpl: 12, roi: 190 }
        };

        const base = baseMetrics[businessType] || baseMetrics.service;
        
        // Adjust based on budget
        const budgetMultiplier = budget / 1000;
        const audience = Math.round(base.audience * budgetMultiplier);
        const conversion = base.conversion;
        const cpl = Math.round(base.cpl / budgetMultiplier);
        const roi = Math.round(base.roi * (1 + (budgetMultiplier * 0.1)));

        return {
            totalAudience: audience.toLocaleString(),
            conversionRate: conversion + '%',
            costPerLead: '$' + cpl.toFixed(2),
            roi: roi + '%'
        };
    }

    // Get funnel type display name
    function getFunnelTypeName(goal) {
        const names = {
            'lead-generation': 'Lead Generation',
            'product-sales': 'Product Sales',
            'course-enrollment': 'Course Enrollment',
            'app-signups': 'App Sign-ups',
            'book-calls': 'Discovery Calls'
        };
        return names[goal] || goal;
    }

    // Display funnel
    function displayFunnel(funnel) {
        // Update header
        funnelTitle.textContent = funnel.name;
        funnelType.textContent = funnel.type;
        funnelAudience.textContent = funnel.audience;

        // Update stage content
        updateStageContent('awareness', funnel.template.stages.awareness.content);
        updateStageContent('interest', funnel.template.stages.interest.content);
        updateStageContent('decision', funnel.template.stages.decision.content);
        updateStageContent('action', funnel.template.stages.action.content);

        // Update metrics
        totalAudience.textContent = funnel.metrics.totalAudience;
        conversionRate.textContent = funnel.metrics.conversionRate;
        costPerLead.textContent = funnel.metrics.costPerLead;
        roi.textContent = funnel.metrics.roi;

        // Update tools
        updateTools(funnel.tools);

        // Show results
        resultsPlaceholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');
    }

    // Update stage content
    function updateStageContent(stage, content) {
        const container = document.getElementById(`${stage}-content`);
        container.innerHTML = '';

        content.forEach(item => {
            const card = document.createElement('div');
            card.className = 'content-card';
            card.innerHTML = `
                <div class="content-type">${item.type}</div>
                <div class="content-title">${item.title}</div>
                <div class="content-description">${item.description}</div>
            `;
            container.appendChild(card);
        });
    }

    // Update tools
    function updateTools(tools) {
        toolsGrid.innerHTML = '';

        // Combine all tools from different stages
        const allTools = [
            ...tools.awareness,
            ...tools.interest,
            ...tools.decision,
            ...tools.action
        ];

        // Remove duplicates
        const uniqueTools = allTools.filter((tool, index, self) =>
            index === self.findIndex(t => t.name === tool.name)
        );

        // Display tools (limit to 8)
        uniqueTools.slice(0, 8).forEach(tool => {
            const card = document.createElement('div');
            card.className = 'tool-card';
            card.innerHTML = `
                <div class="tool-icon">${tool.icon}</div>
                <div class="tool-name">${tool.name}</div>
                <div class="tool-purpose">${tool.purpose}</div>
            `;
            toolsGrid.appendChild(card);
        });
    }

    // Use template
    function useTemplate(templateType) {
        const templateMap = {
            'ecommerce': 'ecommerce',
            'saas': 'saas',
            'course': 'service'
        };

        const businessType = templateMap[templateType] || 'service';
        businessTypeSelect.value = businessType;
        
        // Set common values for the template
        switch(templateType) {
            case 'ecommerce':
                targetAudienceInput.value = 'Online shoppers interested in [your product category]';
                primaryOfferInput.value = 'Your main product or collection';
                funnelGoalSelect.value = 'product-sales';
                break;
            case 'saas':
                targetAudienceInput.value = 'Business professionals needing [your solution]';
                primaryOfferInput.value = 'Software subscription or service';
                funnelGoalSelect.value = 'app-signups';
                break;
            case 'course':
                targetAudienceInput.value = 'Students and professionals wanting to learn [your topic]';
                primaryOfferInput.value = 'Online course or coaching program';
                funnelGoalSelect.value = 'course-enrollment';
                break;
        }

        showNotification(`Template applied! Fill in your specific details and click "Build My Funnel"`);
    }

    // Export funnel
    function exportFunnel() {
        const funnelData = {
            name: funnelTitle.textContent,
            type: funnelType.textContent,
            audience: funnelAudience.textContent,
            metrics: {
                totalAudience: totalAudience.textContent,
                conversionRate: conversionRate.textContent,
                costPerLead: costPerLead.textContent,
                roi: roi.textContent
            }
        };

        const funnelText = `
Marketing Funnel Plan
=====================

Funnel: ${funnelData.name}
Type: ${funnelData.type}
Target Audience: ${funnelData.audience}

Performance Metrics:
- Total Audience: ${funnelData.metrics.totalAudience}
- Conversion Rate: ${funnelData.metrics.conversionRate}
- Cost Per Lead: ${funnelData.metrics.costPerLead}
- Projected ROI: ${funnelData.metrics.roi}

Stage-by-Stage Plan:
1. AWARENESS: Attract potential customers
2. INTEREST: Build relationships and trust
3. DECISION: Convert leads to customers
4. ACTION: Deliver value and retain customers

Next Steps:
1. Implement the content suggestions for each stage
2. Set up tracking for key metrics
3. Test and optimize continuously
4. Scale successful strategies
        `.trim();

        copyToClipboard(funnelText);
        showNotification('Funnel plan copied to clipboard!');
    }

    // Save funnel (simulated)
    function saveFunnel() {
        showNotification('Funnel saved! (This is a demo)');
    }

    // Set loading state
    function setLoadingState(isLoading) {
        if (isLoading) {
            buildBtn.disabled = true;
            resultsPlaceholder.classList.add('hidden');
            resultsContent.classList.add('hidden');
            loadingIndicator.classList.remove('hidden');
            
            const btnText = buildBtn.querySelector('.btn-text');
            const btnLoading = buildBtn.querySelector('.btn-loading');
            btnText.classList.add('hidden');
            btnLoading.classList.remove('hidden');
        } else {
            buildBtn.disabled = false;
            loadingIndicator.classList.add('hidden');
            
            const btnText = buildBtn.querySelector('.btn-text');
            const btnLoading = buildBtn.querySelector('.btn-loading');
            btnText.classList.remove('hidden');
            btnLoading.classList.add('hidden');
        }
    }

    // Copy text to clipboard
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copied to clipboard!');
        }).catch(err => {
            console.error('Failed to copy: ', err);
            showNotification('Failed to copy to clipboard');
        });
    }

    // Show notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            font-weight: 600;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }

    // Initialize with demo data
    function initializeDemo() {
        businessNameInput.value = 'Growth Marketing Co';
        targetAudienceInput.value = 'Small business owners looking to grow online';
        primaryOfferInput.value = 'Marketing strategy consultation';
    }

    // Initialize the demo
    initializeDemo();
});
// Add CSS for tools links
const toolsStyles = document.createElement('style');
toolsStyles.textContent = `
    .tools-links-container {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 2px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    
    .tools-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    
    .tools-header h3 {
        color: #1e293b;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: 700;
    }
    
    .tools-header p {
        color: #64748b;
        font-size: 0.9rem;
    }
    
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .tool-link {
        background: white;
        border: 2px solid #f1f5f9;
        border-radius: 12px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        text-decoration: none;
        transition: all 0.3s ease;
        color: inherit;
    }
    
    .tool-link:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
        text-decoration: none;
        color: inherit;
    }
    
    .tool-icon {
        font-size: 2rem;
        flex-shrink: 0;
    }
    
    .tool-content h4 {
        color: #1e293b;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        font-weight: 600;
    }
    
    .tool-content p {
        color: #64748b;
        font-size: 0.8rem;
        margin: 0;
        line-height: 1.4;
    }
`;
document.head.appendChild(toolsStyles);