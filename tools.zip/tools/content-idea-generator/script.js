document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const generateBtn = document.getElementById('generate-btn');
    const regenerateBtn = document.getElementById('regenerate-btn');
    const saveIdeasBtn = document.getElementById('save-ideas-btn');
    const calendarToggle = document.getElementById('calendar-toggle');
    const resultsPlaceholder = document.getElementById('results-placeholder');
    const resultsContent = document.getElementById('results-content');
    const loadingIndicator = document.getElementById('loading-indicator');
    const contentCalendar = document.getElementById('content-calendar');
    const tabButtons = document.querySelectorAll('.tab-btn');

    // Form Elements
    const nicheInput = document.getElementById('niche');
    const targetAudienceInput = document.getElementById('target-audience');
    const contentTypeSelect = document.getElementById('content-type');
    const contentFormatSelect = document.getElementById('content-format');
    const toneSelect = document.getElementById('tone');
    const ideaCountSelect = document.getElementById('idea-count');
    const keywordsInput = document.getElementById('keywords');
    const goalSelect = document.getElementById('goal');

    // Result Elements
    const resultsBadge = document.getElementById('results-badge');
    const resultsCount = document.getElementById('results-count');
    const ideasGrid = document.getElementById('ideas-grid');
    const calendarGrid = document.getElementById('calendar-grid');

    // Create tools links container
    const toolsContainer = document.createElement('div');
    toolsContainer.className = 'tools-links-container';
    toolsContainer.innerHTML = `
        <div class="tools-header">
            <h3>🚀 More Content Tools</h3>
            <p>Enhance your content creation workflow</p>
        </div>
        <div class="tools-grid">
            <a href="../social-media-generator/index.html" class="tool-link" data-tool="social-media">
                <div class="tool-icon">📱</div>
                <div class="tool-content">
                    <h4>AI Social Media Generator</h4>
                    <p>Create engaging social media posts and captions</p>
                </div>
            </a>
            
            <a href="../headline-Analyzer/index.html" class="tool-link" data-tool="ai-writer">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Headline Analyzer</h4>
                    <p>Generate full articles and blog posts</p>
                </div>
            </a>
            
            <a href="../seo-meta-generator/index.html" class="tool-link" data-tool="seo-analyzer">
                <div class="tool-icon">🔍</div>
                <div class="tool-content">
                    <h4>SEO Meta Generator</h4>
                    <p>Optimize content for search engines</p>
                </div>
            </a>
            
            <a href="../email-subject-line-tester/index.html" class="tool-link" data-tool="video-generator">
                <div class="tool-icon">✉️</div>
                <div class="tool-content">
                    <h4>Email Subject Line Tester</h4>
                    <p>Create videos from text automatically</p>
                </div>
            </a>
            
            <a href="../Ad-Copy-Generator/index.html" class="tool-link" data-tool="content-planner">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Ad Copy Generator</h4>
                    <p>Plan and organize your content calendar</p>
                </div>
            </a>
        </div>
    `;

    // Insert tools container UNDER the content ideas (after results content)
    const mainContainer = document.querySelector('.container') || document.querySelector('main');
    if (mainContainer) {
        // Insert tools after the results content section
        mainContainer.appendChild(toolsContainer);
    }

    // [Rest of your existing code remains exactly the same...]
    // Content type configurations
    const contentTypeConfigs = {
        blog: {
            name: 'Blog Posts',
            formats: ['how-to', 'list', 'tips', 'case-study', 'review', 'trends'],
            maxLength: 120
        },
        'social-media': {
            name: 'Social Media Posts',
            formats: ['tips', 'list', 'how-to', 'engagement'],
            maxLength: 280
        },
        video: {
            name: 'Video Content',
            formats: ['tutorial', 'review', 'entertainment', 'educational'],
            maxLength: 100
        },
        podcast: {
            name: 'Podcast Episodes',
            formats: ['interview', 'discussion', 'solo', 'qa'],
            maxLength: 80
        },
        email: {
            name: 'Email Newsletter',
            formats: ['update', 'tips', 'news', 'promotion'],
            maxLength: 100
        },
        ebook: {
            name: 'E-book/Guide',
            formats: ['comprehensive', 'beginner', 'advanced', 'specialized'],
            maxLength: 60
        }
    };

    // Content format templates
    const formatTemplates = {
        'how-to': {
            templates: [
                "How to [Achieve Goal] in [Timeframe]",
                "Step-by-Step Guide to [Action]",
                "The Complete Beginner's Guide to [Topic]",
                "How We [Achieved Result] in [Timeframe]"
            ],
            descriptions: [
                "A comprehensive guide that walks readers through the process of achieving specific goals.",
                "Detailed instructions and best practices for completing a particular task or project."
            ]
        },
        'list': {
            templates: [
                "[Number] [Topic] Tips That Actually Work",
                "[Number] Common Mistakes to Avoid When [Action]",
                "[Number] Best [Tools/Resources] for [Audience]",
                "[Number] Signs You're [Situation]"
            ],
            descriptions: [
                "Actionable tips and insights presented in an easy-to-digest list format.",
                "Common pitfalls and how to avoid them in your specific niche or industry."
            ]
        },
        'tips': {
            templates: [
                "[Number] Proven Strategies for [Goal]",
                "Expert Tips for Better [Result]",
                "[Number] Little-Known [Topic] Secrets",
                "Quick Wins for [Improvement]"
            ],
            descriptions: [
                "Practical advice and strategies that deliver immediate results.",
                "Expert insights and proven methods for achieving specific outcomes."
            ]
        },
        'case-study': {
            templates: [
                "Case Study: How [Company] Achieved [Result]",
                "Real Results: [Metric] Improvement in [Timeframe]",
                "Success Story: [Client]'s Journey to [Achievement]",
                "Behind the Scenes: How We [Accomplishment]"
            ],
            descriptions: [
                "Detailed analysis of real-world success stories and their key takeaways.",
                "In-depth look at strategies that delivered measurable results for businesses."
            ]
        }
    };

    // Tone templates
    const toneTemplates = {
        professional: {
            adjectives: ['comprehensive', 'strategic', 'professional', 'effective', 'proven'],
            phrases: ['industry best practices', 'data-driven approach', 'expert insights']
        },
        casual: {
            adjectives: ['awesome', 'simple', 'easy', 'fun', 'practical'],
            phrases: ['you\'ll love this', 'game-changing tips', 'super helpful']
        },
        authoritative: {
            adjectives: ['definitive', 'comprehensive', 'expert', 'master', 'ultimate'],
            phrases: ['must-know strategies', 'industry secrets', 'professional guidance']
        },
        humorous: {
            adjectives: ['hilarious', 'entertaining', 'funny', 'witty', 'amusing'],
            phrases: ['you won\'t believe this', 'laugh while you learn', 'entertaining insights']
        },
        inspirational: {
            adjectives: ['transformative', 'life-changing', 'empowering', 'motivational', 'inspiring'],
            phrases: ['unlock your potential', 'transform your approach', 'achieve amazing results']
        }
    };

    // Goal templates
    const goalTemplates = {
        education: {
            focus: ['teach', 'educate', 'explain', 'demonstrate', 'guide'],
            outcomes: ['understanding', 'knowledge', 'skills', 'expertise']
        },
        entertainment: {
            focus: ['entertain', 'engage', 'amuse', 'delight', 'captivate'],
            outcomes: ['enjoyment', 'engagement', 'entertainment', 'fun']
        },
        conversion: {
            focus: ['convert', 'persuade', 'convince', 'motivate', 'inspire'],
            outcomes: ['action', 'conversion', 'purchase', 'sign-up']
        },
        awareness: {
            focus: ['introduce', 'showcase', 'highlight', 'feature', 'present'],
            outcomes: ['awareness', 'recognition', 'visibility', 'exposure']
        },
        engagement: {
            focus: ['engage', 'interact', 'connect', 'involve', 'participate'],
            outcomes: ['engagement', 'interaction', 'discussion', 'community']
        }
    };

    // Event Listeners
    generateBtn.addEventListener('click', generateContentIdeas);
    regenerateBtn.addEventListener('click', generateContentIdeas);
    saveIdeasBtn.addEventListener('click', saveAllIdeas);
    calendarToggle.addEventListener('click', toggleCalendar);

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            updateExamples(this.dataset.type);
        });
    });

    // Generate content ideas function - UPDATED FOR REAL-TIME DISPLAY
    async function generateContentIdeas() {
        const niche = nicheInput.value.trim();
        const targetAudience = targetAudienceInput.value.trim();

        if (!niche) {
            alert('Please enter your niche or industry');
            return;
        }

        if (!targetAudience) {
            alert('Please describe your target audience');
            return;
        }

        setLoadingState(true);
        
        // Clear previous results and show container
        ideasGrid.innerHTML = '';
        resultsPlaceholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');
        
        // Update results header immediately
        const config = contentTypeConfigs[contentTypeSelect.value];
        resultsBadge.textContent = config.name;
        resultsCount.textContent = `Generating ${ideaCountSelect.value} ideas...`;

        try {
            const ideas = await generateIdeasWithProgress();
            displayFinalResults(ideas);
            setLoadingState(false);
        } catch (error) {
            console.error('Error generating ideas:', error);
            alert('Error generating content ideas. Please try again.');
            setLoadingState(false);
        }
    }

    // Generate ideas with real-time progress - NEW FUNCTION
    async function generateIdeasWithProgress() {
        const ideaCount = parseInt(ideaCountSelect.value);
        const ideas = [];
        
        for (let i = 0; i < ideaCount; i++) {
            // Simulate AI thinking time with variable delay
            const thinkingTime = 300 + Math.random() * 700;
            await new Promise(resolve => setTimeout(resolve, thinkingTime));
            
            // Generate and display idea immediately
            const idea = generateSingleIdea(i);
            ideas.push(idea);
            
            // Display idea as it's generated
            displayIdeaInRealTime(idea, i + 1, ideaCount);
            
            // Update progress counter
            resultsCount.textContent = `Generated ${i + 1} of ${ideaCount} ideas...`;
        }
        
        const calendar = generateContentCalendar(ideas);
        
        return {
            contentType: contentTypeSelect.value,
            contentTypeName: contentTypeConfigs[contentTypeSelect.value].name,
            ideaCount: ideaCount,
            ideas: ideas,
            calendar: calendar
        };
    }

    // Display idea in real-time - NEW FUNCTION
    function displayIdeaInRealTime(idea, currentIndex, totalCount) {
        const ideaElement = createIdeaElement(idea);
        
        // Add animation class for entrance effect
        ideaElement.classList.add('idea-generating');
        
        ideasGrid.appendChild(ideaElement);
        
        // Add slight stagger effect
        setTimeout(() => {
            ideaElement.classList.remove('idea-generating');
            ideaElement.classList.add('idea-visible');
        }, 100);
        
        // Scroll to show new idea
        ideaElement.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'nearest',
            inline: 'nearest'
        });
    }

    // Generate single idea - NEW FUNCTION
    function generateSingleIdea(index) {
        const contentType = contentTypeSelect.value;
        const contentFormat = contentFormatSelect.value;
        const tone = toneSelect.value;
        const goal = goalSelect.value;
        const keywords = keywordsInput.value.split(',').map(k => k.trim()).filter(k => k);
        
        const config = contentTypeConfigs[contentType];
        const formatTemplate = formatTemplates[contentFormat] || formatTemplates['how-to'];
        const toneTemplate = toneTemplates[tone];
        const goalTemplate = goalTemplates[goal];

        const niche = nicheInput.value;
        const targetAudience = targetAudienceInput.value;
        
        const title = generateTitle(formatTemplate, toneTemplate, goalTemplate, niche, targetAudience, keywords);
        const description = generateDescription(formatTemplate, toneTemplate, goalTemplate, niche, targetAudience);
        const tags = generateTags(niche, keywords);

        return {
            id: index + 1,
            title: title,
            description: description,
            type: config.name,
            format: contentFormatSelect.options[contentFormatSelect.selectedIndex].text,
            tags: tags
        };
    }

    // Display final results after all ideas are generated - NEW FUNCTION
    function displayFinalResults(results) {
        // Update final count
        resultsCount.textContent = `${results.ideaCount} ideas generated`;
        
        // Display calendar
        calendarGrid.innerHTML = '';
        results.calendar.forEach(item => {
            const calendarElement = createCalendarElement(item);
            calendarGrid.appendChild(calendarElement);
        });
        
        // Show completion notification
        showNotification('🎉 All ideas generated! Ready to copy or save.');
    }

    // Generate content ideas based on form inputs
    function generateIdeas() {
        const contentType = contentTypeSelect.value;
        const contentFormat = contentFormatSelect.value;
        const tone = toneSelect.value;
        const goal = goalSelect.value;
        const ideaCount = parseInt(ideaCountSelect.value);
        const keywords = keywordsInput.value.split(',').map(k => k.trim()).filter(k => k);
        
        const config = contentTypeConfigs[contentType];
        const formatTemplate = formatTemplates[contentFormat] || formatTemplates['how-to'];
        const toneTemplate = toneTemplates[tone];
        const goalTemplate = goalTemplates[goal];

        const ideas = [];
        for (let i = 0; i < ideaCount; i++) {
            ideas.push(generateIdea(i, config, formatTemplate, toneTemplate, goalTemplate, keywords));
        }

        const calendar = generateContentCalendar(ideas);

        return {
            contentType: contentType,
            contentTypeName: config.name,
            ideaCount: ideaCount,
            ideas: ideas,
            calendar: calendar
        };
    }

    // Generate individual idea
    function generateIdea(index, config, formatTemplate, toneTemplate, goalTemplate, keywords) {
        const niche = nicheInput.value;
        const targetAudience = targetAudienceInput.value;
        
        const title = generateTitle(formatTemplate, toneTemplate, goalTemplate, niche, targetAudience, keywords);
        const description = generateDescription(formatTemplate, toneTemplate, goalTemplate, niche, targetAudience);
        const tags = generateTags(niche, keywords);

        return {
            id: index + 1,
            title: title,
            description: description,
            type: config.name,
            format: contentFormatSelect.options[contentFormatSelect.selectedIndex].text,
            tags: tags
        };
    }

    // Generate title
    function generateTitle(formatTemplate, toneTemplate, goalTemplate, niche, targetAudience, keywords) {
        const templates = formatTemplate.templates;
        const adjectives = toneTemplate.adjectives;
        const focusWords = goalTemplate.focus;
        
        let template = templates[Math.floor(Math.random() * templates.length)];
        
        // Replace placeholders with actual content
        template = template.replace('[Number]', getRandomNumber());
        template = template.replace('[Topic]', niche);
        template = template.replace('[Action]', getRandomItem(focusWords));
        template = template.replace('[Goal]', getRandomItem(goalTemplate.outcomes));
        template = template.replace('[Audience]', targetAudience);
        template = template.replace('[Timeframe]', getRandomTimeframe());
        
        // Add adjectives for tone
        if (Math.random() > 0.5) {
            template = getRandomItem(adjectives) + ' ' + template.replace('[', '');
        }
        
        // Add keywords if available
        if (keywords.length > 0 && Math.random() > 0.7) {
            template += ` (${getRandomItem(keywords)})`;
        }
        
        return template;
    }

    // Generate description
    function generateDescription(formatTemplate, toneTemplate, goalTemplate, niche, targetAudience) {
        const descriptions = formatTemplate.descriptions;
        const phrases = toneTemplate.phrases;
        const focusWords = goalTemplate.focus;
        
        let description = descriptions[Math.floor(Math.random() * descriptions.length)];
        
        // Enhance description with tone and goal elements
        description = description.replace('[Topic]', niche.toLowerCase());
        description = description.replace('[audience]', targetAudience.toLowerCase());
        
        // Add tone phrases
        if (Math.random() > 0.5) {
            description += ` ${getRandomItem(phrases)}.`;
        }
        
        // Add goal focus
        description += ` Perfect for ${getRandomItem(focusWords)}ing ${getRandomItem(goalTemplate.outcomes)}.`;
        
        return description;
    }

    // Generate tags
    function generateTags(niche, keywords) {
        const baseTags = [niche, contentFormatSelect.options[contentFormatSelect.selectedIndex].text];
        const additionalTags = keywords.slice(0, 3);
        const toneTag = toneSelect.options[toneSelect.selectedIndex].text;
        
        return [...new Set([...baseTags, ...additionalTags, toneTag])].slice(0, 5);
    }

    // Generate content calendar
    function generateContentCalendar(ideas) {
        const today = new Date();
        const calendar = [];
        
        ideas.slice(0, 5).forEach((idea, index) => {
            const date = new Date(today);
            date.setDate(today.getDate() + (index * 2)); // Schedule every 2 days
            
            calendar.push({
                date: date.toLocaleDateString('en-US', { 
                    weekday: 'short', 
                    month: 'short', 
                    day: 'numeric' 
                }),
                idea: idea.title,
                type: idea.type
            });
        });
        
        return calendar;
    }

    // Display results (legacy function - kept for compatibility)
    function displayResults(results) {
        // Update results header
        resultsBadge.textContent = results.contentTypeName;
        resultsCount.textContent = `${results.ideaCount} ideas generated`;
        
        // Display ideas
        ideasGrid.innerHTML = '';
        results.ideas.forEach(idea => {
            const ideaElement = createIdeaElement(idea);
            ideasGrid.appendChild(ideaElement);
        });
        
        // Display calendar
        calendarGrid.innerHTML = '';
        results.calendar.forEach(item => {
            const calendarElement = createCalendarElement(item);
            calendarGrid.appendChild(calendarElement);
        });
        
        // Show results
        resultsPlaceholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');
    }

    // Create idea element
    function createIdeaElement(idea) {
        const element = document.createElement('div');
        element.className = 'idea-card';
        element.innerHTML = `
            <div class="idea-header">
                <div class="idea-type">${idea.format}</div>
                <div class="idea-number">#${idea.id}</div>
            </div>
            <div class="idea-title">${idea.title}</div>
            <div class="idea-description">${idea.description}</div>
            <div class="idea-meta">
                ${idea.tags.map(tag => `<span class="meta-tag">${tag}</span>`).join('')}
            </div>
        `;
        
        element.addEventListener('click', () => {
            copyToClipboard(`${idea.title}\n\n${idea.description}\n\nTags: ${idea.tags.join(', ')}`);
        });
        
        return element;
    }

    // Create calendar element
    function createCalendarElement(item) {
        const element = document.createElement('div');
        element.className = 'calendar-item';
        element.innerHTML = `
            <div class="calendar-date">${item.date}</div>
            <div class="calendar-idea">${item.idea}</div>
        `;
        return element;
    }

    // Toggle calendar visibility
    function toggleCalendar() {
        contentCalendar.classList.toggle('hidden');
        calendarToggle.innerHTML = contentCalendar.classList.contains('hidden') 
            ? '<span>📅</span> Show Calendar' 
            : '<span>📅</span> Hide Calendar';
    }

    // Save all ideas
    function saveAllIdeas() {
        const ideas = Array.from(document.querySelectorAll('.idea-card'));
        const allIdeas = ideas.map(card => {
            const title = card.querySelector('.idea-title').textContent;
            const description = card.querySelector('.idea-description').textContent;
            const tags = Array.from(card.querySelectorAll('.meta-tag')).map(tag => tag.textContent);
            return `${title}\n${description}\nTags: ${tags.join(', ')}\n\n`;
        }).join('---\n\n');
        
        copyToClipboard(allIdeas);
        showNotification('All ideas copied to clipboard!');
    }

    // Set loading state
    function setLoadingState(isLoading) {
        if (isLoading) {
            generateBtn.disabled = true;
            regenerateBtn.disabled = true;
            loadingIndicator.classList.remove('hidden');
            
            const btnText = generateBtn.querySelector('.btn-text');
            const btnLoading = generateBtn.querySelector('.btn-loading');
            if (btnText && btnLoading) {
                btnText.classList.add('hidden');
                btnLoading.classList.remove('hidden');
            }
        } else {
            generateBtn.disabled = false;
            regenerateBtn.disabled = false;
            loadingIndicator.classList.add('hidden');
            
            const btnText = generateBtn.querySelector('.btn-text');
            const btnLoading = generateBtn.querySelector('.btn-loading');
            if (btnText && btnLoading) {
                btnText.classList.remove('hidden');
                btnLoading.classList.add('hidden');
            }
        }
    }

    // Copy text to clipboard
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copied to clipboard!');
        }).catch(err => {
            console.error('Failed to copy: ', err);
            showNotification('Failed to copy to clipboard');
        });
    }

    // Show notification
    function showNotification(message) {
        // Remove existing notifications
        const existingNotifications = document.querySelectorAll('.custom-notification');
        existingNotifications.forEach(notification => notification.remove());
        
        const notification = document.createElement('div');
        notification.className = 'custom-notification';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            z-index: 1000;
            font-weight: 600;
            border: 2px solid rgba(255,255,255,0.3);
            backdrop-filter: blur(10px);
            transform: translateX(400px);
            opacity: 0;
            transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
            notification.style.opacity = '1';
        }, 100);
        
        // Auto-remove
        setTimeout(() => {
            notification.style.transform = 'translateX(400px)';
            notification.style.opacity = '0';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 500);
        }, 3000);
    }

    // Helper functions
    function getRandomItem(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    function getRandomNumber() {
        const numbers = [5, 7, 10, 15, 21, 25, 30];
        return numbers[Math.floor(Math.random() * numbers.length)];
    }

    function getRandomTimeframe() {
        const timeframes = ['30 Days', '1 Week', '24 Hours', '5 Simple Steps', '2024', 'This Year'];
        return getRandomItem(timeframes);
    }

    // Update examples based on tab selection
    function updateExamples(type) {
        // In a real application, this would load different examples
        console.log('Loading examples for:', type);
    }

    // Initialize with some example data for demo purposes
    function initializeDemo() {
        nicheInput.value = 'Digital Marketing';
        targetAudienceInput.value = 'Small Business Owners';
        keywordsInput.value = 'SEO, social media, content strategy, email marketing';
    }

    // Initialize the demo
    initializeDemo();
});

// Add CSS for tools links
const toolsStyles = document.createElement('style');
toolsStyles.textContent = `
    .tools-links-container {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 2px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    
    .tools-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    
    .tools-header h3 {
        color: #1e293b;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: 700;
    }
    
    .tools-header p {
        color: #64748b;
        font-size: 0.9rem;
    }
    
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .tool-link {
        background: white;
        border: 2px solid #f1f5f9;
        border-radius: 12px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        text-decoration: none;
        transition: all 0.3s ease;
        color: inherit;
    }
    
    .tool-link:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
        text-decoration: none;
        color: inherit;
    }
    
    .tool-icon {
        font-size: 2rem;
        flex-shrink: 0;
    }
    
    .tool-content h4 {
        color: #1e293b;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        font-weight: 600;
    }
    
    .tool-content p {
        color: #64748b;
        font-size: 0.8rem;
        margin: 0;
        line-height: 1.4;
    }
    
    .idea-generating {
        opacity: 0;
        transform: translateY(20px);
        animation: ideaSlideIn 0.6s ease-out forwards;
    }
    
    .idea-visible {
        opacity: 1;
        transform: translateY(0);
    }
    
    @keyframes ideaSlideIn {
        0% {
            opacity: 0;
            transform: translateY(20px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .idea-card {
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }
    
    .idea-card:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
    }
    
    .idea-number {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 0.2rem 0.6rem;
        border-radius: 12px;
        font-size: 0.8em;
        font-weight: bold;
    }
    
    #loading-indicator {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 12px;
        border: 2px solid rgba(255,255,255,0.3);
    }
    
    .loading-text {
        font-weight: 600;
        background: linear-gradient(90deg, #fff, #e0e7ff, #fff);
        background-size: 200% 100%;
        animation: shimmer 2s infinite;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
`;
document.head.appendChild(toolsStyles);