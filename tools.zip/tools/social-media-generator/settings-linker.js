// settings-linker.js

// Save button functionality with redirect and settings application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize settings when page loads
    initializePage();
    
    // Add event listeners to all save buttons
    const saveButtons = document.querySelectorAll('.save-button');
    
    saveButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get the section from button ID
            const buttonId = this.id;
            let section = '';
            
            if (buttonId.includes('Content')) section = 'content';
            else if (buttonId.includes('Posting')) section = 'posting';
            else if (buttonId.includes('Media')) section = 'media';
            else if (buttonId.includes('Account')) section = 'account';
            else if (buttonId.includes('Analytics')) section = 'analytics';
            else if (buttonId.includes('General')) section = 'general';
            else section = 'content'; // default
            
            // Save settings and redirect to dashboard
            saveSettingsAndRedirect(section, this);
        });
    });
    
    // Add event listener to generate button to use saved settings
    const generateBtn = document.getElementById('generateContentBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', function() {
            generateContentWithSavedSettings();
        });
    }
});

// Initialize page with saved settings
function initializePage() {
    const settings = loadSavedSettings();
    applySettingsToContentGenerator(settings);
    
    // Check if we're coming from settings save
    checkForSettingsRedirect();
}

// Check if we're coming from settings save and show notification
function checkForSettingsRedirect() {
    const urlParams = new URLSearchParams(window.location.search);
    const fromSettings = urlParams.get('fromSettings');
    
    if (fromSettings) {
        showSettingsAppliedNotification();
        
        // Remove the parameter from URL without reloading
        const newUrl = window.location.pathname;
        window.history.replaceState({}, '', newUrl);
    }
}

// Save settings and redirect to dashboard
function saveSettingsAndRedirect(section, buttonElement) {
    // Show loading state on button
    const originalText = buttonElement.innerHTML;
    buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Saving...</span>';
    buttonElement.disabled = true;
    
    // Simulate save process
    setTimeout(() => {
        // Save settings to localStorage
        const settings = collectCurrentSettings(section);
        localStorage.setItem('socialGeniusSettings', JSON.stringify(settings));
        
        // Update global settings
        window.userSettings = settings;
        
        // Show success message
        showSaveSuccess(section);
        
        // Redirect to dashboard after delay
        setTimeout(() => {
            redirectToDashboard();
            
            // Reset button state
            buttonElement.innerHTML = originalText;
            buttonElement.disabled = false;
        }, 1500);
        
    }, 1000);
}

// Collect current section settings
function collectCurrentSettings(section) {
    // Get existing settings or create new object
    const existingSettings = JSON.parse(localStorage.getItem('socialGeniusSettings')) || {};
    
    switch(section) {
        case 'content':
            existingSettings.content = existingSettings.content || {};
            
            // Brand Voice from radio buttons
            const selectedVoice = document.querySelector('input[name="brand-voice"]:checked');
            if (selectedVoice) {
                existingSettings.content.tone = selectedVoice.id.replace('voice-', '');
            }
            
            // Target Audience
            const audienceInput = document.querySelector('input[placeholder*="Audience Demographics"]');
            if (audienceInput) {
                existingSettings.content.targetAudience = audienceInput.value;
            }
            
            // Content Pillars (simplified)
            const pillarElements = document.querySelectorAll('.content-pillar h4');
            existingSettings.content.contentPillars = Array.from(pillarElements).map(pillar => pillar.textContent);
            
            // Keywords
            const keywordTextareas = document.querySelectorAll('textarea');
            keywordTextareas.forEach(textarea => {
                if (textarea.placeholder && textarea.placeholder.includes('Keywords to Include')) {
                    existingSettings.content.keywords = existingSettings.content.keywords || {};
                    existingSettings.content.keywords.include = textarea.value;
                } else if (textarea.placeholder && textarea.placeholder.includes('Keywords to Avoid')) {
                    existingSettings.content.keywords = existingSettings.content.keywords || {};
                    existingSettings.content.keywords.avoid = textarea.value;
                }
            });
            break;
            
        case 'posting':
            existingSettings.posting = existingSettings.posting || {};
            
            // Publishing Mode
            const publishMode = document.querySelector('input[name="publish-mode"]:checked');
            if (publishMode) {
                existingSettings.posting.publishMode = publishMode.nextElementSibling.textContent.toLowerCase().includes('draft') ? 'draft' : 'publish';
            }
            
            // Posting Frequency
            const frequencySelects = document.querySelectorAll('select');
            frequencySelects.forEach(select => {
                if (select.previousElementSibling && select.previousElementSibling.textContent.includes('Posts Per Week')) {
                    existingSettings.posting.frequency = select.value;
                }
            });
            break;
            
        case 'media':
            existingSettings.media = existingSettings.media || {};
            
            // Image Source
            const imageSource = document.querySelector('input[name="image-source"]:checked');
            if (imageSource) {
                existingSettings.media.imageSource = imageSource.id.replace('source-', '');
            }
            
            // Auto-generate Images
            const autoGenerateCheckbox = document.querySelector('input[type="checkbox"]');
            if (autoGenerateCheckbox) {
                existingSettings.media.autoGenerateImages = autoGenerateCheckbox.checked;
            }
            break;
    }
    
    return existingSettings;
}

// Redirect to main dashboard
function redirectToDashboard() {
    // If we're on a settings page, navigate back to index.html with parameter
    if (window.location.pathname.includes('settings.html') || window.location.hash.includes('settings')) {
        window.location.href = 'index.html?fromSettings=true';
    } else {
        // If we're already on index.html, just show the dashboard and apply settings
        showDashboard();
    }
}

// Show dashboard and apply settings
function showDashboard() {
    // Hide settings sections if they're visible
    const settingsSections = document.querySelectorAll('.settings-section');
    const settingsNav = document.querySelector('.lg\\:col-span-1');
    const settingsContent = document.querySelector('.lg\\:col-span-3');
    
    if (settingsSections.length > 0) {
        settingsSections.forEach(section => {
            section.style.display = 'none';
        });
    }
    
    if (settingsNav) {
        settingsNav.style.display = 'none';
    }
    
    if (settingsContent) {
        settingsContent.style.display = 'none';
    }
    
    // Show main dashboard content
    const mainContent = document.querySelector('.lg\\:col-span-2');
    const rightColumn = document.querySelector('.space-y-6');
    
    if (mainContent) {
        mainContent.style.display = 'block';
    }
    
    if (rightColumn) {
        rightColumn.style.display = 'block';
    }
    
    // Apply saved settings to content generator
    const settings = loadSavedSettings();
    applySettingsToContentGenerator(settings);
    
    // Scroll to content generator and highlight it
    const contentGenerator = document.getElementById('contentGenerator');
    if (contentGenerator) {
        contentGenerator.scrollIntoView({ behavior: 'smooth' });
        highlightContentGenerator();
    }
    
    // Show settings applied notification
    showSettingsAppliedNotification();
}

// Apply settings to content generator form
function applySettingsToContentGenerator(settings) {
    if (!settings.content) return;
    
    console.log('Applying settings to content generator:', settings.content);
    
    // Apply brand voice to dropdown
    const brandVoiceSelect = document.getElementById('brandVoice');
    if (brandVoiceSelect && settings.content.brandVoice) {
        brandVoiceSelect.value = settings.content.brandVoice;
        console.log('Applied brand voice:', settings.content.brandVoice);
    }
    
    // Apply target audience
    const targetAudienceInput = document.getElementById('targetAudience');
    if (targetAudienceInput && settings.content.targetAudience) {
        targetAudienceInput.value = settings.content.targetAudience;
        console.log('Applied target audience:', settings.content.targetAudience);
    }
    
    // Show settings indicator in the form
    showSettingsIndicator(settings);
}

// Show visual indicator that settings are applied
function showSettingsIndicator(settings) {
    // Remove existing indicator if any
    const existingIndicator = document.getElementById('settingsAppliedIndicator');
    if (existingIndicator) {
        existingIndicator.remove();
    }
    
    if (settings.content && (settings.content.targetAudience || settings.content.brandVoice)) {
        const indicator = document.createElement('div');
        indicator.id = 'settingsAppliedIndicator';
        indicator.className = 'mb-4 p-3 bg-green-50 border border-green-200 rounded-lg';
        indicator.innerHTML = `
            <div class="flex items-center space-x-2 text-green-700">
                <i class="fas fa-check-circle"></i>
                <span class="font-medium">Your saved settings are applied</span>
            </div>
            <div class="mt-2 text-sm text-green-600">
                ${settings.content.brandVoice ? `<div>• Brand Voice: <strong>${settings.content.brandVoice}</strong></div>` : ''}
                ${settings.content.targetAudience ? `<div>• Target Audience: <strong>${settings.content.targetAudience}</strong></div>` : ''}
                ${settings.content.tone ? `<div>• Tone: <strong>${settings.content.tone}</strong></div>` : ''}
            </div>
        `;
        
        const contentGenerator = document.getElementById('contentGenerator');
        if (contentGenerator) {
            const form = contentGenerator.querySelector('.space-y-4');
            if (form) {
                form.insertBefore(indicator, form.firstChild);
                
                // Auto-remove after 10 seconds
                setTimeout(() => {
                    if (indicator.parentNode) {
                        indicator.style.opacity = '0';
                        indicator.style.transition = 'opacity 0.5s ease';
                        setTimeout(() => {
                            if (indicator.parentNode) {
                                indicator.remove();
                            }
                        }, 500);
                    }
                }, 10000);
            }
        }
    }
}

// Highlight content generator to show settings are applied
function highlightContentGenerator() {
    const contentGenerator = document.getElementById('contentGenerator');
    if (contentGenerator) {
        contentGenerator.classList.add('ring-4', 'ring-green-500', 'ring-opacity-50', 'transition-all', 'duration-1000');
        
        setTimeout(() => {
            contentGenerator.classList.remove('ring-4', 'ring-green-500', 'ring-opacity-50');
        }, 3000);
    }
}

// Show settings applied notification
function showSettingsAppliedNotification() {
    // Remove existing notification if any
    const existingNotification = document.getElementById('settingsAppliedNotification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.id = 'settingsAppliedNotification';
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white py-3 px-6 rounded-lg shadow-lg z-50';
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-check-circle"></i>
            <span>Your settings are now active in the content generator!</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Add animation
    notification.style.animation = 'slideInRight 0.3s ease-out';
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

// Show save success message
function showSaveSuccess(section) {
    // Remove existing notification if any
    const existingNotification = document.getElementById('saveSuccessNotification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create success notification
    const successMsg = document.createElement('div');
    successMsg.id = 'saveSuccessNotification';
    successMsg.className = 'fixed top-4 left-4 bg-green-500 text-white py-3 px-6 rounded-lg shadow-lg z-50';
    successMsg.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-check-circle"></i>
            <span>${getSectionName(section)} settings saved! Redirecting to dashboard...</span>
        </div>
    `;
    document.body.appendChild(successMsg);
    
    // Add animation
    successMsg.style.animation = 'slideInLeft 0.3s ease-out';
    
    // Hide after 3 seconds
    setTimeout(() => {
        successMsg.style.animation = 'slideOutLeft 0.3s ease-in';
        setTimeout(() => {
            if (successMsg.parentNode) {
                successMsg.remove();
            }
        }, 300);
    }, 3000);
}

// Get section name for display
function getSectionName(section) {
    const sectionNames = {
        'content': 'Content Generation',
        'posting': 'Posting & Scheduling',
        'media': 'Media & Assets',
        'account': 'Account & Profile',
        'analytics': 'Analytics & Reporting',
        'general': 'General'
    };
    return sectionNames[section] || 'Settings';
}

// Load saved settings from localStorage
function loadSavedSettings() {
    const savedSettings = localStorage.getItem('socialGeniusSettings');
    if (savedSettings) {
        window.userSettings = JSON.parse(savedSettings);
        console.log('Loaded saved settings:', window.userSettings);
        return window.userSettings;
    } else {
        // Initialize default settings
        window.userSettings = {
            content: {
                brandVoice: 'professional',
                targetAudience: '',
                tone: 'professional',
                keywords: {
                    include: 'social media, automation, AI, marketing',
                    avoid: 'spam, fake, scam'
                }
            },
            posting: {
                publishMode: 'draft',
                frequency: '3-5 posts'
            },
            media: {
                imageSource: 'unsplash',
                autoGenerateImages: true
            }
        };
        return window.userSettings;
    }
}

// Generate content using saved settings
function generateContentWithSavedSettings() {
    const settings = loadSavedSettings();
    
    // Get current form values
    const niche = document.getElementById('nicheSelect').value;
    const contentType = document.getElementById('contentType').value;
    const brandVoice = document.getElementById('brandVoice').value;
    const targetAudience = document.getElementById('targetAudience').value;
    const postQuantity = document.getElementById('postQuantity').value;
    
    // Use saved settings as fallbacks
    const generationSettings = {
        niche: niche,
        contentType: contentType,
        brandVoice: brandVoice || (settings.content ? settings.content.brandVoice : 'professional'),
        targetAudience: targetAudience || (settings.content ? settings.content.targetAudience : ''),
        postQuantity: parseInt(postQuantity),
        tone: settings.content ? settings.content.tone : 'professional',
        keywords: settings.content ? settings.content.keywords : { include: '', avoid: '' },
        imageSource: settings.media ? settings.media.imageSource : 'unsplash',
        autoGenerateImages: settings.media ? settings.media.autoGenerateImages : true,
        contentPillars: settings.content ? settings.content.contentPillars : []
    };
    
    console.log('Generating content with enhanced settings:', generationSettings);
    
    // Show generation in progress
    showGenerationInProgress(generationSettings);
    
    return generationSettings;
}

// Show generation in progress with settings used
function showGenerationInProgress(settings) {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        // Enhance loading overlay to show settings being used
        const settingsInfo = loadingOverlay.querySelector('.text-gray-500');
        if (settingsInfo) {
            settingsInfo.innerHTML += `
                <div class="mt-4 p-3 bg-blue-50 rounded-lg text-left">
                    <div class="font-medium text-blue-800 mb-2">Using Your Settings:</div>
                    <div class="text-sm text-blue-600 space-y-1">
                        ${settings.brandVoice ? `<div>✓ Brand Voice: ${settings.brandVoice}</div>` : ''}
                        ${settings.targetAudience ? `<div>✓ Audience: ${settings.targetAudience}</div>` : ''}
                        ${settings.tone ? `<div>✓ Tone: ${settings.tone}</div>` : ''}
                    </div>
                </div>
            `;
        }
        loadingOverlay.classList.remove('hidden');
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    @keyframes slideInLeft {
        from {
            transform: translateX(-100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutLeft {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(-100%);
            opacity: 0;
        }
    }
    
    .save-button:disabled {
        background-color: #9ca3af;
        cursor: not-allowed;
    }
    
    .fa-spinner {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    
    .ring-4 {
        transition: all 0.3s ease;
    }
    
    #settingsAppliedIndicator {
        animation: fadeIn 0.5s ease-out;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
`;
document.head.appendChild(style);

// Make functions available globally
window.applyContentSettings = applySettingsToContentGenerator;
window.generateWithSettings = generateContentWithSavedSettings;
window.redirectToDashboard = redirectToDashboard;