// Payment Method Interactions - Professional Version
class PaymentMethodManager {
    constructor() {
        this.modal = null;
        this.isInitialized = false;
        this.currentAction = null; // 'edit' or 'add'
        this.currentPaymentId = null;
        
        this.init();
    }

    init() {
        if (this.isInitialized) return;
        
        this.bindEvents();
        this.createModal();
        this.isInitialized = true;
        
        console.log('PaymentMethodManager initialized');
    }

    bindEvents() {
        // Use event delegation for dynamic elements
        document.addEventListener('click', (e) => {
            // Payment card click
            if (e.target.closest('.payment-method-card')) {
                this.handleCardClick(e);
            }
            
            // Edit button click
            if (e.target.closest('.edit-payment-btn')) {
                this.handleEditClick(e);
            }
            
            // Add payment button click
            if (e.target.closest('.add-payment-btn')) {
                this.handleAddClick(e);
            }
            
           // Close modal buttons (ADD THIS LINE FOR X BUTTON)
            if (e.target.closest('.close-payment-modal') || 
                e.target.closest('.payment-modal-cancel') ||
                e.target.closest('.payment-modal-close')) {  // ← ADD THIS
                this.closeModal();
            }
            
            // Modal backdrop click
            if (e.target.classList.contains('payment-modal')) {
                this.closeModal();
            }
        });

        // Form submission
        document.addEventListener('submit', (e) => {
            if (e.target.id === 'paymentForm') {
                this.handleFormSubmit(e);
            }
        });

        // Keyboard events
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modal?.classList.contains('active')) {
                this.closeModal();
            }
        });

        // Input formatting
        document.addEventListener('input', (e) => {
            if (e.target.name === 'cardNumber') {
                this.formatCardNumber(e.target);
            }
            if (e.target.name === 'expiryDate') {
                this.formatExpiryDate(e.target);
            }
            if (e.target.name === 'cvv') {
                this.formatCVV(e.target);
            }
        });
    }

    handleCardClick(e) {
        const card = e.target.closest('.payment-method-card');
        const paymentId = card.dataset.paymentId;
        
        // Don't trigger if clicking the edit button (to avoid double events)
        if (!e.target.closest('.edit-payment-btn')) {
            this.openEditModal(paymentId);
        }
    }

    handleEditClick(e) {
        e.stopPropagation(); // Prevent card click event
        const card = e.target.closest('.payment-method-card');
        const paymentId = card.dataset.paymentId;
        this.openEditModal(paymentId);
    }

    handleAddClick(e) {
        e.preventDefault();
        this.openAddModal();
    }

    openEditModal(paymentId) {
        this.currentAction = 'edit';
        this.currentPaymentId = paymentId;
        
        // In a real app, you would fetch payment data from your backend
        const paymentData = this.getPaymentData(paymentId);
        this.populateForm(paymentData);
        
        this.showModal('Edit Payment Method');
        this.animateModalIn();
    }

    openAddModal() {
        this.currentAction = 'add';
        this.currentPaymentId = null;
        
        this.clearForm();
        this.showModal('Add New Payment Method');
        this.animateModalIn();
    }

    showModal(title) {
        if (!this.modal) return;
        
        // Update modal title
        const modalTitle = this.modal.querySelector('.payment-modal-title');
        if (modalTitle) {
            modalTitle.textContent = title;
        }
        
        // Show modal
        this.modal.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
        
        // Set focus to first input for accessibility
        setTimeout(() => {
            const firstInput = this.modal.querySelector('input');
            if (firstInput) firstInput.focus();
        }, 300);
    }

    closeModal() {
        if (!this.modal) return;
        
        this.animateModalOut(() => {
            this.modal.classList.remove('active');
            document.body.style.overflow = ''; // Restore scrolling
            this.currentAction = null;
            this.currentPaymentId = null;
        });
    }

    animateModalIn() {
        const modalContent = this.modal.querySelector('.payment-modal-content');
        if (modalContent) {
            modalContent.style.transform = 'scale(0.95) translateY(-10px)';
            modalContent.style.opacity = '0';
            
            requestAnimationFrame(() => {
                modalContent.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
                modalContent.style.transform = 'scale(1) translateY(0)';
                modalContent.style.opacity = '1';
            });
        }
    }

    animateModalOut(callback) {
        const modalContent = this.modal.querySelector('.payment-modal-content');
        if (modalContent) {
            modalContent.style.transform = 'scale(1) translateY(0)';
            modalContent.style.opacity = '1';
            
            requestAnimationFrame(() => {
                modalContent.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';
                modalContent.style.transform = 'scale(0.95) translateY(-10px)';
                modalContent.style.opacity = '0';
                
                setTimeout(callback, 200);
            });
        } else {
            callback();
        }
    }

    async handleFormSubmit(e) {
        e.preventDefault();
        
        const formData = this.getFormData();
        const isValid = this.validateForm(formData);
        
        if (!isValid) {
            this.showValidationErrors();
            return;
        }
        
        this.setLoadingState(true);
        
        try {
            // Simulate API call
            await this.savePaymentMethod(formData);
            
            this.showSuccessMessage('Payment method saved successfully!');
            this.closeModal();
            
            // Update UI with new data
            this.updatePaymentDisplay(formData);
            
        } catch (error) {
            this.showErrorMessage('Failed to save payment method. Please try again.');
            console.error('Payment method save error:', error);
        } finally {
            this.setLoadingState(false);
        }
    }

    getFormData() {
        const form = document.getElementById('paymentForm');
        return {
            cardNumber: form.querySelector('[name="cardNumber"]').value,
            expiryDate: form.querySelector('[name="expiryDate"]').value,
            cvv: form.querySelector('[name="cvv"]').value,
            cardholderName: form.querySelector('[name="cardholderName"]')?.value || '',
            isDefault: form.querySelector('[name="isDefault"]')?.checked || false
        };
    }

    validateForm(data) {
        let isValid = true;
        this.clearValidationErrors();
        
        // Card number validation (basic)
        if (!data.cardNumber || data.cardNumber.replace(/\s/g, '').length < 16) {
            this.showFieldError('cardNumber', 'Please enter a valid card number');
            isValid = false;
        }
        
        // Expiry date validation
        if (!this.isValidExpiryDate(data.expiryDate)) {
            this.showFieldError('expiryDate', 'Please enter a valid expiry date (MM/YY)');
            isValid = false;
        }
        
        // CVV validation
        if (!data.cvv || data.cvv.length < 3) {
            this.showFieldError('cvv', 'Please enter a valid CVV');
            isValid = false;
        }
        
        return isValid;
    }

    isValidExpiryDate(expiryDate) {
        if (!expiryDate || !expiryDate.includes('/')) return false;
        
        const [month, year] = expiryDate.split('/');
        const now = new Date();
        const currentYear = now.getFullYear() % 100;
        const currentMonth = now.getMonth() + 1;
        
        const expMonth = parseInt(month);
        const expYear = parseInt(year);
        
        if (expMonth < 1 || expMonth > 12) return false;
        if (expYear < currentYear) return false;
        if (expYear === currentYear && expMonth < currentMonth) return false;
        
        return true;
    }

    showFieldError(fieldName, message) {
        const field = document.querySelector(`[name="${fieldName}"]`);
        if (field) {
            field.classList.add('payment-error');
            
            let errorElement = field.parentNode.querySelector('.payment-error-message');
            if (!errorElement) {
                errorElement = document.createElement('div');
                errorElement.className = 'payment-error-message';
                field.parentNode.appendChild(errorElement);
            }
            errorElement.textContent = message;
        }
    }

    clearValidationErrors() {
        document.querySelectorAll('.payment-error').forEach(el => {
            el.classList.remove('payment-error');
        });
        document.querySelectorAll('.payment-error-message').forEach(el => {
            el.remove();
        });
    }

    setLoadingState(isLoading) {
        const submitButton = this.modal.querySelector('.payment-modal-submit');
        const buttons = this.modal.querySelectorAll('button');
        
        if (isLoading) {
            submitButton.classList.add('payment-loading');
            submitButton.disabled = true;
            buttons.forEach(btn => btn.disabled = true);
            submitButton.innerHTML = '<span class="payment-spinner"></span> Saving...';
        } else {
            submitButton.classList.remove('payment-loading');
            submitButton.disabled = false;
            buttons.forEach(btn => btn.disabled = false);
            submitButton.textContent = this.currentAction === 'edit' ? 'Save Changes' : 'Add Payment Method';
        }
    }

    showSuccessMessage(message) {
        this.showToast(message, 'success');
    }

    showErrorMessage(message) {
        this.showToast(message, 'error');
    }

    showToast(message, type = 'info') {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = `payment-toast payment-toast-${type}`;
        toast.innerHTML = `
            <div class="payment-toast-content">
                <i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}-circle"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Animate in
        requestAnimationFrame(() => {
            toast.style.transform = 'translateX(100%)';
            requestAnimationFrame(() => {
                toast.style.transition = 'transform 0.3s ease';
                toast.style.transform = 'translateX(0)';
            });
        });
        
        // Remove after delay
        setTimeout(() => {
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, 3000);
    }

    // Utility methods for input formatting
    formatCardNumber(input) {
        let value = input.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        let formattedValue = '';
        
        for (let i = 0; i < value.length; i++) {
            if (i > 0 && i % 4 === 0) {
                formattedValue += ' ';
            }
            formattedValue += value[i];
        }
        
        input.value = formattedValue.trim();
    }

    formatExpiryDate(input) {
        let value = input.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        
        if (value.length >= 2) {
            input.value = value.slice(0, 2) + '/' + value.slice(2, 4);
        } else {
            input.value = value;
        }
    }

    formatCVV(input) {
        input.value = input.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '').slice(0, 4);
    }

    // Mock data methods - replace with actual API calls
    getPaymentData(paymentId) {
        // Mock data - replace with actual API call
        return {
            cardNumber: '4242 4242 4242 4242',
            expiryDate: '12/25',
            cvv: '123',
            cardholderName: 'John Doe',
            isDefault: true
        };
    }

    populateForm(data) {
        const form = document.getElementById('paymentForm');
        if (!form) return;
        
        form.querySelector('[name="cardNumber"]').value = data.cardNumber || '';
        form.querySelector('[name="expiryDate"]').value = data.expiryDate || '';
        form.querySelector('[name="cvv"]').value = data.cvv || '';
        
        if (data.cardholderName) {
            const nameField = form.querySelector('[name="cardholderName"]');
            if (nameField) nameField.value = data.cardholderName;
        }
        
        if (data.isDefault) {
            const defaultField = form.querySelector('[name="isDefault"]');
            if (defaultField) defaultField.checked = data.isDefault;
        }
    }

    clearForm() {
        const form = document.getElementById('paymentForm');
        if (form) {
            form.reset();
            this.clearValidationErrors();
        }
    }

    async savePaymentMethod(data) {
        // Simulate API call delay
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simulate random failure (remove in production)
                if (Math.random() < 0.1) { // 10% chance of failure for demo
                    reject(new Error('Network error'));
                } else {
                    resolve({ success: true, data });
                }
            }, 1000);
        });
    }

    updatePaymentDisplay(data) {
        // Update the displayed payment method in the UI
        const cardNumber = data.cardNumber;
        const lastFour = cardNumber.slice(-4);
        const expiryDate = data.expiryDate;
        
        // Update the main payment card display
        const cardDisplay = document.querySelector('.payment-method-card');
        if (cardDisplay) {
            const numberElement = cardDisplay.querySelector('h4');
            const expiryElement = cardDisplay.querySelector('.text-sm');
            
            if (numberElement) {
                numberElement.textContent = `Visa ending in ${lastFour}`;
            }
            if (expiryElement) {
                expiryElement.textContent = `Expires ${expiryDate}`;
            }
        }
    }

    createModal() {
        // Create modal HTML if it doesn't exist
        if (document.getElementById('paymentModal')) {
            this.modal = document.getElementById('paymentModal');
            return;
        }

        const modalHTML = `
            <div id="paymentModal" class="payment-modal">
                <div class="payment-modal-content">
                    <div class="payment-modal-header">
                        <h3 class="payment-modal-title">Edit Payment Method</h3>
                    </div>
                    <form id="paymentForm" class="payment-modal-body">
                        <div class="payment-form-group">
                            <label class="payment-form-label">Cardholder Name</label>
                            <input type="text" name="cardholderName" class="payment-form-input" placeholder="John Doe">
                        </div>
                        <div class="payment-form-group">
                            <label class="payment-form-label">Card Number</label>
                            <input type="text" name="cardNumber" class="payment-form-input" placeholder="4242 4242 4242 4242" maxlength="19">
                        </div>
                        <div class="payment-form-grid">
                            <div class="payment-form-group">
                                <label class="payment-form-label">Expiry Date</label>
                                <input type="text" name="expiryDate" class="payment-form-input" placeholder="MM/YY" maxlength="5">
                            </div>
                            <div class="payment-form-group">
                                <label class="payment-form-label">CVV</label>
                                <input type="text" name="cvv" class="payment-form-input" placeholder="123" maxlength="4">
                            </div>
                        </div>
                        <div class="payment-form-group">
                            <label class="payment-form-checkbox">
                                <input type="checkbox" name="isDefault">
                                <span>Set as default payment method</span>
                            </label>
                        </div>
                    </form>
                    <div class="payment-modal-footer">
                        <button type="button" class="payment-btn payment-btn-secondary payment-modal-cancel">Cancel</button>
                        <button type="submit" form="paymentForm" class="payment-btn payment-btn-primary payment-modal-submit">Save Changes</button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.modal = document.getElementById('paymentModal');
    }

    // Public method to destroy instance
    destroy() {
        document.removeEventListener('click', this.boundHandlers);
        document.removeEventListener('submit', this.boundHandlers);
        document.removeEventListener('keydown', this.boundHandlers);
        document.removeEventListener('input', this.boundHandlers);
        
        if (this.modal && this.modal.parentNode) {
            this.modal.parentNode.removeChild(this.modal);
        }
        
        this.isInitialized = false;
        console.log('PaymentMethodManager destroyed');
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.paymentMethodManager = new PaymentMethodManager();
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PaymentMethodManager;
}