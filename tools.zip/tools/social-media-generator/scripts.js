// Enhanced Social Connection Handler
function initializeSocialConnections() {
    document.querySelectorAll('.connect-btn').forEach(btn => {
        btn.addEventListener('click', async function() {
            const card = this.closest('.social-account-card');
            const platform = card.dataset.platform;
            const isConnected = card.classList.contains('connected');
            
            // Add loading state
            this.classList.add('loading');
            this.innerHTML = '<i class="fas fa-spinner"></i><span>Connecting...</span>';
            
            try {
                if (isConnected) {
                    // Reconnect flow
                    await reconnectSocialAccount(platform, card);
                } else {
                    // Connect flow
                    await connectSocialAccount(platform, card);
                }
            } catch (error) {
                // Reset button on error
                this.classList.remove('loading');
                this.innerHTML = isConnected ? 
                    '<i class="fas fa-sync-alt"></i><span>Reconnect</span>' : 
                    '<i class="fas fa-link"></i><span>Connect</span>';
                
                showConnectionError(platform, error);
            }
        });
    });
}

async function connectSocialAccount(platform, card) {
    const api = window.SocialMediaAPI || new SocialMediaAPI();
    
    // Check premium status for connection
    if (!api.isPremium) {
        api.showPremiumWall('social-connections');
        throw new Error('Premium feature');
    }
    
    // Show connecting animation
    card.classList.add('connecting');
    
    // Simulate connection process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Update UI to connected state
    card.classList.add('connected');
    card.classList.remove('connecting');
    
    const statusElement = card.querySelector('.connection-status');
    statusElement.innerHTML = '<i class="fas fa-check-circle"></i><span>Connected</span>';
    statusElement.classList.add('connected');
    
    const platformInfo = card.querySelector('.platform-info p');
    platformInfo.textContent = `@${platform}_user`;
    platformInfo.classList.remove('text-gray-500');
    platformInfo.classList.add('text-green-600');
    
    // Update stats with realistic numbers
    const stats = card.querySelectorAll('.stat .number');
    if (stats.length >= 2) {
        stats[0].textContent = Math.floor(Math.random() * 50) + 10; // Posts
        stats[1].textContent = platform === 'instagram' ? 
            (Math.floor(Math.random() * 5000) + 1000).toLocaleString() : // Likes
            (Math.floor(Math.random() * 1000) + 100).toLocaleString(); // Engagement/Views
    }
    
    const btn = card.querySelector('.connect-btn');
    btn.classList.remove('loading');
    btn.innerHTML = '<i class="fas fa-sync-alt"></i><span>Reconnect</span>';
    
    // Update dashboard stats
    updateConnectedCount();
    
    // Show success message
    showConnectionSuccess(platform);
}

async function reconnectSocialAccount(platform, card) {
    // Show reconnecting animation
    card.classList.add('connecting');
    
    // Handle reconnection logic
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    card.classList.remove('connecting');
    
    const btn = card.querySelector('.connect-btn');
    btn.classList.remove('loading');
    btn.innerHTML = '<i class="fas fa-check"></i><span>Reconnected</span>';
    
    setTimeout(() => {
        btn.innerHTML = '<i class="fas fa-sync-alt"></i><span>Reconnect</span>';
    }, 2000);
    
    showToast(`${platform} reconnected successfully`, 'success');
}

function updateConnectedCount() {
    const connectedCards = document.querySelectorAll('.social-account-card.connected');
    const count = connectedCards.length;
    document.getElementById('connectedCount').textContent = count;
    
    // Update progress in the boost section
    const progressText = document.querySelector('.text-2xl.font-bold.text-blue-600');
    if (progressText) {
        progressText.textContent = `${count}/4`;
    }
    
    // Update other stats based on connections
    if (count > 0) {
        document.getElementById('postsCount').textContent = Math.floor(Math.random() * 100) + 10;
        document.getElementById('engagementRate').textContent = (Math.random() * 10 + 2).toFixed(1) + '%';
    }
}

function showConnectionSuccess(platform) {
    showToast(`Successfully connected to ${platform}`, 'success');
}

function showConnectionError(platform, error) {
    showToast(`Failed to connect to ${platform}`, 'error');
}

// Toast notification function
function showToast(message, type = 'info') {
    // Remove existing toasts
    document.querySelectorAll('.toast').forEach(toast => toast.remove());
    
    const toast = document.createElement('div');
    toast.className = `toast ${type} show`;
    toast.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Initialize when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    initializeSocialConnections();
    
    // Initialize API
    const api = new SocialMediaAPI();
    
    // Update generatePosts function to use API
    const generateContentBtn = document.getElementById('generateContentBtn');
    if (generateContentBtn) {
        generateContentBtn.addEventListener('click', async function() {
            const brandName = document.getElementById('brandName').value.trim();
            const postTopic = document.getElementById('postTopic').value.trim();
            const brandVoice = document.getElementById('brandVoice').value;
            const selectedPlatforms = getSelectedPlatforms();
            const autoPost = document.getElementById('autoPostToggle')?.checked || false;

            // Validation
            if (!brandName || !postTopic || selectedPlatforms.length === 0) {
                alert('Please fill in all required fields and select at least one platform.');
                return;
            }

            showLoading();

            try {
                const response = await api.generateContent({
                    brandName,
                    postTopic,
                    brandVoice,
                    platforms: selectedPlatforms,
                    quantity: parseInt(document.getElementById('postQuantity').value),
                    autoPost: autoPost
                });
                
                displayResults(response);
            } catch (error) {
                console.error('Generation failed:', error);
                alert('Failed to generate content. Please try again.');
            }
            
            hideLoading();
        });
    }
});

// Helper functions (keep your existing ones)
function getSelectedPlatforms() {
    // Your existing implementation
    const platformCheckboxes = document.querySelectorAll('.platforms input[type="checkbox"]:checked');
    return Array.from(platformCheckboxes).map(cb => cb.value);
}

function showLoading() {
    document.getElementById('loadingOverlay').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('hidden');
}

function displayResults(response) {
    // Your existing implementation
    const resultsSection = document.getElementById('generatedContent');
    const contentResults = document.getElementById('contentResults');
    
    if (resultsSection && contentResults) {
        contentResults.innerHTML = '';
        
        response.posts.forEach((post, index) => {
            const postElement = createPostElement(post, index);
            contentResults.appendChild(postElement);
        });
        
        resultsSection.classList.remove('hidden');
        resultsSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function createPostElement(post, index) {
    const postDiv = document.createElement('div');
    postDiv.className = 'post-card fade-in-up';
    postDiv.style.animationDelay = `${index * 0.1}s`;
    
    postDiv.innerHTML = `
        <div class="post-card-header">
            <span class="platform-badge ${post.platform}">${post.platform}</span>
            <div class="post-actions">
                <button class="action-btn copy-btn" onclick="copyToClipboard(this, ${index})">
                    <i class="fas fa-copy"></i> Copy
                </button>
                <button class="action-btn schedule-btn">
                    <i class="fas fa-calendar-plus"></i> Schedule
                </button>
            </div>
        </div>
        <div class="post-content">${post.content}</div>
        <div class="hashtags">
            ${post.hashtags.map(tag => `<span class="hashtag">${tag}</span>`).join('')}
        </div>
        <div class="hidden" id="postContent-${index}">${post.content}\n\n${post.hashtags.join(' ')}</div>
    `;
    
    return postDiv;
}

async function copyToClipboard(button, index) {
    const content = document.getElementById(`postContent-${index}`).textContent;
    
    try {
        await navigator.clipboard.writeText(content);
        
        // Visual feedback
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i> Copied!';
        button.classList.add('copied');
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.classList.remove('copied');
        }, 2000);
        
    } catch (err) {
        console.error('Failed to copy text: ', err);
        alert('Failed to copy text to clipboard. Please select and copy manually.');
    }
}