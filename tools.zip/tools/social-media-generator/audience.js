// target-audience.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded - initializing target audience');
    initializeTargetAudience();
});

function initializeTargetAudience() {
    console.log('Initializing target audience...');
    
    // Add click events to all interest items
    const interestItems = document.querySelectorAll('.interest-item');
    console.log('Found interest items:', interestItems.length);
    
    interestItems.forEach(item => {
        item.addEventListener('click', function(e) {
            console.log('Interest item clicked:', this);
            e.preventDefault();
            e.stopPropagation();
            toggleInterest(this);
        });
    });

    // Add interest button - DIRECT event listener
    const addInterestBtn = document.getElementById('addInterestBtn');
    if (addInterestBtn) {
        console.log('Add interest button found, adding click event');
        addInterestBtn.addEventListener('click', function(e) {
            console.log('Add interest button clicked!');
            e.preventDefault();
            e.stopPropagation();
            showAddInterestModal();
        });
    } else {
        console.error('Add interest button not found!');
    }

    // Age range change listener
    const ageRangeSelect = document.getElementById('ageRange');
    if (ageRangeSelect) {
        ageRangeSelect.addEventListener('change', updateAudienceSummary);
        console.log('Age range select found');
    }

    // Load saved audience preferences
    setTimeout(loadSavedAudience, 100);
}

function toggleInterest(interestItem) {
    console.log('Toggling interest:', interestItem);
    const checkbox = interestItem.querySelector('input[type="checkbox"]');
    if (!checkbox) {
        console.error('No checkbox found in interest item');
        return;
    }
    
    checkbox.checked = !checkbox.checked;
    updateInterestVisual(checkbox);
    updateAudienceSummary();
}

function updateInterestVisual(checkbox) {
    const interestItem = checkbox.closest('.interest-item');
    const checkIcon = interestItem.querySelector('.fa-check');
    const checkmarkDiv = interestItem.querySelector('.checkmark');
    
    if (checkbox.checked) {
        interestItem.classList.add('bg-blue-50', 'border-blue-300');
        checkIcon.classList.remove('hidden');
        checkmarkDiv.classList.add('bg-blue-600', 'border-blue-600');
        console.log('Interest selected:', checkbox.value);
    } else {
        interestItem.classList.remove('bg-blue-50', 'border-blue-300');
        checkIcon.classList.add('hidden');
        checkmarkDiv.classList.remove('bg-blue-600', 'border-blue-600');
        console.log('Interest deselected:', checkbox.value);
    }
}

function showAddInterestModal() {
    console.log('Showing add interest modal');
    
    // Create modal overlay
    const modalOverlay = document.createElement('div');
    modalOverlay.id = 'interestModalOverlay';
    modalOverlay.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modalOverlay.innerHTML = `
        <div class="bg-white p-6 rounded-2xl shadow-xl max-w-md w-full mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Add Custom Interest</h3>
                <button type="button" class="modal-close-btn text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="space-y-4">
                <div>
                    <label class="block font-medium mb-2">Interest Name</label>
                    <input type="text" class="custom-interest-input w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500" placeholder="Enter interest...">
                </div>
                <div class="flex space-x-2 pt-2">
                    <button type="button" class="modal-cancel-btn flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 py-2 px-4 rounded-lg transition">
                        Cancel
                    </button>
                    <button type="button" class="modal-add-btn flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition">
                        Add Interest
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalOverlay);

    // Focus on input immediately after adding to DOM
    const input = modalOverlay.querySelector('.custom-interest-input');
    if (input) {
        input.focus();
    }

    // Set up event listeners AFTER the modal is added to DOM
    setupModalEvents(modalOverlay);
}

function setupModalEvents(modalOverlay) {
    console.log('Setting up modal events');
    
    const closeModal = () => {
        console.log('Closing modal');
        modalOverlay.remove();
    };

    // Close button
    const closeBtn = modalOverlay.querySelector('.modal-close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
        console.log('Close button event attached');
    }

    // Cancel button
    const cancelBtn = modalOverlay.querySelector('.modal-cancel-btn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeModal);
        console.log('Cancel button event attached');
    }

    // Add interest button in modal
    const addBtn = modalOverlay.querySelector('.modal-add-btn');
    const input = modalOverlay.querySelector('.custom-interest-input');
    
    if (addBtn && input) {
        addBtn.addEventListener('click', function() {
            const interestName = input.value.trim();
            console.log('Modal add button clicked, interest name:', interestName);
            if (interestName) {
                addCustomInterest(interestName);
                closeModal();
            } else {
                input.focus();
                console.log('No interest name entered');
            }
        });
        console.log('Add button event attached');
    }

    // Enter key handler
    if (input) {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const interestName = input.value.trim();
                console.log('Enter key pressed, interest name:', interestName);
                if (interestName) {
                    addCustomInterest(interestName);
                    closeModal();
                }
            }
        });
        console.log('Enter key event attached');
    }

    // Click outside to close
    modalOverlay.addEventListener('click', function(e) {
        if (e.target === modalOverlay) {
            console.log('Clicked outside modal - closing');
            closeModal();
        }
    });

    console.log('All modal events attached successfully');
}

function addCustomInterest(interestName) {
    console.log('Adding custom interest:', interestName);
    
    const interestsContainer = document.getElementById('interestsContainer');
    if (!interestsContainer) {
        console.error('Interests container not found');
        return;
    }

    // Create new interest item
    const newInterest = document.createElement('label');
    newInterest.className = 'interest-item flex items-center space-x-2 p-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors';
    
    // Use the exact interest name for display and value
    newInterest.innerHTML = `
        <input type="checkbox" name="interests" value="${interestName.toLowerCase()}" class="hidden" checked>
        <div class="checkmark w-5 h-5 border-2 border-gray-300 rounded flex items-center justify-center transition-colors bg-blue-600 border-blue-600">
            <i class="fas fa-check text-white text-xs"></i>
        </div>
        <span class="text-sm select-none">${interestName}</span>
    `;

    // Add click event to the new interest
    newInterest.addEventListener('click', function(e) {
        console.log('New interest clicked:', this);
        e.preventDefault();
        e.stopPropagation();
        toggleInterest(this);
    });

    // Add to container (append to the end)
    interestsContainer.appendChild(newInterest);

    // Add the selected styles
    newInterest.classList.add('bg-blue-50', 'border-blue-300');
    
    console.log('Custom interest added successfully');
    updateAudienceSummary();
}

function updateAudienceSummary() {
    const summary = document.getElementById('audienceSummary');
    const summaryContent = document.getElementById('summaryContent');
    
    if (!summary || !summaryContent) {
        console.error('Summary elements not found');
        return;
    }

    const ageRange = document.getElementById('ageRange');
    const selectedInterests = Array.from(document.querySelectorAll('.interest-item input:checked'))
        .map(checkbox => {
            const span = checkbox.closest('.interest-item').querySelector('span');
            return span ? span.textContent : checkbox.value;
        });

    console.log('Updating summary. Selected interests:', selectedInterests);

    let summaryText = '';

    // Add age range
    if (ageRange && ageRange.value) {
        const ageText = ageRange.options[ageRange.selectedIndex].text;
        summaryText += `${ageText}`;
    }

    // Add interests
    if (selectedInterests.length > 0) {
        if (summaryText) summaryText += ' interested in ';
        summaryText += selectedInterests.join(', ');
    }

    if (summaryText) {
        summaryContent.textContent = summaryText;
        summary.classList.remove('hidden');
        
        // Update the hidden target audience input for compatibility
        const targetAudienceInput = document.getElementById('targetAudience');
        if (targetAudienceInput) {
            targetAudienceInput.value = summaryText;
        }
        
        console.log('Summary updated:', summaryText);
    } else {
        summary.classList.add('hidden');
        
        // Clear the hidden input
        const targetAudienceInput = document.getElementById('targetAudience');
        if (targetAudienceInput) {
            targetAudienceInput.value = '';
        }
    }

    // Save audience preferences
    saveAudiencePreferences();
}

function saveAudiencePreferences() {
    const ageRange = document.getElementById('ageRange');
    const selectedInterests = Array.from(document.querySelectorAll('.interest-item input:checked'))
        .map(checkbox => checkbox.value);

    const audienceData = {
        ageRange: ageRange ? ageRange.value : '',
        interests: selectedInterests
    };

    console.log('Saving audience preferences:', audienceData);

    // Save to localStorage
    const settings = JSON.parse(localStorage.getItem('socialGeniusSettings')) || {};
    settings.content = settings.content || {};
    settings.content.audience = audienceData;
    
    localStorage.setItem('socialGeniusSettings', JSON.stringify(settings));
}

function loadSavedAudience() {
    const settings = JSON.parse(localStorage.getItem('socialGeniusSettings'));
    if (!settings || !settings.content || !settings.content.audience) {
        console.log('No saved audience preferences found');
        return;
    }

    const savedAudience = settings.content.audience;
    console.log('Loading saved audience:', savedAudience);

    // Load age range
    if (savedAudience.ageRange) {
        const ageRangeSelect = document.getElementById('ageRange');
        if (ageRangeSelect) {
            ageRangeSelect.value = savedAudience.ageRange;
        }
    }

    // Load interests
    if (savedAudience.interests && savedAudience.interests.length > 0) {
        savedAudience.interests.forEach(interest => {
            const checkbox = document.querySelector(`.interest-item input[value="${interest}"]`);
            if (checkbox && !checkbox.checked) {
                checkbox.checked = true;
                updateInterestVisual(checkbox);
            }
        });
    }

    // Update summary
    updateAudienceSummary();
}

console.log('Target audience script loaded successfully');