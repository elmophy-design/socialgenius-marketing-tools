// interest-tags.js

document.addEventListener('DOMContentLoaded', function() {
    initializeInterestTags();
});

function initializeInterestTags() {
    // Get the interests container
    const interestsContainer = document.querySelector('.flex.flex-wrap.gap-2');
    if (!interestsContainer) return;

    // Add click event listeners to all existing interest tags
    const interestTags = interestsContainer.querySelectorAll('.interest-tag');
    interestTags.forEach(tag => {
        // Skip if it's already been processed
        if (tag.classList.contains('initialized')) return;
        
        makeTagToggleable(tag);
        tag.classList.add('initialized');
    });

    // Handle "Add Interest" button
    const addInterestBtn = interestsContainer.querySelector('button.text-blue-600');
    if (addInterestBtn && addInterestBtn.querySelector('.fa-plus')) {
        addInterestBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            showAddInterestModal(interestsContainer);
        });
    }

    // Load saved interests
    loadSavedInterests();
}

function makeTagToggleable(tag) {
    // Remove any existing × button if present
    const removeBtn = tag.querySelector('button');
    if (removeBtn) {
        removeBtn.remove();
    }

    // Clear any existing content and rebuild
    const tagText = tag.textContent.replace('×', '').trim();
    tag.innerHTML = tagText;
    
    // Add click event to toggle selection
    tag.style.cursor = 'pointer';
    tag.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        toggleTagSelection(this);
    });

    // Initialize as unselected
    tag.classList.remove('selected');
    
    // Add base styles
    tag.classList.add('bg-blue-50', 'text-blue-600', 'px-3', 'py-1', 'rounded-full', 'text-sm', 'flex', 'items-center', 'cursor-pointer', 'transition-all', 'duration-200', 'border', 'border-transparent');
}

function toggleTagSelection(tag) {
    tag.classList.toggle('selected');
    
    if (tag.classList.contains('selected')) {
        // Add checkmark icon
        if (!tag.querySelector('.fa-check')) {
            const checkIcon = document.createElement('i');
            checkIcon.className = 'fas fa-check ml-2 text-xs';
            tag.appendChild(checkIcon);
        }
        
        // Update visual style for selected state
        tag.classList.add('bg-blue-100', 'text-blue-700', 'border-blue-300');
        tag.classList.remove('bg-blue-50', 'text-blue-600');
    } else {
        // Remove checkmark icon
        const checkIcon = tag.querySelector('.fa-check');
        if (checkIcon) {
            checkIcon.remove();
        }
        
        // Revert to default style
        tag.classList.remove('bg-blue-100', 'text-blue-700', 'border-blue-300');
        tag.classList.add('bg-blue-50', 'text-blue-600');
    }

    // Save selected interests to settings
    saveSelectedInterests();
}

function showAddInterestModal(container) {
    // Create modal overlay
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modalOverlay.innerHTML = `
        <div class="bg-white p-6 rounded-2xl shadow-xl max-w-md w-full mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Add New Interest</h3>
                <button class="close-modal text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="space-y-4">
                <div>
                    <label class="block font-medium mb-2">Interest Name</label>
                    <input type="text" id="newInterestInput" 
                           class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500"
                           placeholder="Enter interest...">
                </div>
                <div class="flex space-x-2 pt-2">
                    <button class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 py-2 px-4 rounded-lg transition cancel-btn">
                        Cancel
                    </button>
                    <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition add-interest-btn">
                        Add Interest
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalOverlay);

    // Focus on input
    const input = modalOverlay.querySelector('#newInterestInput');
    input.focus();

    // Close modal handlers
    const closeModal = () => modalOverlay.remove();
    
    modalOverlay.querySelector('.close-modal').addEventListener('click', closeModal);
    modalOverlay.querySelector('.cancel-btn').addEventListener('click', closeModal);
    
    // Click outside to close
    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) closeModal();
    });

    // Add interest handler
    modalOverlay.querySelector('.add-interest-btn').addEventListener('click', function() {
        const interestName = input.value.trim();
        if (interestName) {
            addNewInterest(interestName, container);
            closeModal();
        } else {
            input.focus();
        }
    });

    // Enter key handler
    input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const interestName = input.value.trim();
            if (interestName) {
                addNewInterest(interestName, container);
                closeModal();
            }
        }
    });
}

function addNewInterest(interestName, container) {
    // Create new interest tag
    const newTag = document.createElement('span');
    newTag.className = 'interest-tag bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-sm flex items-center cursor-pointer transition-all duration-200 border border-transparent';
    newTag.textContent = interestName;
    newTag.classList.add('initialized');
    
    // Make it toggleable
    makeTagToggleable(newTag);
    
    // Insert before the "Add Interest" button
    const addButton = container.querySelector('button.text-blue-600');
    if (addButton) {
        container.insertBefore(newTag, addButton);
    } else {
        container.appendChild(newTag);
    }
    
    // Save to settings
    saveSelectedInterests();
}

function saveSelectedInterests() {
    // Get all selected interests
    const selectedTags = document.querySelectorAll('.interest-tag.selected');
    const selectedInterests = Array.from(selectedTags).map(tag => {
        const text = tag.cloneNode(true);
        const checkIcon = text.querySelector('.fa-check');
        if (checkIcon) checkIcon.remove();
        return text.textContent.trim();
    });
    
    // Save to localStorage
    const settings = JSON.parse(localStorage.getItem('socialGeniusSettings')) || {};
    settings.content = settings.content || {};
    settings.content.selectedInterests = selectedInterests;
    
    localStorage.setItem('socialGeniusSettings', JSON.stringify(settings));
    
    console.log('Saved interests:', selectedInterests);
}

function loadSavedInterests() {
    const settings = JSON.parse(localStorage.getItem('socialGeniusSettings'));
    if (!settings || !settings.content || !settings.content.selectedInterests) return;
    
    const savedInterests = settings.content.selectedInterests;
    const interestTags = document.querySelectorAll('.interest-tag');
    
    interestTags.forEach(tag => {
        const tagText = tag.textContent.replace('✓', '').trim();
        if (savedInterests.includes(tagText)) {
            // Force select the tag
            if (!tag.classList.contains('selected')) {
                toggleTagSelection(tag);
            }
        }
    });
}

// Re-initialize when navigating back to the page
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeInterestTags);
} else {
    initializeInterestTags();
}