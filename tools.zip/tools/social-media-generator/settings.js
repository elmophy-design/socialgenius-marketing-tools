// settings.js - SocialGenius Settings - Complete Rewrite with Profile Sync

class SettingsManager {
    constructor() {
        this.currentSection = 'account';
        this.socialAccounts = {
            'Instagram': { connected: true },
            'TikTok': { connected: false },
            'Twitter': { connected: true },
            'LinkedIn': { connected: false },
            'Facebook': { connected: true }
        };
        this.securitySettings = {
            twoFactorEnabled: false,
            connectedDevices: [
                { id: 1, name: 'Chrome on Windows', lastActive: new Date().toISOString(), current: true },
                { id: 2, name: 'Safari on iPhone', lastActive: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), current: false },
                { id: 3, name: 'Firefox on Mac', lastActive: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), current: false }
            ]
        };
        this.init();
    }

    init() {
        this.loadAllSettings();
        this.initializeNavigation();
        this.initializeImageUpload();
        this.initializeFormInteractions();
        this.initializeToggleSwitches();
        this.initializeModals();
        this.initializeUserData();
        this.initializeEventListeners();
        this.initializePostingScheduling();
        this.updateAllDisplays();
        
        // NEW: Initialize profile sync features
        this.initializeNameEditing();
        this.initializeProfilePictureSync();
        
        // NEW: Initialize default author name editing
        this.initializeDefaultAuthorNameEditing();
        
        // Handle initial hash navigation
        this.handleInitialHashNavigation();
    }

    handleInitialHashNavigation() {
        // Wait for DOM to be fully ready
        setTimeout(() => {
            if (window.location.hash) {
                const sectionId = window.location.hash.substring(1);
                this.switchToSection(sectionId);
            }
        }, 300);
    }

    // Data Management
    loadAllSettings() {
        const savedAccounts = localStorage.getItem('socialgenius_social_accounts');
        if (savedAccounts) this.socialAccounts = JSON.parse(savedAccounts);

        const savedSecurity = localStorage.getItem('socialgenius_security');
        if (savedSecurity) this.securitySettings = JSON.parse(savedSecurity);

        const savedSettings = localStorage.getItem('socialgenius_settings');
        if (savedSettings) this.settings = JSON.parse(savedSettings);
    }

    saveAllSettings() {
        localStorage.setItem('socialgenius_social_accounts', JSON.stringify(this.socialAccounts));
        localStorage.setItem('socialgenius_security', JSON.stringify(this.securitySettings));
        localStorage.setItem('socialgenius_settings', JSON.stringify(this.settings || {}));
    }

    updateAllDisplays() {
        this.updateSocialAccountDisplays();
        this.updateSecurityDisplays();
    }

    // Navigation System - UPDATED VERSION
    initializeNavigation() {
        document.querySelectorAll('.settings-nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const sectionId = item.getAttribute('href').substring(1);
                this.switchToSection(sectionId);
                
                // Update URL hash without page reload
                window.history.pushState(null, null, `#${sectionId}`);
            });
        });

        // Handle browser back/forward buttons
        window.addEventListener('popstate', () => {
            if (window.location.hash) {
                const sectionId = window.location.hash.substring(1);
                this.switchToSection(sectionId);
            }
        });

        // Check for hash on page load
        if (window.location.hash) {
            const sectionId = window.location.hash.substring(1);
            setTimeout(() => {
                this.switchToSection(sectionId);
            }, 100);
        }
    }

    switchToSection(sectionId) {
        // Validate section exists
        const targetSection = document.getElementById(sectionId);
        if (!targetSection) {
            console.warn(`Section ${sectionId} not found`);
            return;
        }

        // Update navigation
        document.querySelectorAll('.settings-nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const targetNav = document.querySelector(`[href="#${sectionId}"]`);
        if (targetNav) {
            targetNav.classList.add('active');
        }

        // Update sections
        document.querySelectorAll('.settings-section').forEach(section => {
            section.classList.remove('active');
        });
        
        targetSection.classList.add('active');
        this.currentSection = sectionId;

        // Scroll to top of section
        targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // Image Upload System - ENHANCED WITH PROFILE SYNC
    initializeImageUpload() {
        this.setupImageUpload('account', 'profile');
        this.setupImageUpload('media', 'logo');
        this.loadSavedImages();
    }

    setupImageUpload(section, type) {
        const uploadBtn = document.querySelector(`#${section} .bg-blue-600`);
        const removeBtn = document.querySelector(`#${section} .text-gray-600`);
        const preview = document.querySelector(`#${section} .w-16.h-16`);

        uploadBtn?.addEventListener('click', () => this.uploadImage(type, preview));
        removeBtn?.addEventListener('click', () => this.removeImage(type, preview));
    }

    uploadImage(type, previewElement) {
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/jpeg,image/png,image/gif,image/webp';
        fileInput.style.display = 'none';

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file && this.validateImageFile(file)) {
                this.processImageUpload(file, type, previewElement);
            }
            fileInput.remove();
        });

        document.body.appendChild(fileInput);
        fileInput.click();
    }

    validateImageFile(file) {
        const maxSize = 5 * 1024 * 1024;
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

        if (!allowedTypes.includes(file.type)) {
            this.showNotification('Please select a valid image file (JPEG, PNG, GIF, or WebP)', 'error');
            return false;
        }

        if (file.size > maxSize) {
            this.showNotification('Image size must be less than 5MB', 'error');
            return false;
        }

        return true;
    }

   processImageUpload(file, type, previewElement) {
        // Show uploading notification and store reference
        const uploadingNotification = document.createElement('div');
        uploadingNotification.className = 'notification info fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 flex items-center gap-3';
        uploadingNotification.innerHTML = `
            <i class="fas fa-info-circle text-white text-lg"></i>
            <span class="text-white font-medium">Uploading ${type} image...</span>
        `;
        document.body.appendChild(uploadingNotification);
        setTimeout(() => uploadingNotification.classList.add('show'), 100);
        
        const originalContent = previewElement.innerHTML;
        previewElement.innerHTML = this.createLoadingSpinner();

        const reader = new FileReader();
        
        reader.onload = (e) => {
            // Remove uploading notification with animation
            uploadingNotification.classList.remove('show');
            setTimeout(() => {
                if (uploadingNotification.parentNode) {
                    uploadingNotification.remove();
                }
                
                // Now show success notification
                this.setImagePreview(previewElement, e.target.result, type);
                this.saveImage(type, e.target.result);
                this.showNotification(`${this.capitalize(type)} image uploaded successfully!`, 'success');
            }, 300);
        };
        
        reader.onerror = () => {
            // Remove uploading notification with animation
            uploadingNotification.classList.remove('show');
            setTimeout(() => {
                if (uploadingNotification.parentNode) {
                    uploadingNotification.remove();
                }
                
                previewElement.innerHTML = originalContent;
                this.showNotification('Error uploading image. Please try again.', 'error');
            }, 300);
        };
        
        reader.readAsDataURL(file);
    }

    setImagePreview(previewElement, imageData, type) {
        const img = document.createElement('img');
        img.src = imageData;
        img.className = type === 'profile' 
            ? 'w-full h-full object-cover rounded-full' 
            : 'w-full h-full object-cover rounded-lg';
        img.alt = `${type} image`;
        
        previewElement.innerHTML = '';
        previewElement.appendChild(img);
    }

    removeImage(type, previewElement) {
        this.showConfirmationModal(
            `Remove ${this.capitalize(type)}`,
            `Are you sure you want to remove your ${type}?`,
            'Remove',
            () => {
                const defaultIcon = type === 'profile' 
                    ? '<i class="fas fa-user text-gray-400 text-2xl"></i>'
                    : '<i class="fas fa-image text-gray-400"></i>';
                
                previewElement.innerHTML = defaultIcon;
                localStorage.removeItem(`socialgenius_${type}_image`);
                
                // NEW: Update profile picture across app if it's a profile image
                if (type === 'profile') {
                    this.updateProfilePictureAcrossApp(null);
                }
                
                this.showNotification(`${this.capitalize(type)} removed`, 'info');
            }
        );
    }

    loadSavedImages() {
        ['profile', 'logo'].forEach(type => {
            const savedImage = localStorage.getItem(`socialgenius_${type}_image`);
            const preview = document.querySelector(`#${type === 'profile' ? 'account' : 'media'} .w-16.h-16`);
            
            if (savedImage && preview) {
                this.setImagePreview(preview, savedImage, type);
            }
            
            // NEW: Also update view profile modal if it's a profile image
            if (type === 'profile' && savedImage) {
                this.updateViewProfilePicture(savedImage);
            }
        });
    }

    // ENHANCED: Save image with profile sync
    saveImage(type, imageData) {
        localStorage.setItem(`socialgenius_${type}_image`, imageData);
        
        // NEW: Update profile picture across the entire application
        if (type === 'profile') {
            this.updateProfilePictureAcrossApp(imageData);
        }
    }

    // NEW: Profile Picture Sync Methods
    updateProfilePictureAcrossApp(imageData) {
        // Update in settings page
        this.updateSettingsProfilePicture(imageData);
        
        // Update in view profile modal
        this.updateViewProfilePicture(imageData);
        
        // Update in navigation/dropdown
        this.updateNavigationProfilePicture(imageData);
        
        // Show notification
        this.showNotification('success');
    }

    updateSettingsProfilePicture(imageData) {
        const profilePreviews = document.querySelectorAll('.profile-picture, .profile-picture-large, .w-16.h-16 img');
        profilePreviews.forEach(preview => {
            if (preview.tagName === 'IMG') {
                preview.src = imageData;
            } else {
                // If it's a container, update its content
                preview.innerHTML = '';
                const img = document.createElement('img');
                img.src = imageData;
                img.className = 'w-full h-full object-cover rounded-full';
                img.alt = 'Profile picture';
                preview.appendChild(img);
            }
        });
    }

    updateViewProfilePicture(imageData) {
        const profilePictureLarge = document.getElementById('profilePictureLarge');
        if (profilePictureLarge) {
            profilePictureLarge.innerHTML = '';
            if (imageData) {
                const img = document.createElement('img');
                img.src = imageData;
                img.className = 'w-full h-full object-cover rounded-full';
                img.alt = 'Profile picture';
                profilePictureLarge.appendChild(img);
            } else {
                // Show default icon if no image
                profilePictureLarge.innerHTML = '<i class="fas fa-user text-white text-2xl"></i>';
            }
        }
    }

    updateNavigationProfilePicture(imageData) {
        // Update in profile dropdown if exists
        const dropdownProfilePictures = document.querySelectorAll('#profilePicture, #profilePictureSmall, .profile-picture-small');
        dropdownProfilePictures.forEach(picture => {
            if (picture.tagName === 'IMG') {
                picture.src = imageData;
            } else if (imageData) {
                picture.innerHTML = '';
                const img = document.createElement('img');
                img.src = imageData;
                img.className = 'w-full h-full object-cover rounded-full';
                img.alt = 'Profile picture';
                picture.appendChild(img);
            }
        });
    }

    // NEW: Profile Picture Sync Initialization
    initializeProfilePictureSync() {
        // Listen for view profile modal opening
        document.addEventListener('click', (e) => {
            if (e.target.closest('#viewProfileBtn') || e.target.id === 'viewProfileBtn') {
                // Load the latest profile data when view profile is opened
                setTimeout(() => {
                    this.loadProfilePictureInViewModal();
                    this.loadUserDataInViewModal();
                }, 100);
            }
        });
        
        // Also listen for modal show events
        const profileModal = document.getElementById('profileModal');
        if (profileModal) {
            // Use MutationObserver to detect when modal becomes visible
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                        if (profileModal.classList.contains('show')) {
                            this.loadProfilePictureInViewModal();
                            this.loadUserDataInViewModal();
                        }
                    }
                });
            });
            
            observer.observe(profileModal, { attributes: true });
        }
    }

    loadProfilePictureInViewModal() {
        const savedProfileImage = localStorage.getItem('socialgenius_profile_image');
        if (savedProfileImage) {
            this.updateViewProfilePicture(savedProfileImage);
        }
    }

    // NEW: User Name Management Methods
    initializeUserData() {
        const userEmail = localStorage.getItem('userEmail') || 'user@example.com';
        const userName = localStorage.getItem('userName') || 'Prime Alpha';
        const authorName = localStorage.getItem('defaultAuthorName') || userName;
        
        const userEmailElement = document.getElementById('userEmail');
        const userNameElement = document.getElementById('userName');
        
        if (userEmailElement) {
            userEmailElement.textContent = userEmail;
        }
        if (userNameElement) {
            userNameElement.textContent = userName;
        }
        
        // NEW: Also update view profile if it exists
        this.updateViewProfileName(userName);
        
        // NEW: Update default author name to match username
        this.updateDefaultAuthorName(userName);
        
        // NEW: Initialize default author name editing
        this.initializeDefaultAuthorNameEditing();
        
        // NEW: Also update view profile with current author name
        this.updateViewProfileAuthorName(authorName);
    }

    // NEW: Method to update user name across the entire application
    updateUserNameAcrossApp(newName) {
        // Save to localStorage
        localStorage.setItem('userName', newName);
        
        // Update in settings page
        this.updateSettingsUserName(newName);
        
        // Update in view profile modal
        this.updateViewProfileName(newName);
        
        // Update in navigation/dropdown
        this.updateNavigationUserName(newName);
        
        // NEW: Only update author name if it hasn't been customized
        const currentAuthorName = localStorage.getItem('defaultAuthorName');
        if (!currentAuthorName || currentAuthorName === this.getCurrentAuthorName()) {
            this.updateAuthorNameAcrossApp(newName);
        }
        
        // Show notification
        this.showNotification('Profile name updated across all areas!', 'success');
    }

    // NEW: Update default author name to match username
    updateDefaultAuthorName(userName) {
        // Use username as default author name
        localStorage.setItem('defaultAuthorName', userName);
        
        // Update any default author name fields in the UI
        this.refreshDefaultAuthorNames();
    }

    // NEW: Refresh default author name displays
    refreshDefaultAuthorNames() {
        const authorName = localStorage.getItem('defaultAuthorName') || localStorage.getItem('userName') || 'Prime Alpha';
        
        // Update default author name input fields
        const authorNameInputs = document.querySelectorAll('input[data-default-author], input[placeholder*="Author"], input[value*="SocialGenius"]');
        authorNameInputs.forEach(input => {
            if (input.type === 'text' || input.type === 'hidden') {
                input.value = authorName;
            }
        });
        
        // Update any other instances of default author name
        const authorNameElements = document.querySelectorAll('[data-default-author], .default-author-name');
        authorNameElements.forEach(element => {
            if (element.tagName !== 'INPUT') {
                element.textContent = authorName;
            }
        });
    }

    
    // NEW: Initialize default author name editing with small save button
    initializeDefaultAuthorNameEditing() {
        const authorNameInput = document.getElementById('defaultAuthorName');
        if (authorNameInput) {
            // Check if save button already exists to prevent duplicates
            const existingSaveButton = authorNameInput.parentNode.querySelector('.save-button-container');
            if (existingSaveButton) {
                existingSaveButton.remove(); // Remove existing save button
            }
            
            // Load current display name
            const currentDisplayName = localStorage.getItem('defaultAuthorName') || localStorage.getItem('userName') || 'Prime Alpha';
            authorNameInput.value = currentDisplayName;
            
            // Update label
            const label = authorNameInput.previousElementSibling;
            if (label && label.tagName === 'LABEL') {
                label.textContent = 'Display Name';
                label.innerHTML += '<span class="text-red-500 ml-1">*</span>';
            }
            
            // Add helpful description (only if it doesn't exist)
            const existingHelpText = authorNameInput.parentNode.querySelector('.help-text');
            if (!existingHelpText) {
                const helpText = document.createElement('p');
                helpText.className = 'help-text text-sm text-gray-600 mt-1';
                helpText.textContent = 'This name will be displayed in your profile, posts, and across the application.';
                authorNameInput.parentNode.appendChild(helpText);
            }
            
            // Create save button container with smaller button
            const saveButtonContainer = document.createElement('div');
            saveButtonContainer.className = 'save-button-container mt-2 flex justify-end';
            saveButtonContainer.innerHTML = `
                <button type="button" 
                        class="save-display-name-btn px-4 py-1.5 bg-gray-400 text-white rounded-lg transition font-medium flex items-center justify-center space-x-2 cursor-not-allowed text-sm"
                        disabled>
                    <i class="fas fa-save text-xs"></i>
                    <span>Save</span>
                </button>
            `;
            
            authorNameInput.parentNode.appendChild(saveButtonContainer);
            
            const saveButton = saveButtonContainer.querySelector('.save-display-name-btn');
            let originalValue = currentDisplayName;
            
            // Enable/disable save button based on changes
            authorNameInput.addEventListener('input', (e) => {
                const currentValue = e.target.value.trim();
                const hasChanges = currentValue !== originalValue && currentValue.length > 0;
                
                if (hasChanges) {
                    saveButton.disabled = false;
                    saveButton.classList.remove('bg-gray-400', 'cursor-not-allowed');
                    saveButton.classList.add('bg-blue-600', 'hover:bg-blue-700', 'cursor-pointer');
                } else {
                    saveButton.disabled = true;
                    saveButton.classList.add('bg-gray-400', 'cursor-not-allowed');
                    saveButton.classList.remove('bg-blue-600', 'hover:bg-blue-700', 'cursor-pointer');
                }
            });
            
            // Save on Enter key
            authorNameInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !saveButton.disabled) {
                    e.preventDefault();
                    saveButton.click();
                }
            });
            
            // Save button click handler
            saveButton.addEventListener('click', () => {
                const newName = authorNameInput.value.trim();
                
                if (!newName) {
                    this.showNotification('Please enter a valid display name', 'error');
                    return;
                }
                
                if (newName.length > 50) {
                    this.showNotification('Display name must be 50 characters or less', 'error');
                    return;
                }
                
                // Show loading state
                saveButton.disabled = true;
                saveButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Saving...';
                saveButton.classList.remove('bg-blue-600', 'hover:bg-blue-700');
                saveButton.classList.add('bg-gray-400');
                
                // Simulate API call
                setTimeout(() => {
                    this.updateAuthorNameAcrossApp(newName);
                    
                    // Update original value
                    originalValue = newName;
                    
                    // Reset button to disabled state
                    saveButton.disabled = true;
                    saveButton.innerHTML = '<i class="fas fa-save text-xs"></i><span>Save</span>';
                    saveButton.classList.add('bg-gray-400', 'cursor-not-allowed');
                    saveButton.classList.remove('bg-blue-600', 'hover:bg-blue-700', 'cursor-pointer');
                    
                    this.showNotification('Display name updated successfully!', 'success');
                    
                    // Revert button text after 2 seconds
                    setTimeout(() => {
                        saveButton.innerHTML = '<i class="fas fa-save text-xs"></i><span>Save</span>';
                        saveButton.classList.remove('bg-green-500');
                        saveButton.classList.add('bg-gray-400');
                    }, 2000);
                    
                }, 100);
            });
        }
    }

    // NEW: Get current author name
    getCurrentAuthorName() {
        return localStorage.getItem('defaultAuthorName') || localStorage.getItem('userName') || 'Prime Alpha';
    }

    // In SettingsManager - update this method
    updateAuthorNameAcrossApp(newAuthorName) {
        if (!newAuthorName) {
            this.showNotification('Please enter a valid author name', 'error');
            return;
        }
        
        // Save to localStorage
        localStorage.setItem('defaultAuthorName', newAuthorName);
        localStorage.setItem('userName', newAuthorName); 
        
        // Update the input field
        const authorNameInput = document.getElementById('defaultAuthorName');
        if (authorNameInput && authorNameInput.value !== newAuthorName) {
            authorNameInput.value = newAuthorName;
        }
        
        // Update View Profile display
        this.updateViewProfileAuthorName(newAuthorName);
        this.updateViewProfileName(newAuthorName); 
        
        // Update Profile Dropdown display
        this.updateProfileDropdownAuthorName(newAuthorName);
        
        // Update any other author name displays
        this.refreshAuthorNameDisplays(newAuthorName);

        // Update settings page user name display
        this.updateSettingsUserName(newAuthorName);
        
        // NEW: Trigger the global profile sync to update View Profile modal
        if (window.updateUserProfileNameEverywhere) {
            window.updateUserProfileNameEverywhere(newAuthorName);
        }

        
        
        this.showNotification('Author name updated across all areas!', 'success');
    }
    // NEW: Update author name in View Profile
    updateViewProfileAuthorName(authorName) {
        // Update the main profile name display
        const profileNameDisplay = document.getElementById('profileNameDisplay');
        if (profileNameDisplay) {
            profileNameDisplay.textContent = authorName;
        }
        
        // Also update any author-specific displays in view profile
        const authorNameElements = document.querySelectorAll('#profileModal [data-author-name], #profileModal .author-name');
        authorNameElements.forEach(element => {
            element.textContent = authorName;
        });
    }

    // NEW: Update author name in Profile Dropdown
    updateProfileDropdownAuthorName(authorName) {
        const dropdownUserName = document.getElementById('dropdownUserName');
        if (dropdownUserName) {
            dropdownUserName.textContent = authorName;
        }
        
        // Update any other dropdown elements
        const dropdownAuthorElements = document.querySelectorAll('.profile-dropdown [data-author-name], .profile-dropdown .user-name');
        dropdownAuthorElements.forEach(element => {
            element.textContent = authorName;
        });
    }

    // NEW: Refresh all author name displays
    refreshAuthorNameDisplays(authorName) {
        // Update all elements with author name data attributes
        const authorNameElements = document.querySelectorAll('[data-author-name], .default-author-name');
        authorNameElements.forEach(element => {
            if (element.tagName !== 'INPUT') {
                element.textContent = authorName;
            }
        });
        
        // Update input fields that should show author name
        const authorNameInputs = document.querySelectorAll('input[data-default-author]');
        authorNameInputs.forEach(input => {
            if (input.id !== 'defaultAuthorName') {
                input.value = authorName;
            }
        });
    }

    updateSettingsUserName(newName) {
        const userNameElements = document.querySelectorAll('#userName, .user-name, [data-user-name]');
        userNameElements.forEach(element => {
            element.textContent = newName;
        });
    }

    updateViewProfileName(newName) {
        const profileNameDisplay = document.getElementById('profileNameDisplay');
        if (profileNameDisplay) {
            profileNameDisplay.textContent = newName;
        }
    }

    updateNavigationUserName(newName) {
        const dropdownUserName = document.getElementById('dropdownUserName');
        if (dropdownUserName) {
            dropdownUserName.textContent = newName;
        }
        
        // Also update any other navigation elements
        const navUserNames = document.querySelectorAll('.nav-user-name, [data-nav-user]');
        navUserNames.forEach(element => {
            element.textContent = newName;
        });
    }

    // NEW: Load user data in view profile modal
    loadUserDataInViewModal() {
        const savedName = localStorage.getItem('userName') || 'Prime Alpha';
        const savedEmail = localStorage.getItem('userEmail') || 'user@example.com';
        const savedAuthorName = localStorage.getItem('defaultAuthorName') || savedName;
        
        this.updateViewProfileName(savedName);
        this.updateViewProfileAuthorName(savedAuthorName);
        
        const profileEmailDisplay = document.getElementById('profileEmailDisplay');
        if (profileEmailDisplay) {
            profileEmailDisplay.textContent = savedEmail;
        }
    }

    // NEW: Name Editing Functionality
    initializeNameEditing() {
        const nameEditBtn = document.querySelector('#account .text-blue-600');
        if (nameEditBtn && nameEditBtn.textContent.includes('Edit')) {
            nameEditBtn.addEventListener('click', () => {
                this.showNameEditModal();
            });
        }
    }

    // Name edit modal
    showNameEditModal() {
        const currentName = localStorage.getItem('userName') || 'Prime Alpha';
        
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">Edit Profile Name</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                        <input type="text" 
                               id="nameEditInput" 
                               value="${currentName}" 
                               class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               placeholder="Enter your full name"
                               maxlength="50">
                        <div class="text-right mt-1">
                            <span class="text-xs text-gray-500">
                                <span id="nameCharCount">${currentName.length}</span>/50 characters
                            </span>
                        </div>
                    </div>
                    
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-info-circle text-blue-500 text-lg mr-3 mt-0.5"></i>
                            <div>
                                <h4 class="font-medium text-blue-800 mb-1">Profile Name</h4>
                                <p class="text-sm text-blue-700">
                                    This name will be displayed in your profile, navigation, and across the application. It will also be used as your default author name for posts unless you customize it separately.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Cancel
                    </button>
                    <button onclick="settingsManager.saveUserName(this)" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                        Save Changes
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
        this.initializeNameInputValidation();
    }

    // Initialize name input validation
    initializeNameInputValidation() {
        const nameInput = document.getElementById('nameEditInput');
        const charCount = document.getElementById('nameCharCount');
        
        if (nameInput && charCount) {
            nameInput.addEventListener('input', (e) => {
                const value = e.target.value;
                charCount.textContent = value.length;
                
                // Basic validation - ensure name is not empty
                const saveButton = document.querySelector('.modal-content button.bg-blue-600');
                if (saveButton) {
                    saveButton.disabled = value.trim().length === 0;
                }
            });
            
            // Focus the input
            setTimeout(() => {
                nameInput.focus();
                nameInput.select();
            }, 100);
        }
    }

    // Save user name
    saveUserName(button) {
        const nameInput = document.getElementById('nameEditInput');
        const newName = nameInput?.value.trim();
        
        if (!newName) {
            this.showNotification('Please enter a valid name', 'error');
            return;
        }
        
        if (newName.length > 50) {
            this.showNotification('Name must be 50 characters or less', 'error');
            return;
        }
        
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';
        
        // Simulate API call
        setTimeout(() => {
            this.updateUserNameAcrossApp(newName);
            this.closeModal();
            
            // Reset button state
            button.disabled = false;
            button.textContent = 'Save Changes';
        }, 1000);
    }


    // Social Account Management
    updateSocialAccountDisplays() {
        Object.keys(this.socialAccounts).forEach(platform => {
            const account = this.findSocialAccountElement(platform);
            if (account) {
                this.updateAccountDisplay(account, platform);
            }
        });
    }

    findSocialAccountElement(platform) {
        const accounts = document.querySelectorAll('.social-account-setting');
        for (let account of accounts) {
            if (account.querySelector('span').textContent === platform) {
                return account;
            }
        }
        return null;
    }

    updateAccountDisplay(account, platform) {
        const statusText = account.querySelector('.status-text');
        const button = account.querySelector('button');
        const isConnected = this.socialAccounts[platform].connected;

        if (isConnected) {
            statusText.textContent = 'Connected';
            statusText.className = 'status-text bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium';
            button.textContent = 'Manage';
        } else {
            statusText.textContent = 'Not Connected';
            statusText.className = 'status-text bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-medium';
            button.textContent = 'Connect';
        }
    }

    handleSocialAccountClick(platform, button) {
        console.log(`Handling click for ${platform}`); // Debug log
        
        // SAFE ACCESS with optional chaining and default
        const accountData = this.socialAccounts[platform];
        const isConnected = this.socialAccounts[platform]?.connected || false;
        
        console.log(`${platform} connected status:`, isConnected); // Debug log
        console.log('Account data:', accountData); // Debug log
        
        if (!isConnected) {
            this.connectSocialAccount(platform, button);
        } else {
            this.showAccountManagementModal(platform);
        }
    }

    connectSocialAccount(platform, button) {
    const account = button.closest('.social-account-setting');
    if (!account) {
        console.error('Could not find account element');
        return;
    }
    
    const statusText = account.querySelector('.status-text');
    if (!statusText) {
        console.error('Could not find status text element');
        return;
    }
    
    // Show connecting state
    button.disabled = true;
    button.textContent = 'Connecting...';
    statusText.textContent = 'Connecting...';
    statusText.className = 'status-text bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium';

    // Simulate connection process
    setTimeout(() => {
        // FIX: Ensure the platform object exists and has connected property
        if (!this.socialAccounts[platform]) {
            this.socialAccounts[platform] = {};
        }
        this.socialAccounts[platform].connected = true;
        
        this.saveAllSettings();
        this.updateAccountDisplay(account, platform);
        button.disabled = false;
        this.showNotification(`${platform} connected successfully!`, 'success');
    }, 2000);
}

    disconnectSocialAccount(platform) {
        this.socialAccounts[platform].connected = false;
        this.saveAllSettings();
        
        const account = this.findSocialAccountElement(platform);
        if (account) {
            this.updateAccountDisplay(account, platform);
        }
        
        this.showNotification(`${platform} disconnected successfully`, 'info');
    }

    // Security Features
    updateSecurityDisplays() {
        this.update2FADisplay();
        this.updateConnectedDevicesDisplay();
    }

    update2FADisplay() {
        const twoFactorBtn = document.querySelector('.bg-gray-50 button.text-blue-600:nth-child(2)');
        if (twoFactorBtn) {
            twoFactorBtn.textContent = this.securitySettings.twoFactorEnabled ? 'Manage' : 'Enable';
            twoFactorBtn.classList.toggle('text-blue-600', !this.securitySettings.twoFactorEnabled);
            twoFactorBtn.classList.toggle('text-green-600', this.securitySettings.twoFactorEnabled);
        }
    }


    updateConnectedDevicesDisplay() {
        const devicesBtn = document.querySelector('.bg-gray-50 button.text-blue-600:nth-child(3)');
        if (devicesBtn) {
            const activeDevices = this.securitySettings.connectedDevices.length;
            devicesBtn.textContent = `Manage (${activeDevices})`;
        }
    }

    // Two-Factor Authentication System
    initialize2FA() {
        const enable2faBtn = document.getElementById('enable2faBtn');
        const cancel2faBtn = document.getElementById('cancel2faBtn');
        const closeModalBtns = document.querySelectorAll('.close-modal');
        const enable2faConfirmBtn = document.getElementById('enable2faConfirmBtn');
        
        // Authentication method sections
        const appAuthSection = document.getElementById('appAuthSection');
        const smsAuthSection = document.getElementById('smsAuthSection');
        const emailAuthSection = document.getElementById('emailAuthSection');
        
        // Open Two-Factor Authentication Modal
        if (enable2faBtn) {
            enable2faBtn.addEventListener('click', () => {
                this.show2FAModal();
            });
        }
        
        // Close Modal with Cancel Button
        if (cancel2faBtn) {
            cancel2faBtn.addEventListener('click', () => {
                this.closeModal();
            });
        }
        
        // Close Modal with Close Button
        closeModalBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeModal();
            });
        });
        
        // Handle authentication method selection
        const authMethods = document.querySelectorAll('input[name="auth-method"]');
        authMethods.forEach(method => {
            method.addEventListener('change', function() {
                // Hide all sections first
                appAuthSection?.classList.add('hidden');
                smsAuthSection?.classList.add('hidden');
                emailAuthSection?.classList.add('hidden');
                
                // Show selected section
                if (this.value === 'app') {
                    appAuthSection?.classList.remove('hidden');
                } else if (this.value === 'sms') {
                    smsAuthSection?.classList.remove('hidden');
                } else if (this.value === 'email') {
                    emailAuthSection?.classList.remove('hidden');
                }
            });
        });
        
        // Enable 2FA Confirmation
        if (enable2faConfirmBtn) {
            enable2faConfirmBtn.addEventListener('click', () => {
                this.enable2FA();
            });
        }
    }

    show2FAModal() {
        if (this.securitySettings.twoFactorEnabled) {
            this.show2FAManagementModal();
        } else {
            this.show2FASetupModal();
        }
    }

    show2FASetupModal() {
        const userEmail = localStorage.getItem('userEmail') || 'user@example.com';
        const userPhone = localStorage.getItem('userPhone') || '+1 (555) 123-4567';
        
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">Setup Two-Factor Authentication</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-4">
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <h4 class="text-sm font-medium text-blue-800 mb-1">What is 2FA?</h4>
                        <p class="text-xs text-blue-600">
                            Two-factor authentication adds an extra layer of security to your account by requiring a verification code when you sign in.
                        </p>
                    </div>
                    
                    <div class="space-y-3">
                        <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            <input type="radio" id="auth-app" name="auth-method" value="app" checked class="text-blue-600 focus:ring-blue-500">
                            <label for="auth-app" class="flex-1 cursor-pointer">
                                <div class="font-medium text-gray-800 text-sm">Authenticator App</div>
                                <div class="text-xs text-gray-600">Use Google Authenticator or Authy</div>
                            </label>
                        </div>
                        
                        <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            <input type="radio" id="auth-sms" name="auth-method" value="sms" class="text-blue-600 focus:ring-blue-500">
                            <label for="auth-sms" class="flex-1 cursor-pointer">
                                <div class="font-medium text-gray-800 text-sm">SMS Text Message</div>
                                <div class="text-xs text-gray-600">We'll send codes to your registered phone</div>
                                <div class="text-xs text-blue-600 font-medium mt-1">${userPhone}</div>
                            </label>
                        </div>
                        
                        <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            <input type="radio" id="auth-email" name="auth-method" value="email" class="text-blue-600 focus:ring-blue-500">
                            <label for="auth-email" class="flex-1 cursor-pointer">
                                <div class="font-medium text-gray-800 text-sm">Email</div>
                                <div class="text-xs text-gray-600">We'll send codes to your registered email</div>
                                <div class="text-xs text-blue-600 font-medium mt-1">${userEmail}</div>
                            </label>
                        </div>
                    </div>
                    
                    <!-- App Authentication Section -->
                    <div id="appAuthSection" class="space-y-3">
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
                            <div class="flex items-start">
                                <i class="fas fa-info-circle text-blue-500 text-sm mr-2 mt-0.5"></i>
                                <div>
                                    <h4 class="text-sm font-medium text-blue-800 mb-1">Authenticator App</h4>
                                    <p class="text-xs text-blue-600">
                                        You'll set up your authenticator app in the next step.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- SMS Authentication Section -->
                    <div id="smsAuthSection" class="hidden space-y-3">
                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                            <div class="flex items-start">
                                <i class="fas fa-exclamation-triangle text-yellow-500 text-sm mr-2 mt-0.5"></i>
                                <div>
                                    <h4 class="text-sm font-medium text-yellow-800 mb-1">SMS Verification</h4>
                                    <p class="text-xs text-yellow-600">
                                        Verification codes will be sent to your registered phone number.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Email Authentication Section -->
                    <div id="emailAuthSection" class="hidden space-y-3">
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
                            <div class="flex items-start">
                                <i class="fas fa-info-circle text-blue-500 text-sm mr-2 mt-0.5"></i>
                                <div>
                                    <h4 class="text-sm font-medium text-blue-800 mb-1">Email Verification</h4>
                                    <p class="text-xs text-blue-600">
                                        Verification codes will be sent to your registered email address.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.closeModal()" class="flex-1 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium text-sm">
                        Cancel
                    </button>
                    <button onclick="settingsManager.showVerificationPage()" class="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium text-sm">
                        Continue
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
        this.initialize2FAMethodSelection();
    }

    // New method to show verification code input page
    showVerificationPage() {
        const selectedMethod = document.querySelector('input[name="auth-method"]:checked')?.value;
        
        if (!selectedMethod) {
            this.showNotification('Please select an authentication method', 'error');
            return;
        }
        
        let methodDisplay = '';
        let instructions = '';
        let contactInfo = '';
        
        // Get user's registered contact information
        const userEmail = localStorage.getItem('userEmail') || 'user@example.com';
        const userPhone = localStorage.getItem('userPhone') || '+1 (555) 123-4567'; // You can store this during signup
        
        switch(selectedMethod) {
            case 'app':
                methodDisplay = 'Authenticator App';
                instructions = 'Enter the 6-digit code from your authenticator app';
                contactInfo = '';
                break;
            case 'sms':
                methodDisplay = 'SMS';
                instructions = `Enter the 6-digit code sent to your phone`;
                contactInfo = userPhone;
                // Auto-send SMS verification code
                this.sendVerificationCode('sms', userPhone);
                break;
            case 'email':
                methodDisplay = 'Email';
                instructions = `Enter the 6-digit code sent to your email`;
                contactInfo = userEmail;
                // Auto-send email verification code
                this.sendVerificationCode('email', userEmail);
                break;
        }
        
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-sm mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-5 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-800">Enter Verification Code</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-5 space-y-4">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-shield-alt text-blue-600"></i>
                        </div>
                        <p class="text-sm text-gray-600 mb-2">
                            ${instructions}
                        </p>
                        ${contactInfo ? `
                            <p class="text-xs text-blue-600 font-medium mb-1">
                                Sent to: ${contactInfo}
                            </p>
                        ` : ''}
                        <p class="text-xs text-gray-500">
                            Method: <span class="font-medium">${methodDisplay}</span>
                        </p>
                    </div>
                    
                    <div class="space-y-3">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2 text-center">Verification Code</label>
                            <input type="text" 
                                id="verificationCodeInput" 
                                class="verification-code w-full border border-gray-300 rounded-lg p-3 text-center text-lg font-mono tracking-widest focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                                placeholder="000000" 
                                maxlength="6"
                                autocomplete="one-time-code">
                        </div>
                        
                        <div class="text-center">
                            <button onclick="settingsManager.resendVerificationCode('${selectedMethod}')" class="text-blue-600 hover:text-blue-800 text-xs font-medium">
                                <i class="fas fa-redo mr-1"></i> Resend Code
                            </button>
                        </div>
                        
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
                            <div class="flex items-start">
                                <i class="fas fa-info-circle text-blue-500 text-sm mr-2 mt-0.5"></i>
                                <div>
                                    <p class="text-xs text-blue-600">
                                        This code expires in 1 minuites.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.show2FASetupModal()" class="flex-1 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium text-sm">
                        Back
                    </button>
                    <button onclick="settingsManager.verifyAndEnable2FA(this)" class="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium text-sm">
                        Verify & Enable
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
        this.initializeVerificationCodeInput();
    }

    // Updated method to send verification code
    sendVerificationCode(method, contactInfo = null) {
        // Get user's registered contact information
        const userEmail = localStorage.getItem('userEmail') || 'user@example.com';
        const userPhone = localStorage.getItem('userPhone') || '+1 (555) 123-4567';
        
        let message = '';
        let target = '';
        
        switch(method) {
            case 'sms':
                target = contactInfo || userPhone;
                message = `Verification code sent to your phone: ${target}`;
                break;
            case 'email':
                target = contactInfo || userEmail;
                message = `Verification code sent to your email: ${target}`;
                break;
            default:
                message = 'Verification code generated';
        }
        
        // Show sending notification
        this.showNotification(`Sending verification code...`, 'info');
        
        // Simulate API call to send verification code
        setTimeout(() => {
            this.showNotification(message, 'success');
            
            // In a real app, you would:
            // 1. Make API call to your backend to send the code
            // 2. The backend would send SMS/email to the user's registered contact
            // 3. Store the verification code temporarily for validation
            
            console.log(`Sending verification code via ${method} to: ${target}`);
        }, 1000);
    }

    // Updated method to resend verification code
    resendVerificationCode(method = null) {
        if (!method) {
            method = document.querySelector('input[name="auth-method"]:checked')?.value;
        }
        
        if (method && method !== 'app') {
            // Get user's registered contact information
            const userEmail = localStorage.getItem('userEmail') || 'user@example.com';
            const userPhone = localStorage.getItem('userPhone') || '+1 (555) 123-4567';
            
            const contactInfo = method === 'sms' ? userPhone : userEmail;
            this.sendVerificationCode(method, contactInfo);
        } else {
            this.showNotification('Use your authenticator app to get a new code', 'info');
        }
    }

    // Method to verify the code and enable 2FA
    verifyAndEnable2FA(button) {
        const verificationCode = document.getElementById('verificationCodeInput')?.value;
        
        if (!verificationCode || verificationCode.length !== 6) {
            this.showNotification('Please enter a valid 6-digit verification code', 'error');
            return;
        }

        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Verifying...';

        // Simulate verification process
        setTimeout(() => {
            // Demo: Always accept "123456" as valid, in real app you'd verify against backend
            if (verificationCode === '123456' || verificationCode === '000000') {
                this.securitySettings.twoFactorEnabled = true;
                this.saveAllSettings();
                this.update2FADisplay();
                this.showNotification('Two-factor authentication enabled successfully!', 'success');
                this.closeModal();
            } else {
                button.disabled = false;
                button.textContent = 'Verify & Enable 2FA';
                this.showNotification('Invalid verification code. Please try again.', 'error');
                
                // Clear the input for retry
                const codeInput = document.getElementById('verificationCodeInput');
                if (codeInput) {
                    codeInput.value = '';
                    codeInput.focus();
                }
            }
        }, 2000);
    }

    // Initialize verification code input
    initializeVerificationCodeInput() {
        const codeInput = document.getElementById('verificationCodeInput');
        codeInput?.addEventListener('input', (e) => {
            // Only allow numbers and limit to 6 digits
            e.target.value = e.target.value.replace(/[^0-9]/g, '').substring(0, 6);
            
            // Auto-submit when 6 digits are entered
            if (e.target.value.length === 6) {
                const verifyButton = document.querySelector('.modal-content button.bg-blue-600');
                if (verifyButton) {
                    setTimeout(() => verifyButton.click(), 300);
                }
            }
        });
        
        // Focus the input
        setTimeout(() => {
            codeInput?.focus();
        }, 100);
    }

    initialize2FAMethodSelection() {
        const authMethods = document.querySelectorAll('input[name="auth-method"]');
        authMethods.forEach(method => {
            method.addEventListener('change', function() {
                // Hide all sections first
                document.getElementById('appAuthSection')?.classList.add('hidden');
                document.getElementById('smsAuthSection')?.classList.add('hidden');
                document.getElementById('emailAuthSection')?.classList.add('hidden');
                
                // Show selected section
                if (this.value === 'app') {
                    document.getElementById('appAuthSection')?.classList.remove('hidden');
                } else if (this.value === 'sms') {
                    document.getElementById('smsAuthSection')?.classList.remove('hidden');
                } else if (this.value === 'email') {
                    document.getElementById('emailAuthSection')?.classList.remove('hidden');
                }
            });
        });
    }



    initializeVerificationCodeInput() {
        const codeInput = document.querySelector('.verification-code');
        codeInput?.addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/[^0-9]/g, '').substring(0, 6);
        });
    }

    enable2FA(button) {
        const verificationCode = document.querySelector('.verification-code')?.value;
        
        if (!verificationCode || verificationCode.length !== 6) {
            this.showNotification('Please enter a valid 6-digit verification code', 'error');
            return;
        }

        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Verifying...';

        // Simulate verification
        setTimeout(() => {
            if (verificationCode === '123456') { // Demo code
                this.securitySettings.twoFactorEnabled = true;
                this.saveAllSettings();
                this.update2FADisplay();
                this.showNotification('Two-factor authentication enabled successfully!', 'success');
                this.closeModal();
            } else {
                button.disabled = false;
                button.textContent = 'Enable 2FA';
                this.showNotification('Invalid verification code. Please try again.', 'error');
            }
        }, 2000);
    }

    show2FAManagementModal() {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">Two-Factor Authentication</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-6">
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div class="flex items-center">
                            <i class="fas fa-check-circle text-green-500 text-xl mr-3"></i>
                            <div>
                                <h4 class="font-medium text-green-800">2FA Enabled</h4>
                                <p class="text-green-600 text-sm">Your account is protected with two-factor authentication</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <h4 class="font-medium text-gray-800 mb-2">Recovery Codes</h4>
                            <p class="text-sm text-gray-600 mb-3">Save these codes in a safe place. You can use them to access your account if you lose your authenticator device.</p>
                            <div class="bg-gray-50 border border-gray-200 rounded-lg p-4">
                                <div class="grid grid-cols-2 gap-2 text-sm font-mono">
                                    <div>1A2B-3C4D</div>
                                    <div>5E6F-7G8H</div>
                                    <div>9I0J-1K2L</div>
                                    <div>3M4N-5O6P</div>
                                    <div>7Q8R-9S0T</div>
                                </div>
                            </div>
                            <button onclick="settingsManager.downloadRecoveryCodes()" class="w-full mt-3 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg text-sm transition font-medium">
                                <i class="fas fa-download mr-2"></i>Download Recovery Codes
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
                    <button onclick="settingsManager.disable2FA()" class="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition font-medium">
                        Disable 2FA
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    downloadRecoveryCodes() {
        this.showNotification('Recovery codes downloaded successfully!', 'success');
    }

    disable2FA() {
        this.showConfirmationModal(
            'Disable Two-Factor Authentication',
            'Are you sure you want to disable two-factor authentication? This will make your account less secure.',
            'Disable 2FA',
            () => {
                this.securitySettings.twoFactorEnabled = false;
                this.saveAllSettings();
                this.update2FADisplay();
                this.showNotification('Two-factor authentication has been disabled', 'info');
                this.closeModal();
            }
        );
    }

    // Password Change
    showPasswordChangeModal() {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">Change Password</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                        <input type="password" class="current-password w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Enter current password">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                        <input type="password" class="new-password w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Enter new password">
                        <div class="password-strength mt-2 hidden">
                            <div class="flex items-center space-x-2">
                                <div class="strength-bar h-2 flex-1 bg-gray-200 rounded-full overflow-hidden">
                                    <div class="strength-progress h-full bg-red-500 transition-all duration-300"></div>
                                </div>
                                <span class="strength-text text-xs font-medium text-red-500">Weak</span>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Confirm New Password</label>
                        <input type="password" class="confirm-password w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Confirm new password">
                        <div class="password-match mt-2 hidden">
                            <span class="text-xs text-red-500">Passwords don't match</span>
                        </div>
                    </div>
                    
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 class="text-sm font-medium text-blue-800 mb-2">Password Requirements</h4>
                        <ul class="text-xs text-blue-600 space-y-1">
                            <li class="requirement-min-length flex items-center"><i class="fas fa-check-circle mr-2 text-green-500"></i> At least 8 characters</li>
                            <li class="requirement-uppercase flex items-center"><i class="fas fa-times-circle mr-2 text-gray-400"></i> One uppercase letter</li>
                            <li class="requirement-lowercase flex items-center"><i class="fas fa-times-circle mr-2 text-gray-400"></i> One lowercase letter</li>
                            <li class="requirement-number flex items-center"><i class="fas fa-times-circle mr-2 text-gray-400"></i> One number</li>
                            <li class="requirement-special flex items-center"><i class="fas fa-times-circle mr-2 text-gray-400"></i> One special character</li>
                        </ul>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Cancel
                    </button>
                    <button onclick="settingsManager.changePassword(this)" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                        Update Password
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
        this.initializePasswordValidation();
    }

    initializePasswordValidation() {
        const newPasswordInput = document.querySelector('.new-password');
        const confirmPasswordInput = document.querySelector('.confirm-password');
        const updateButton = document.querySelector('.modal-content button.bg-blue-600');

        newPasswordInput?.addEventListener('input', () => {
            this.validatePasswordStrength(newPasswordInput.value);
            this.checkPasswordsMatch();
            this.updatePasswordButtonState();
        });

        confirmPasswordInput?.addEventListener('input', () => {
            this.checkPasswordsMatch();
            this.updatePasswordButtonState();
        });

        document.querySelector('.current-password')?.addEventListener('input', () => {
            this.updatePasswordButtonState();
        });
    }

    validatePasswordStrength(password) {
        const strengthBar = document.querySelector('.strength-progress');
        const strengthText = document.querySelector('.strength-text');
        const requirements = document.querySelectorAll('.password-requirements li');
        const strengthContainer = document.querySelector('.password-strength');

        if (!strengthBar || !strengthText) return;

        strengthContainer.classList.remove('hidden');

        const checks = {
            minLength: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        const score = Object.values(checks).filter(Boolean).length;
        const strengthLevels = [
            { percent: 20, color: 'bg-red-500', text: 'Weak' },
            { percent: 40, color: 'bg-orange-500', text: 'Fair' },
            { percent: 60, color: 'bg-yellow-500', text: 'Good' },
            { percent: 80, color: 'bg-green-500', text: 'Strong' },
            { percent: 100, color: 'bg-green-600', text: 'Very Strong' }
        ];

        const level = strengthLevels[Math.min(score, strengthLevels.length - 1)];
        
        strengthBar.style.width = `${level.percent}%`;
        strengthBar.className = `strength-progress h-full ${level.color} transition-all duration-300`;
        strengthText.textContent = level.text;
        strengthText.className = `strength-text text-xs font-medium ${level.color.replace('bg-', 'text-')}`;

        // Update requirement indicators
        requirements[0].querySelector('i').className = `fas ${checks.minLength ? 'fa-check-circle text-green-500' : 'fa-times-circle text-gray-400'} mr-2`;
        requirements[1].querySelector('i').className = `fas ${checks.uppercase ? 'fa-check-circle text-green-500' : 'fa-times-circle text-gray-400'} mr-2`;
        requirements[2].querySelector('i').className = `fas ${checks.lowercase ? 'fa-check-circle text-green-500' : 'fa-times-circle text-gray-400'} mr-2`;
        requirements[3].querySelector('i').className = `fas ${checks.number ? 'fa-check-circle text-green-500' : 'fa-times-circle text-gray-400'} mr-2`;
        requirements[4].querySelector('i').className = `fas ${checks.special ? 'fa-check-circle text-green-500' : 'fa-times-circle text-gray-400'} mr-2`;
    }

    checkPasswordsMatch() {
        const newPassword = document.querySelector('.new-password')?.value;
        const confirmPassword = document.querySelector('.confirm-password')?.value;
        const matchContainer = document.querySelector('.password-match');

        if (!matchContainer) return;

        if (confirmPassword && newPassword !== confirmPassword) {
            matchContainer.classList.remove('hidden');
            return false;
        } else {
            matchContainer.classList.add('hidden');
            return true;
        }
    }

    updatePasswordButtonState() {
        const currentPassword = document.querySelector('.current-password')?.value;
        const newPassword = document.querySelector('.new-password')?.value;
        const confirmPassword = document.querySelector('.confirm-password')?.value;
        const updateButton = document.querySelector('.modal-content button.bg-blue-600');

        if (!updateButton) return;

        const isCurrentValid = currentPassword && currentPassword.length > 0;
        const isNewValid = newPassword && newPassword.length >= 8;
        const isConfirmValid = this.checkPasswordsMatch();

        updateButton.disabled = !(isCurrentValid && isNewValid && isConfirmValid);
    }

    changePassword(button) {
        const currentPassword = document.querySelector('.current-password')?.value;
        const newPassword = document.querySelector('.new-password')?.value;

        if (!currentPassword || !newPassword) {
            this.showNotification('Please fill in all password fields', 'error');
            return;
        }

        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Updating...';

        // Simulate API call
        setTimeout(() => {
            this.showNotification('Password updated successfully!', 'success');
            this.closeModal();
            
            // Clear password fields
            document.querySelector('.current-password').value = '';
            document.querySelector('.new-password').value = '';
            document.querySelector('.confirm-password').value = '';
        }, 2000);
    }

    // Connected Devices
    showConnectedDevicesModal() {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-2xl mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">Connected Devices</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6">
                    <div class="space-y-4">
                        ${this.securitySettings.connectedDevices.map(device => `
                            <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border ${device.current ? 'border-blue-200 bg-blue-50' : 'border-gray-200'}">
                                <div class="flex items-center space-x-4">
                                    <div class="w-10 h-10 bg-${device.current ? 'blue' : 'gray'}-100 rounded-lg flex items-center justify-center">
                                        <i class="fas fa-${this.getDeviceIcon(device.name)} text-${device.current ? 'blue' : 'gray'}-500"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-medium text-gray-800">${device.name}</h4>
                                        <p class="text-sm text-gray-600">
                                            Last active: ${this.formatDate(device.lastActive)}
                                            ${device.current ? '<span class="ml-2 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Current Session</span>' : ''}
                                        </p>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-2">
                                    ${!device.current ? `
                                        <button onclick="settingsManager.signOutDevice(${device.id})" class="px-3 py-1 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg text-sm transition font-medium">
                                            Sign Out
                                        </button>
                                    ` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    
                    <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle text-yellow-500 text-lg mr-3 mt-0.5"></i>
                            <div>
                                <h4 class="font-medium text-yellow-800 mb-1">Device Security</h4>
                                <p class="text-sm text-yellow-700">
                                    Sign out of devices you don't recognize or no longer use. This will immediately log you out of that device.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.signOutAllDevices()" class="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition font-medium">
                        Sign Out All Devices
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    getDeviceIcon(deviceName) {
        if (deviceName.includes('Chrome')) return 'globe';
        if (deviceName.includes('Safari')) return 'compass';
        if (deviceName.includes('Firefox')) return 'firefox';
        if (deviceName.includes('iPhone') || deviceName.includes('Android')) return 'mobile-alt';
        return 'laptop';
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString() + ' at ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    signOutDevice(deviceId) {
        this.showConfirmationModal(
            'Sign Out Device',
            'Are you sure you want to sign out of this device? This will immediately log you out of that device.',
            'Sign Out',
            () => {
                this.securitySettings.connectedDevices = this.securitySettings.connectedDevices.filter(device => device.id !== deviceId);
                this.saveAllSettings();
                this.updateConnectedDevicesDisplay();
                this.showNotification('Device signed out successfully', 'success');
                this.closeModal();
                this.showConnectedDevicesModal(); // Refresh the modal
            }
        );
    }

    signOutAllDevices() {
        this.showConfirmationModal(
            'Sign Out All Devices',
            'This will sign you out of all devices except your current session. You will need to sign in again on all other devices.',
            'Sign Out All',
            () => {
                this.securitySettings.connectedDevices = this.securitySettings.connectedDevices.filter(device => device.current);
                this.saveAllSettings();
                this.updateConnectedDevicesDisplay();
                this.showNotification('All other devices have been signed out', 'success');
                this.closeModal();
            }
        );
    }

    // Modal System
    initializeModals() {
        this.createModalStructure();
    }

    createModalStructure() {
        const backdrop = document.createElement('div');
        backdrop.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 hidden';
        backdrop.id = 'modalBackdrop';
        
        const container = document.createElement('div');
        container.className = 'fixed inset-0 z-50 flex items-center justify-center hidden';
        container.id = 'modalContainer';

        document.body.appendChild(backdrop);
        document.body.appendChild(container);

        backdrop.addEventListener('click', () => this.closeModal());
        
        // Escape key listener
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
        });
    }

    showModal(content) {
        const container = document.getElementById('modalContainer');
        const backdrop = document.getElementById('modalBackdrop');
        
        container.innerHTML = content;
        container.classList.remove('hidden');
        backdrop.classList.remove('hidden');

        setTimeout(() => {
            const modalContent = container.querySelector('.modal-content');
            if (modalContent) modalContent.classList.add('modal-open');
        }, 10);
    }

    closeModal() {
        const container = document.getElementById('modalContainer');
        const backdrop = document.getElementById('modalBackdrop');
        
        container.classList.add('hidden');
        backdrop.classList.add('hidden');
    }

    // Account Management Modal
    showAccountManagementModal(platform) {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">Manage ${platform}</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-4">
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div class="flex items-center">
                            <i class="fas fa-check-circle text-green-500 text-xl mr-3"></i>
                            <div>
                                <h4 class="font-medium text-green-800">Connected</h4>
                                <p class="text-green-600 text-sm">Your account is successfully connected</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="space-y-3">
                        <button onclick="settingsManager.handleAccountAction('${platform}', 'reauthenticate')" 
                                class="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition group">
                            <div class="flex items-center">
                                <i class="fas fa-sync-alt text-blue-500 mr-3"></i>
                                <span>Re-authenticate Account</span>
                            </div>
                            <i class="fas fa-chevron-right text-gray-400"></i>
                        </button>
                        
                        <button onclick="settingsManager.handleAccountAction('${platform}', 'permissions')" 
                                class="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition group">
                            <div class="flex items-center">
                                <i class="fas fa-shield-alt text-green-500 mr-3"></i>
                                <span>View Permissions</span>
                            </div>
                            <i class="fas fa-chevron-right text-gray-400"></i>
                        </button>
                        
                        <button onclick="settingsManager.handleAccountAction('${platform}', 'disconnect')" 
                                class="w-full flex items-center justify-between p-3 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg transition group">
                            <div class="flex items-center">
                                <i class="fas fa-unlink text-red-500 mr-3"></i>
                                <span>Disconnect Account</span>
                            </div>
                            <i class="fas fa-chevron-right text-red-400"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
                    <button onclick="settingsManager.closeModal()" class="w-full py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Close
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    handleAccountAction(platform, action) {
        switch(action) {
            case 'reauthenticate':
                this.showNotification(`Re-authenticating ${platform}...`, 'info');
                setTimeout(() => {
                    this.showNotification(`${platform} re-authenticated successfully`, 'success');
                    this.closeModal();
                }, 1500);
                break;
                
            case 'permissions':
                this.showPermissionsModal(platform);
                break;
                
            case 'disconnect':
                this.showConfirmationModal(
                    `Disconnect ${platform}`,
                    `Are you sure you want to disconnect your ${platform} account? You'll need to reconnect it to post to ${platform} again.`,
                    'Disconnect',
                    () => {
                        this.disconnectSocialAccount(platform);
                        this.closeModal();
                    }
                );
                break;
        }
    }

    showPermissionsModal(platform) {
        const permissions = [
            'Post content on your behalf',
            'Read your profile information',
            'Access insights and analytics',
            'Manage comments and interactions'
        ];
        
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">${platform} Permissions</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6">
                    <div class="space-y-3 mb-6">
                        ${permissions.map(permission => `
                            <div class="flex items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                                <i class="fas fa-check-circle text-green-500 mr-3"></i>
                                <span class="text-green-800 font-medium">${permission}</span>
                            </div>
                        `).join('')}
                    </div>
                    
                    <p class="text-sm text-gray-600 text-center bg-gray-50 p-3 rounded-lg">
                        These permissions are required for SocialGenius to manage your ${platform} account effectively.
                    </p>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
                    <button onclick="settingsManager.closeModal()" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                        Understand
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    // Confirmation Modal
    showConfirmationModal(title, message, confirmText, onConfirm) {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <h3 class="text-xl font-semibold text-gray-800">${title}</h3>
                </div>
                
                <div class="p-6">
                    <p class="text-gray-600 leading-relaxed">${message}</p>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Cancel
                    </button>
                    <button onclick="settingsManager.executeConfirmAction()" class="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition font-medium">
                        ${confirmText}
                    </button>
                </div>
            </div>
        `;
        
        window.settingsManagerConfirmAction = onConfirm;
        this.showModal(modalContent);
    }

    executeConfirmAction() {
        if (window.settingsManagerConfirmAction) {
            window.settingsManagerConfirmAction();
        }
        this.closeModal();
    }

    // Form Interactions
    initializeFormInteractions() {
        this.setupOptionSelectors();
        this.setupTagSystem();
        this.setupContentPillars();
        this.setupSecuritySettings();
    }

    setupOptionSelectors() {
        // Voice options
        document.querySelectorAll('.voice-option input').forEach(option => {
            option.addEventListener('change', (e) => {
                this.toggleOptionSelection(e.target, 'voice-option-label');
            });
        });

        // Image sources
        document.querySelectorAll('.image-source-option input').forEach(source => {
            source.addEventListener('change', (e) => {
                this.toggleOptionSelection(e.target, 'image-source-label');
            });
        });

        // Report frequencies
        document.querySelectorAll('.report-frequency-option input').forEach(frequency => {
            frequency.addEventListener('change', (e) => {
                this.toggleOptionSelection(e.target, 'report-frequency-label');
            });
        });
    }

    toggleOptionSelection(selectedInput, labelClass) {
        document.querySelectorAll(`.${labelClass}`).forEach(label => {
            label.classList.remove('selected');
        });
        selectedInput.closest(`.${labelClass}`).classList.add('selected');
    }

    setupTagSystem() {
        // Remove interest tags
        document.querySelectorAll('.interest-tag button').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                e.target.closest('.interest-tag').remove();
            });
        });

        // Remove email tags
        document.querySelectorAll('.email-tag button').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                e.target.closest('.email-tag').remove();
            });
        });

        // Add interest button
        const addInterestBtn = document.querySelector('.text-blue-600 .fa-plus')?.closest('button');
        addInterestBtn?.addEventListener('click', () => {
            const interest = prompt('Enter a new interest:');
            if (interest) {
                this.addNewTag('interest', interest);
            }
        });

        // Add email button
        const addEmailBtn = document.querySelectorAll('.text-blue-600 .fa-plus')[1]?.closest('button');
        addEmailBtn?.addEventListener('click', () => {
            const email = prompt('Enter email address for reports:');
            if (email && this.isValidEmail(email)) {
                this.addNewTag('email', email);
            } else {
                this.showNotification('Please enter a valid email address', 'error');
            }
        });
    }

    addNewTag(type, value) {
        const container = document.querySelector(type === 'interest' ? '.flex-wrap.gap-2' : '.flex-wrap.gap-2:nth-child(2)');
        const tagClass = type === 'interest' ? 'interest-tag bg-blue-100 text-blue-800' : 'email-tag bg-green-100 text-green-800';
        
        const tag = document.createElement('span');
        tag.className = `${tagClass} px-3 py-1 rounded-full text-sm flex items-center`;
        tag.innerHTML = `${value} <button class="ml-2 ${type === 'interest' ? 'text-blue-600' : 'text-green-600'} hover:${type === 'interest' ? 'text-blue-800' : 'text-green-800'} text-xs">&times;</button>`;
        
        tag.querySelector('button').addEventListener('click', () => tag.remove());
        container.appendChild(tag);
    }

    setupContentPillars() {
        document.querySelectorAll('.content-pillar .text-blue-600').forEach(button => {
            if (button.textContent.trim() === 'Edit') {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    const pillar = e.target.closest('.content-pillar');
                    this.showEditPillarModal(pillar);
                });
            }
        });

        document.querySelectorAll('.content-pillar .text-red-600').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const pillar = e.target.closest('.content-pillar');
                this.showDeletePillarModal(pillar);
            });
        });
    }

    showEditPillarModal(pillar) {
        const title = pillar.querySelector('h4').textContent;
        const description = pillar.querySelector('p').textContent;
        
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95 opacity-0">
                <div class="p-6 border-b border-gray-200">
                    <h3 class="text-xl font-semibold text-gray-800">Edit Content Pillar</h3>
                </div>
                
                <div class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Title</label>
                        <input type="text" value="${title}" class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <textarea class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-24">${description}</textarea>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Cancel
                    </button>
                    <button onclick="settingsManager.savePillarChanges(this)" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                        Save Changes
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    savePillarChanges(button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';
        
        setTimeout(() => {
            this.showNotification('Content pillar updated successfully', 'success');
            this.closeModal();
        }, 1000);
    }

    showDeletePillarModal(pillar) {
        const title = pillar.querySelector('h4').textContent;
        
        this.showConfirmationModal(
            'Remove Content Pillar',
            `Are you sure you want to remove "${title}"? This action cannot be undone.`,
            'Remove',
            () => {
                pillar.remove();
                this.showNotification(`"${title}" removed successfully`, 'success');
            }
        );
    }

    setupSecuritySettings() {
        document.querySelectorAll('.bg-gray-50 button.text-blue-600').forEach(button => {
            button.addEventListener('click', () => {
                const setting = button.closest('div').querySelector('h4').textContent;
                this.handleSecurityAction(setting);
            });
        });
    }

    handleSecurityAction(setting) {
        switch(setting) {
            case 'Password':
                this.showPasswordChangeModal();
                break;
            case 'Two-Factor Authentication':
                this.show2FAModal();
                break;
            case 'Connected Devices':
                this.showConnectedDevicesModal();
                break;
        }
    }

    // Toggle Switches
    initializeToggleSwitches() {
        document.querySelectorAll('input[type="checkbox"]').forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                const setting = e.target.closest('div').querySelector('h4').textContent;
                this.handleToggleChange(setting, e.target.checked);
            });
        });
    }

    handleToggleChange(setting, enabled) {
        this.showNotification(`${setting} ${enabled ? 'enabled' : 'disabled'}`, 'success');
        if (!this.settings) this.settings = {};
        this.settings[setting] = enabled;
        this.saveAllSettings();
    }

    // Event Listeners - FIXED VERSION
        initializeEventListeners() {
        // Logout button
        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            this.showConfirmationModal(
                'Logout',
                'Are you sure you want to log out?',
                'Logout',
                () => {
                    localStorage.removeItem('authToken');
                    window.location.href = 'login.html';
                }
            );
        });

        // Enhanced social account buttons with better debugging
        document.addEventListener('click', (e) => {
            const socialAccountButton = e.target.closest('.social-account-setting button');
            if (socialAccountButton) {
                const accountElement = socialAccountButton.closest('.social-account-setting');
                const platform = accountElement.querySelector('span').textContent;
                
                console.log(`Event delegation caught click for: ${platform}`);
                this.handleSocialAccountClick(platform, socialAccountButton);
            }
        });

        // Initialize direct listeners as backup
        this.initializeDirectSocialAccountListeners();

        // Initialize 2FA functionality
        this.initialize2FA();
    }

    // ADD THIS NEW METHOD to ensure all social buttons work
    initializeDirectSocialAccountListeners() {
        document.querySelectorAll('.social-account-setting').forEach(account => {
            const button = account.querySelector('button');
            const platform = account.querySelector('span').textContent;
            
            console.log(`Setting up listener for: ${platform}`); // Debug log
            
            if (button && !button.hasAttribute('data-listener-attached')) {
                button.setAttribute('data-listener-attached', 'true');
                button.addEventListener('click', (e) => {
                    e.stopPropagation(); // Prevent event bubbling
                    console.log(`Button clicked for: ${platform}`); // Debug log
                    this.handleSocialAccountClick(platform, button);
                });
            }
        });
    }

    // Enhanced Notification System
    showNotification(message, type = 'info') {
        console.log('Notification triggered:', message, type); // Debug log
        
        // Remove any existing notifications first
        const existingNotifications = document.querySelectorAll('.notification');
        existingNotifications.forEach(notification => {
            notification.remove();
        });

        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            info: 'fa-info-circle',
            warning: 'fa-exclamation-triangle'
        };
        
        notification.innerHTML = `
            <i class="fas ${icons[type] || 'fa-info-circle'} text-white text-lg"></i>
            <span class="text-white font-medium">${message}</span>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Force reflow and animate in
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Auto remove after 4 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }, 4000);
        
        return notification;
    }

    // Utility Methods
    createLoadingSpinner() {
        return '<div class="w-full h-full flex items-center justify-center bg-gray-100 rounded-full"><i class="fas fa-spinner fa-spin text-blue-600 text-xl"></i></div>';
    }

    capitalize(text) {
        return text.charAt(0).toUpperCase() + text.slice(1);
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Posting and Scheduling Methods
    initializePostingScheduling() {
        this.setupScheduleToggles();
        this.setupPostingFrequency();
        this.setupPlatformSchedules();
        this.setupAutoPublish();
        this.loadPostingSettings();
    }

    setupScheduleToggles() {
        // Platform-specific formatting toggles
        document.querySelectorAll('#posting input[type="checkbox"]').forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                const settingName = e.target.closest('.flex.justify-between').querySelector('h4').textContent;
                this.handlePostingToggle(settingName, e.target.checked);
            });
        });
    }

    setupPostingFrequency() {
        const frequencySelect = document.querySelector('#posting select');
        if (frequencySelect) {
            frequencySelect.addEventListener('change', (e) => {
                this.updatePostingFrequency(e.target.value);
            });
        }

        const generationSelect = document.querySelectorAll('#posting select')[1];
        if (generationSelect) {
            generationSelect.addEventListener('change', (e) => {
                this.updateGenerationSchedule(e.target.value);
            });
        }
    }

    setupPlatformSchedules() {
        // Edit schedule buttons
        document.querySelectorAll('#posting .text-blue-600').forEach(button => {
            if (button.textContent.includes('Edit')) {
                button.addEventListener('click', (e) => {
                    const platform = e.target.closest('.bg-gray-50').querySelector('h4').textContent;
                    this.showScheduleEditor(platform);
                });
            }
        });
    }

    setupAutoPublish() {
        const publishRadios = document.querySelectorAll('#posting input[name="publish-mode"]');
        publishRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.updatePublishMode(e.target.value);
            });
        });
    }

    loadPostingSettings() {
        const saved = localStorage.getItem('socialgenius_posting_settings');
        if (saved) {
            this.postingSettings = JSON.parse(saved);
            this.applyPostingSettings();
        } else {
            // Default posting settings - MAKE SURE TIKTOK IS INCLUDED
            this.postingSettings = {
                publishMode: 'draft',
                postingFrequency: '3-5 posts',
                generationSchedule: 'Weekly',
                platformSchedules: {
                    'Instagram': { times: ['9:00 AM', '1:00 PM', '7:00 PM'], enabled: true },
                    'TikTok': { times: ['11:00 AM', '3:00 PM', '8:00 PM'], enabled: false }, // Start as false
                    'Twitter': { times: ['8:00 AM', '12:00 PM', '5:00 PM'], enabled: true },
                    'LinkedIn': { times: ['10:00 AM', '2:00 PM'], enabled: false },
                    'Facebook': { times: ['1:00 PM', '3:00 PM', '7:00 PM'], enabled: true }
                },
                formattingOptions: {
                    'Auto-Hashtag Conversion': true,
                    'Link Shortening': true,
                    'Character Limit Enforcement': true
                }
            };
            this.savePostingSettings();
        }
    }

    applyPostingSettings() {
        // Apply publish mode
        const publishMode = this.postingSettings.publishMode;
        document.querySelectorAll('#posting input[name="publish-mode"]').forEach(radio => {
            radio.checked = radio.value === publishMode;
        });

        // Apply posting frequency
        const frequencySelect = document.querySelector('#posting select');
        if (frequencySelect) {
            frequencySelect.value = this.postingSettings.postingFrequency;
        }

        // Apply generation schedule
        const generationSelect = document.querySelectorAll('#posting select')[1];
        if (generationSelect) {
            generationSelect.value = this.postingSettings.generationSchedule;
        }

        // Apply platform schedules
        this.updatePlatformScheduleDisplays();

        // Apply formatting toggles
        this.updateFormattingToggles();
    }

    updatePlatformScheduleDisplays() {
        Object.keys(this.postingSettings.platformSchedules).forEach(platform => {
            const platformElement = this.findPlatformElement(platform);
            if (platformElement) {
                const schedule = this.postingSettings.platformSchedules[platform];
                const timeText = platformElement.querySelector('p.text-sm');
                if (timeText) {
                    timeText.textContent = `Optimal times: ${schedule.times.join(', ')}`;
                }
            }
        });
    }

    updateFormattingToggles() {
        Object.keys(this.postingSettings.formattingOptions).forEach(option => {
            const toggle = this.findFormattingToggle(option);
            if (toggle) {
                toggle.checked = this.postingSettings.formattingOptions[option];
            }
        });
    }

    findPlatformElement(platform) {
        const platforms = document.querySelectorAll('#posting .bg-gray-50');
        for (let element of platforms) {
            if (element.querySelector('h4').textContent === platform) {
                return element;
            }
        }
        return null;
    }

    findFormattingToggle(option) {
        const toggles = document.querySelectorAll('#posting .flex.justify-between');
        for (let toggle of toggles) {
            if (toggle.querySelector('h4').textContent === option) {
                return toggle.querySelector('input[type="checkbox"]');
            }
        }
        return null;
    }

    // Event Handlers
    handlePostingToggle(settingName, enabled) {
        this.postingSettings.formattingOptions[settingName] = enabled;
        this.savePostingSettings();
        this.showNotification(`${settingName} ${enabled ? 'enabled' : 'disabled'}`, 'success');
    }

    updatePostingFrequency(frequency) {
        this.postingSettings.postingFrequency = frequency;
        this.savePostingSettings();
        this.showNotification(`Posting frequency updated to ${frequency}`, 'success');
    }

    updateGenerationSchedule(schedule) {
        this.postingSettings.generationSchedule = schedule;
        this.savePostingSettings();
        this.showNotification(`Content generation schedule updated to ${schedule}`, 'success');
    }

    updatePublishMode(mode) {
        this.postingSettings.publishMode = mode;
        this.savePostingSettings();
        this.showNotification(`Publish mode set to ${mode === 'draft' ? 'Save as Draft' : 'Auto-Publish'}`, 'success');
    }

    // Schedule Editor Modal
    showScheduleEditor(platform) {
        // Ensure platform exists in postingSettings
        if (!this.postingSettings.platformSchedules[platform]) {
            this.postingSettings.platformSchedules[platform] = {
                times: ['9:00 AM', '1:00 PM', '7:00 PM'],
                enabled: false
            };
        }
        
        const schedule = this.postingSettings.platformSchedules[platform];
        
        // FIX: Properly evaluate the template literal
        const checkedAttribute = schedule.enabled ? 'checked' : '';
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold text-gray-800">${platform} Schedule</h3>
                        <button onclick="settingsManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <h4 class="font-medium text-gray-800">Enable Posting</h4>
                            <p class="text-sm text-gray-600">Allow auto-posting to ${platform}</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" ${schedule.enabled ? 'checked' : ''} 
                                   class="sr-only peer" onchange="settingsManager.togglePlatformPosting('${platform}', this.checked)">
                            <div class="w-11 h-6 bg-gray-200 peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                    </div>
                    
                    <div>
                        <h4 class="font-medium text-gray-800 mb-3">Optimal Posting Times</h4>
                        <div class="space-y-2" id="time-slots">
                            ${schedule.times.map((time, index) => `
                                <div class="flex items-center space-x-2 time-slot">
                                    <select class="time-select flex-1 border border-gray-300 rounded-lg p-2">
                                        ${this.generateTimeOptions(time)}
                                    </select>
                                    <button onclick="settingsManager.removeTimeSlot(this)" class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition" ${schedule.times.length <= 1 ? 'disabled' : ''}>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            `).join('')}
                        </div>
                        <button onclick="settingsManager.addTimeSlot('${platform}')" class="mt-2 text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center space-x-1">
                            <i class="fas fa-plus"></i>
                            <span>Add Time Slot</span>
                        </button>
                    </div>
                    
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 class="text-sm font-medium text-blue-800 mb-2">Best Practices</h4>
                        <ul class="text-xs text-blue-600 space-y-1">
                            <li>• Post during peak engagement hours for your audience</li>
                            <li>• Space posts 3-4 hours apart</li>
                            <li>• Test different times to find what works best</li>
                        </ul>
                    </div>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="settingsManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Cancel
                    </button>
                    <button onclick="settingsManager.savePlatformSchedule('${platform}')" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                        Save Schedule
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    generateTimeOptions(selectedTime) {
        const times = [];
        for (let hour = 0; hour < 24; hour++) {
            for (let minute = 0; minute < 60; minute += 30) {
                const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                const displayTime = this.formatTimeForDisplay(timeString);
                times.push(`<option value="${timeString}" ${timeString === this.parseTimeForStorage(selectedTime) ? 'selected' : ''}>${displayTime}</option>`);
            }
        }
        return times.join('');
    }

    formatTimeForDisplay(timeString) {
        const [hours, minutes] = timeString.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour}:${minutes} ${ampm}`;
    }

    parseTimeForStorage(displayTime) {
        const [time, period] = displayTime.split(' ');
        let [hours, minutes] = time.split(':');
        
        hours = parseInt(hours);
        if (period === 'PM' && hours < 12) hours += 12;
        if (period === 'AM' && hours === 12) hours = 0;
        
        return `${hours.toString().padStart(2, '0')}:${minutes}`;
    }

    addTimeSlot(platform) {
        const timeSlotsContainer = document.getElementById('time-slots');
        if (timeSlotsContainer.querySelectorAll('.time-slot').length >= 6) {
            this.showNotification('Maximum 6 time slots allowed per platform', 'error');
            return;
        }

        const newSlot = document.createElement('div');
        newSlot.className = 'flex items-center space-x-2 time-slot';
        newSlot.innerHTML = `
            <select class="time-select flex-1 border border-gray-300 rounded-lg p-2">
                ${this.generateTimeOptions('9:00 AM')}
            </select>
            <button onclick="settingsManager.removeTimeSlot(this)" class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        timeSlotsContainer.appendChild(newSlot);
    }

    removeTimeSlot(button) {
        const timeSlots = button.closest('#time-slots').querySelectorAll('.time-slot');
        if (timeSlots.length <= 1) {
            this.showNotification('At least one time slot is required', 'error');
            return;
        }
        button.closest('.time-slot').remove();
    }

    togglePlatformPosting(platform, enabled) {
        console.log(`Toggling ${platform} posting: ${enabled}`);
        
        // Ensure the platform exists in postingSettings
        if (!this.postingSettings.platformSchedules[platform]) {
            this.postingSettings.platformSchedules[platform] = {
                times: ['9:00 AM', '1:00 PM', '7:00 PM'],
                enabled: enabled
            };
        } else {
            this.postingSettings.platformSchedules[platform].enabled = enabled;
        }
        
        // Save the settings immediately
        this.savePostingSettings();
        
        // Update the UI to reflect the change
        this.updatePlatformScheduleDisplays();
        
        this.showNotification(`${platform} posting ${enabled ? 'enabled' : 'disabled'}`, 'success');
    }

    savePlatformSchedule(platform) {
        const timeSlots = document.querySelectorAll('#time-slots .time-slot');
        const times = Array.from(timeSlots).map(slot => {
            const timeValue = slot.querySelector('.time-select').value;
            return this.formatTimeForDisplay(timeValue);
        });

        // Get the enabled state from the toggle
        const enabledToggle = document.querySelector('input[type="checkbox"]');
        const enabled = enabledToggle ? enabledToggle.checked : true;

        // Update the platform schedule
        this.postingSettings.platformSchedules[platform] = {
            times: times,
            enabled: enabled
        };
        
        this.savePostingSettings();
        this.updatePlatformScheduleDisplays();
        this.closeModal();
        this.showNotification(`${platform} schedule updated successfully!`, 'success');
    }

    savePostingSettings() {
        localStorage.setItem('socialgenius_posting_settings', JSON.stringify(this.postingSettings));
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.settingsManager = new SettingsManager();
});

// Add CSS for dynamic elements
const dynamicStyles = document.createElement('style');
dynamicStyles.textContent = `
    .notification { 
        background: linear-gradient(135deg, #3b82f6, #2563eb); 
        position: fixed;
        top: 1rem;
        right: 1rem;
        padding: 1rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        color: white;
        font-weight: 500;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 400px;
    }
    
    .notification.show { 
        transform: translateX(0); 
    }
    
    .notification.success { 
        background: linear-gradient(135deg, #10b981, #059669); 
    }
    
    .notification.error { 
        background: linear-gradient(135deg, #ef4444, #dc2626); 
    }
    
    .notification.warning { 
        background: linear-gradient(135deg, #f59e0b, #d97706); 
    }
    
    .notification.info { 
        background: linear-gradient(135deg, #3b82f6, #2563eb); 
    }
    
    .modal-content { transition: all 0.3s ease; }
    .modal-content.modal-open { opacity: 1; transform: scale(1); }
    
    .selected { border-color: #3b82f6 !important; background-color: #eff6ff !important; }
    
    .status-text { transition: all 0.3s ease; }
    
    .password-strength .strength-bar { background: #e5e7eb; }
    .verification-code { letter-spacing: 0.5em; }
    
    /* Device icons */
    .fa-globe { color: #3b82f6; }
    .fa-compass { color: #10b981; }
    .fa-firefox { color: #f59e0b; }
    .fa-mobile-alt { color: #8b5cf6; }
    .fa-laptop { color: #6b7280; }
    
    /* 2FA Method Selection */
    input[name="auth-method"]:checked + label { 
        border-color: #3b82f6;
        background-color: #eff6ff;
    }
    
    /* Save button animations */
    .save-button-container {
        transition: all 0.3s ease;
    }
    
    .save-display-name-btn {
        transition: all 0.3s ease;
    }
    
    .save-display-name-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
    
    .save-display-name-btn:not(:disabled):hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
    }
`;
document.head.appendChild(dynamicStyles);