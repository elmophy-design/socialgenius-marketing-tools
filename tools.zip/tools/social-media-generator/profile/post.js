// Quick Post & Analytics Modal Functionality with Enhanced Template Features
document.addEventListener('DOMContentLoaded', function() {
    const quickPostBtn = document.getElementById('quickPostBtn');
    const analyticsBtn = document.getElementById('analyticsBtn');
    const viewAnalyticsBtn = document.getElementById('viewAnalyticsBtn');
    const quickPostModal = document.getElementById('quickPostModal');
    const analyticsModal = document.getElementById('analyticsModal');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const mediaUploadArea = document.getElementById('mediaUploadArea');
    const mediaUpload = document.getElementById('mediaUpload');
    const platformOptions = document.querySelectorAll('.platform-option');
    const templateOptions = document.querySelectorAll('.template-card');
    const timeSlots = document.querySelectorAll('.time-slot');
    const generateContentBtn = document.getElementById('generateContent');
    const schedulePostBtn = document.getElementById('schedulePost');
    const publishNowBtn = document.getElementById('publishNow');
    const hashtagChips = document.querySelectorAll('.hashtag-chip');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const closeFeaturesBtn = document.getElementById('closeFeatures');
    const clearAllFeaturesBtn = document.getElementById('clearAllFeatures');
    const useTemplateBtn = document.getElementById('useTemplateBtn');

    // Template elements
    const templateFeatures = document.getElementById('templateFeatures');
    const featuresGrid = document.getElementById('featuresGrid');
    const featuresTitle = document.getElementById('featuresTitle');
    const appliedFeatures = document.getElementById('appliedFeatures');
    const appliedList = document.getElementById('appliedList');
    const postContent = document.getElementById('postContent');

    // Settings ID Elements - Simple navigation only
    const settingsBtn = document.getElementById('settingsBtn');

    let selectedTemplate = null;
    let appliedFeaturesList = [];

    // Check if elements exist before adding event listeners
    function safeAddEventListener(element, event, handler) {
        if (element) {
            element.addEventListener(event, handler);
        }
    }

    // Settings button - simple navigation to settings page
    safeAddEventListener(settingsBtn, 'click', function() {
        window.location.href = 'settings.html';
    });

    // Open Quick Post Modal
    safeAddEventListener(quickPostBtn, 'click', function() {
        if (quickPostModal) {
            quickPostModal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    });

    // Open Analytics Modal
    safeAddEventListener(analyticsBtn, 'click', function() {
        if (analyticsModal) {
            analyticsModal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            // Initialize with zero data
            initializeZeroAnalytics();
        }
    });

    safeAddEventListener(viewAnalyticsBtn, 'click', function() {
        if (analyticsModal) {
            analyticsModal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            // Initialize with zero data
            initializeZeroAnalytics();
        }
    });

    // Close Modals
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            if (quickPostModal) quickPostModal.style.display = 'none';
            if (analyticsModal) analyticsModal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    });

    // Close modals when clicking outside
    [quickPostModal, analyticsModal].forEach(modal => {
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            });
        }
    });

    // Close features section
    safeAddEventListener(closeFeaturesBtn, 'click', function() {
        if (templateFeatures) {
            templateFeatures.classList.remove('active');
            
            // Deselect all template options
            templateOptions.forEach(opt => {
                opt.classList.remove('selected');
            });
        }
    });

    // Clear all applied features
    safeAddEventListener(clearAllFeaturesBtn, 'click', function() {
        appliedFeaturesList = [];
        updateAppliedFeatures();
        if (postContent) postContent.value = '';
        
        // Remove active class from all feature cards
        document.querySelectorAll('.feature-card').forEach(card => {
            card.classList.remove('active');
        });
    });

    // Platform Selection
    platformOptions.forEach(option => {
        option.addEventListener('click', function() {
            this.classList.toggle('selected');
        });
    });

    // Template Selection
    templateOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            templateOptions.forEach(opt => opt.classList.remove('selected'));
            
            // Add selected class to clicked option
            this.classList.add('selected');
            
            // Set selected template
            selectedTemplate = this.getAttribute('data-template');
            
            // Show template features
            showTemplateFeatures(selectedTemplate);
        });
    });

    // Use template button
    safeAddEventListener(useTemplateBtn, 'click', function() {
        if (selectedTemplate) {
            const templateData = getTemplateData(selectedTemplate);
            if (postContent) {
                postContent.value = templateData.sampleContent;
                showNotification(`"${templateData.name}" template applied!`, 'success');
            }
        }
    });

    // Time Slot Selection
    timeSlots.forEach(slot => {
        slot.addEventListener('click', function() {
            timeSlots.forEach(s => s.classList.remove('selected'));
            this.classList.add('selected');
        });
    });

    // Hashtag Selection
    hashtagChips.forEach(chip => {
        chip.addEventListener('click', function() {
            if (postContent) {
                const hashtag = this.textContent;
                postContent.value += ` ${hashtag}`;
            }
        });
    });

    // Media Upload
    if (mediaUploadArea && mediaUpload) {
        mediaUploadArea.addEventListener('click', function() {
            mediaUpload.click();
        });

        mediaUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });

        mediaUploadArea.addEventListener('dragleave', function() {
            this.classList.remove('dragover');
        });

        mediaUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            const files = e.dataTransfer.files;
            handleMediaFiles(files);
        });

        mediaUpload.addEventListener('change', function(e) {
            handleMediaFiles(e.target.files);
        });

        function handleMediaFiles(files) {
            if (files && files.length > 0) {
                mediaUploadArea.innerHTML = `
                    <i class="fas fa-check text-green-500 text-3xl mb-2"></i>
                    <div class="font-medium">${files.length} file(s) selected</div>
                    <div class="text-sm text-gray-600">Ready to upload</div>
                `;
            }
        }
    }

    // AI Content Generation
    safeAddEventListener(generateContentBtn, 'click', function() {
        if (!loadingOverlay) return;
        
        loadingOverlay.classList.remove('hidden');
        
        setTimeout(() => {
            if (postContent) {
                if (appliedFeaturesList.length > 0) {
                    // Combine applied features content
                    let combinedContent = '';
                    appliedFeaturesList.forEach(feature => {
                        combinedContent += feature.sampleContent + '\n\n';
                    });
                    postContent.value = combinedContent.trim();
                    showNotification('AI content generated based on applied features!', 'success');
                } else {
                    const selectedTemplateOption = document.querySelector('.template-option.selected');
                    const templateType = selectedTemplateOption ? selectedTemplateOption.dataset.template : 'general';
                    
                    const templates = {
                        promotion: "🚀 LIMITED TIME OFFER! Get 25% OFF our premium plan this week only! Don't miss this amazing deal to boost your social media presence! #Sale #Discount #LimitedTime",
                        announcement: "📢 BIG NEWS! We're excited to announce our new AI-powered analytics feature! Get deeper insights into your social media performance. #NewFeature #Update #SocialMedia",
                        engagement: "🤔 QUESTION OF THE DAY: What's your biggest social media challenge? Share in the comments below and let's help each other grow! 👇 #Engagement #Community #QandA",
                        educational: "💡 DID YOU KNOW? Posts with videos get 48% more views than image posts! Try incorporating more video content in your strategy. #SocialMediaTips #MarketingTips",
                        general: "🌟 Transform your social media strategy with AI-powered content! Our analytics show a 45% increase in engagement for businesses using automated posting. #AIContent #DigitalMarketing"
                    };
                    
                    postContent.value = templates[templateType] || templates.general;
                    showNotification('AI content generated!', 'success');
                }
            }
            loadingOverlay.classList.add('hidden');
        }, 2000);
    });

    // Schedule Post
    safeAddEventListener(schedulePostBtn, 'click', function() {
        if (validatePost()) {
            showNotification('Post scheduled successfully!', 'success');
            if (quickPostModal) {
                quickPostModal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }
    });

    // Publish Now
    safeAddEventListener(publishNowBtn, 'click', function() {
        if (validatePost()) {
            showNotification('Post published across selected platforms!', 'success');
            if (quickPostModal) {
                quickPostModal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }
    });

    // Validation function
    function validatePost() {
        const selectedPlatforms = document.querySelectorAll('.platform-option.selected');
        
        if (selectedPlatforms.length === 0) {
            showNotification('Please select at least one platform', 'error');
            return false;
        }
        
        if (!postContent || !postContent.value.trim()) {
            showNotification('Please add some content to your post', 'error');
            return false;
        }
        
        return true;
    }

    // Show template features based on selected template
    function showTemplateFeatures(templateId) {
        const templateData = getTemplateData(templateId);
        
        if (!featuresGrid || !featuresTitle) return;
        
        // Update features title
        featuresTitle.textContent = `${templateData.name} Features`;
        
        // Clear previous features
        featuresGrid.innerHTML = '';
        
        // Add new features
        templateData.features.forEach(feature => {
            const featureCard = document.createElement('div');
            featureCard.className = 'feature-card';
            featureCard.setAttribute('data-feature', feature.id);
            
            // Check if feature is already applied
            const isApplied = appliedFeaturesList.some(f => f.id === feature.id);
            if (isApplied) {
                featureCard.classList.add('active');
            }
            
            featureCard.innerHTML = `
                <button class="feature-close" data-feature="${feature.id}">
                    <i class="fas fa-times"></i>
                </button>
                <div class="feature-icon ${feature.iconColor}">
                    <i class="${feature.icon}"></i>
                </div>
                <div class="feature-title">${feature.name}</div>
                <div class="feature-description">${feature.description}</div>
                <div class="feature-metrics">
                    <div class="feature-metric positive">
                        <i class="fas fa-chart-line"></i>
                        <span>${feature.performance}</span>
                    </div>
                    <div class="feature-metric">
                        <i class="fas fa-clock"></i>
                        <span>${feature.setupTime}</span>
                    </div>
                </div>
                <div class="platform-optimization">
                    ${feature.platforms.map(platform => 
                        `<div class="platform-badge ${platform}"><i class="fab fa-${platform}"></i></div>`
                    ).join('')}
                </div>
                <button class="btn btn-primary btn-sm mt-2 w-full apply-feature" data-feature="${feature.id}">
                    Apply Feature
                </button>
            `;
            
            featuresGrid.appendChild(featureCard);
            
            // Add click event to apply feature button
            const applyBtn = featureCard.querySelector('.apply-feature');
            applyBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                applyFeature(feature);
            });
            
            // Add click event to close button
            const closeBtn = featureCard.querySelector('.feature-close');
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                removeFeature(feature.id);
            });
            
            // Add click event to feature card
            featureCard.addEventListener('click', function() {
                applyFeature(feature);
            });
        });
        
        // Show the template features section
        if (templateFeatures) {
            templateFeatures.classList.add('active');
        }
    }
    
    // Apply feature to content editor
    function applyFeature(feature) {
        // Check if feature is already applied
        if (!appliedFeaturesList.some(f => f.id === feature.id)) {
            appliedFeaturesList.push(feature);
            updateAppliedFeatures();
        }
        
        // Update content with feature sample
        if (postContent) {
            postContent.value = feature.sampleContent;
        }
        
        // Mark feature as active in the grid
        const featureCard = document.querySelector(`.feature-card[data-feature="${feature.id}"]`);
        if (featureCard) {
            featureCard.classList.add('active');
        }
        
        // Show success message
        showNotification(`"${feature.name}" feature applied!`, 'success');
    }
    
    // Remove feature from applied list
    function removeFeature(featureId) {
        appliedFeaturesList = appliedFeaturesList.filter(f => f.id !== featureId);
        updateAppliedFeatures();
        
        // Remove active class from feature card
        const featureCard = document.querySelector(`.feature-card[data-feature="${featureId}"]`);
        if (featureCard) {
            featureCard.classList.remove('active');
        }
        
        // Show notification
        showNotification('Feature removed', 'info');
    }
    
    // Update applied features display
    function updateAppliedFeatures() {
        if (!appliedList || !appliedFeatures) return;
        
        // Clear applied list
        appliedList.innerHTML = '';
        
        // Add applied features
        appliedFeaturesList.forEach(feature => {
            const featureTag = document.createElement('div');
            featureTag.className = 'applied-feature-tag';
            featureTag.innerHTML = `
                ${feature.name}
                <button class="remove-feature" data-feature="${feature.id}">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            appliedList.appendChild(featureTag);
            
            // Add click event to remove button
            const removeBtn = featureTag.querySelector('.remove-feature');
            removeBtn.addEventListener('click', function() {
                removeFeature(feature.id);
            });
        });
        
        // Show/hide applied features section
        if (appliedFeaturesList.length > 0) {
            appliedFeatures.classList.add('active');
        } else {
            appliedFeatures.classList.remove('active');
        }
    }

    // Get template data
    function getTemplateData(templateId) {
        const templates = {
            'promotion': {
                name: 'Promotional Templates',
                sampleContent: '🚨 SPECIAL OFFER! 🚨 Limited time only - get amazing deals on our premium products. Shop now and save!',
                features: [
                    {
                        id: 'flash-sale',
                        name: 'Flash Sale Engine',
                        description: 'Creates urgency with countdown and FOMO triggers',
                        icon: 'fas fa-bolt',
                        iconColor: 'bg-gradient-to-r from-purple-500 to-pink-500 text-white',
                        performance: '+42% CTR',
                        setupTime: '2 min',
                        platforms: ['instagram', 'facebook'],
                        sampleContent: '🚨 FLASH SALE! 🚨 Only 24 hours to save 40% on our premium collection. Limited stock available - shop now before it\'s gone! ⏰'
                    },
                    {
                        id: 'product-launch',
                        name: 'Product Launch',
                        description: 'Build hype and drive pre-orders',
                        icon: 'fas fa-rocket',
                        iconColor: 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white',
                        performance: '+35% Engagement',
                        setupTime: '3 min',
                        platforms: ['instagram', 'linkedin'],
                        sampleContent: 'The wait is almost over! Our revolutionary new product launches next week. Be the first to experience innovation. Pre-order now!'
                    },
                    {
                        id: 'discount-campaign',
                        name: 'Discount Campaign',
                        description: 'Multiple approaches for discount types',
                        icon: 'fas fa-percentage',
                        iconColor: 'bg-gradient-to-r from-green-500 to-teal-500 text-white',
                        performance: '+28% Conversions',
                        setupTime: '2 min',
                        platforms: ['instagram', 'facebook'],
                        sampleContent: 'Buy One Get One 50% Off! Stock up on your favorites and save big. Limited time offer - shop the sale now!'
                    }
                ]
            },
            'announcement': {
                name: 'Announcement Templates',
                sampleContent: 'We have exciting news to share! Stay tuned for our big announcement coming soon...',
                features: [
                    {
                        id: 'company-news',
                        name: 'Company News',
                        description: 'Corporate updates as engaging stories',
                        icon: 'fas fa-newspaper',
                        iconColor: 'bg-gradient-to-r from-blue-400 to-cyan-500 text-white',
                        performance: '+25% Engagement',
                        setupTime: '2 min',
                        platforms: ['linkedin', 'twitter'],
                        sampleContent: 'We\'re thrilled to announce our Series B funding round! This milestone will accelerate our mission to revolutionize the industry.'
                    },
                    {
                        id: 'event-announcement',
                        name: 'Event Announcement',
                        description: 'Complete event marketing kits',
                        icon: 'fas fa-calendar-alt',
                        iconColor: 'bg-gradient-to-r from-purple-400 to-pink-500 text-white',
                        performance: '+38% Registrations',
                        setupTime: '3 min',
                        platforms: ['linkedin', 'facebook'],
                        sampleContent: 'Join us for our annual conference featuring industry leaders and cutting-edge insights. Register now for early bird pricing!'
                    },
                    {
                        id: 'partnership-reveal',
                        name: 'Partnership Reveal',
                        description: 'Announce collaborations that excite',
                        icon: 'fas fa-handshake',
                        iconColor: 'bg-gradient-to-r from-indigo-400 to-purple-500 text-white',
                        performance: '+45% Engagement',
                        setupTime: '2 min',
                        platforms: ['linkedin', 'instagram'],
                        sampleContent: 'We\'re teaming up with [Partner Name] to bring you something extraordinary! Stay tuned for the big reveal next week.'
                    }
                ]
            },
            'engagement': {
                name: 'Engagement Templates',
                sampleContent: 'What\'s your opinion on this? Share your thoughts in the comments below! 👇',
                features: [
                    {
                        id: 'question-architect',
                        name: 'Question Architect',
                        description: 'Polls, AMA formats, discussions',
                        icon: 'fas fa-question-circle',
                        iconColor: 'bg-gradient-to-r from-pink-400 to-rose-500 text-white',
                        performance: '+78% Comments',
                        setupTime: '1 min',
                        platforms: ['instagram', 'twitter'],
                        sampleContent: 'What\'s your biggest productivity challenge? A) Time management B) Distractions C) Motivation D) Organization (Comment below!)'
                    },
                    {
                        id: 'ugc-campaign',
                        name: 'UGC Campaign',
                        description: 'Encourage user-generated content',
                        icon: 'fas fa-users',
                        iconColor: 'bg-gradient-to-r from-purple-400 to-fuchsia-500 text-white',
                        performance: '+92% UGC',
                        setupTime: '3 min',
                        platforms: ['instagram'],
                        sampleContent: 'Show us how you use our product! Share a photo with #MyBrandStory for a chance to be featured on our page and win a prize!'
                    },
                    {
                        id: 'interactive-content',
                        name: 'Interactive Content',
                        description: 'Quizzes, challenges, gamified posts',
                        icon: 'fas fa-gamepad',
                        iconColor: 'bg-gradient-to-r from-yellow-400 to-amber-500 text-white',
                        performance: '+67% Interaction',
                        setupTime: '4 min',
                        platforms: ['instagram', 'facebook'],
                        sampleContent: 'What\'s your marketing personality? Take our quick quiz to find out if you\'re a Strategist, Creator, Analyst, or Connector!'
                    }
                ]
            },
            'educational': {
                name: 'Educational Templates',
                sampleContent: 'Did you know these 3 simple tips can transform your workflow? Read on to learn more...',
                features: [
                    {
                        id: 'how-to-guide',
                        name: 'How-To Guide',
                        description: 'Break down complex topics',
                        icon: 'fas fa-list-ol',
                        iconColor: 'bg-gradient-to-r from-green-400 to-emerald-500 text-white',
                        performance: '+65% Saves',
                        setupTime: '4 min',
                        platforms: ['instagram', 'linkedin'],
                        sampleContent: '5 simple steps to optimize your workflow: 1. Plan your day 2. Prioritize tasks 3. Eliminate distractions 4. Take breaks 5. Review progress'
                    },
                    {
                        id: 'tips-tricks',
                        name: 'Tips & Tricks',
                        description: 'Valuable bite-sized insights',
                        icon: 'fas fa-lightbulb',
                        iconColor: 'bg-gradient-to-r from-teal-400 to-cyan-500 text-white',
                        performance: '+48% Shares',
                        setupTime: '1 min',
                        platforms: ['twitter', 'instagram'],
                        sampleContent: 'Pro tip: Use the 2-minute rule - if a task takes less than 2 minutes, do it immediately. This prevents small tasks from piling up!'
                    },
                    {
                        id: 'industry-insights',
                        name: 'Industry Insights',
                        description: 'Showcase expertise and trends',
                        icon: 'fas fa-chart-line',
                        iconColor: 'bg-gradient-to-r from-blue-400 to-indigo-500 text-white',
                        performance: '+33% Authority',
                        setupTime: '3 min',
                        platforms: ['linkedin', 'twitter'],
                        sampleContent: 'The future of AI in marketing: Personalization at scale, predictive analytics, and automated content creation will redefine customer experiences.'
                    }
                ]
            }
        };
        
        return templates[templateId] || {};
    }

    // Initialize Analytics with Zero Data
    function initializeZeroAnalytics() {
        const zeroData = {
            totalReach: 0,
            engagementRate: '0.0',
            newFollowers: 0,
            platforms: {},
            topContent: [],
            audienceData: {
                "18-24": 0,
                "25-34": 0,
                "35-44": 0,
                "45-54": 0,
                "55+": 0
            },
            engagementMetrics: {
                likes: 0,
                comments: 0,
                shares: 0,
                saves: 0
            }
        };

        // Update analytics UI with zero data
        updateAnalyticsUI(zeroData);
        
        // Show API integration message
        showAPIIntegrationMessage();
    }

    // Update UI with analytics data
    function updateAnalyticsUI(data) {
        // Update overview metrics
        updateMetricCard('.metric-card:nth-child(1) .metric-value', formatNumber(data.totalReach));
        updateMetricCard('.metric-card:nth-child(2) .metric-value', data.engagementRate + '%');
        updateMetricCard('.metric-card:nth-child(3) .metric-value', formatNumber(data.newFollowers));

        // Update engagement metrics
        updateEngagementMetrics(data.engagementMetrics);

        // Update top performing content (empty)
        updateTopContent(data.topContent);

        // Update audience demographics (all zero)
        updateAudienceDemographics(data.audienceData);
    }

    // Show API integration message
    function showAPIIntegrationMessage() {
        // Add a message about API integration
        const existingMessage = document.querySelector('.api-integration-message');
        if (existingMessage) existingMessage.remove();

        const message = document.createElement('div');
        message.className = 'api-integration-message fixed bottom-4 left-4 right-4 bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center z-40';
        message.innerHTML = `
            <div class="flex items-center justify-center space-x-2 text-yellow-800">
                <i class="fas fa-info-circle"></i>
                <span>Analytics data will appear here once you integrate with social media APIs</span>
            </div>
        `;
        
        document.body.appendChild(message);
        
        // Remove message after 5 seconds
        setTimeout(() => {
            message.remove();
        }, 5000);
    }

    // Helper functions for UI updates
    function updateMetricCard(selector, value) {
        const element = document.querySelector(selector);
        if (element) element.textContent = value;
    }

    function updateTopContent(topContent) {
        const contentContainer = document.querySelector('.content-performance');
        if (!contentContainer) return;
        
        if (topContent.length === 0) {
            contentContainer.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-chart-bar text-3xl mb-2"></i>
                    <p>No performance data available</p>
                    <p class="text-sm mt-2">Connect accounts and integrate APIs to see analytics</p>
                </div>
            `;
        }
    }

    function updateAudienceDemographics(demographics) {
        const chartContainer = document.querySelector('.demographic-chart');
        if (!chartContainer) return;
        
        chartContainer.innerHTML = Object.entries(demographics).map(([ageGroup, percentage]) => `
            <div class="demographic-bar" style="height: ${percentage}%">
                <div class="demographic-label">${ageGroup}</div>
                <div class="demographic-value">${percentage}%</div>
            </div>
        `).join('');
    }

    function updateEngagementMetrics(metrics) {
        const engagementGrid = document.querySelector('.grid.grid-cols-2.md\\:grid-cols-4.gap-4');
        if (!engagementGrid) return;
        
        engagementGrid.innerHTML = `
            <div class="text-center p-4 bg-gray-50 rounded-lg">
                <div class="text-2xl font-bold text-blue-600">${formatNumber(metrics.likes)}</div>
                <div class="text-sm text-gray-600">Likes</div>
            </div>
            <div class="text-center p-4 bg-gray-50 rounded-lg">
                <div class="text-2xl font-bold text-green-600">${formatNumber(metrics.comments)}</div>
                <div class="text-sm text-gray-600">Comments</div>
            </div>
            <div class="text-center p-4 bg-gray-50 rounded-lg">
                <div class="text-2xl font-bold text-purple-600">${formatNumber(metrics.shares)}</div>
                <div class="text-sm text-gray-600">Shares</div>
            </div>
            <div class="text-center p-4 bg-gray-50 rounded-lg">
                <div class="text-2xl font-bold text-orange-600">${formatNumber(metrics.saves)}</div>
                <div class="text-sm text-gray-600">Saves</div>
            </div>
        `;
    }

    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    // Notification function
    function showNotification(message, type = 'info') {
        const existingNotifications = document.querySelectorAll('.custom-notification');
        existingNotifications.forEach(notification => notification.remove());
        
        const notification = document.createElement('div');
        notification.className = `custom-notification fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-500' : 
            type === 'error' ? 'bg-red-500' : 'bg-blue-500'
        } text-white`;
        notification.innerHTML = `
            <div class="flex items-center space-x-2">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // Close modals with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (quickPostModal) quickPostModal.style.display = 'none';
            if (analyticsModal) analyticsModal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    // Initialize dashboard with zero values
    function initializeDashboard() {
        const connectedCount = document.getElementById('connectedCount');
        const postsCount = document.getElementById('postsCount');
        const engagementRate = document.getElementById('engagementRate');
        const scheduledCount = document.getElementById('scheduledCount');
        
        if (connectedCount) connectedCount.textContent = '0';
        if (postsCount) postsCount.textContent = '0';
        if (engagementRate) engagementRate.textContent = '0%';
        if (scheduledCount) scheduledCount.textContent = '0';
    }

    // Initialize everything when page loads
    initializeDashboard();
});