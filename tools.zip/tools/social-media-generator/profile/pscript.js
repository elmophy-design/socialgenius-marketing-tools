// Profile dropdown functionality - Updated for View Profile with Global Profile Sync
document.addEventListener('DOMContentLoaded', function() {
  // ==================== ELEMENT SELECTORS ====================
  
  // Profile Dropdown Elements
  const profileDropdownBtn = document.getElementById('profileDropdownBtn');
  const profileDropdownContent = document.getElementById('profileDropdownContent');
  const viewProfileBtn = document.getElementById('viewProfileBtn');
  const accountSettingsBtn = document.getElementById('accountSettingsBtn');
  const logoutBtn = document.getElementById('logoutBtn');

  // Profile Modal Elements (Now View Profile Modal)
  const profileModal = document.getElementById('profileModal');
  const closeProfileModal = document.getElementById('closeProfileModal');
  const closeProfileView = document.getElementById('closeProfileView');
  const editProfileFromView = document.getElementById('editProfileFromView');
  const userName = document.getElementById('userName');
  const dropdownUserName = document.getElementById('dropdownUserName');
  const dropdownUserEmail = document.getElementById('dropdownUserEmail');
  const profilePicture = document.getElementById('profilePicture');
  const profilePictureSmall = document.getElementById('profilePictureSmall');
  const profilePictureLarge = document.getElementById('profilePictureLarge');

  // Profile Display Elements
  const profileNameDisplay = document.getElementById('profileNameDisplay');
  const profileEmailDisplay = document.getElementById('profileEmailDisplay');
  const profileBioDisplay = document.getElementById('profileBioDisplay');
  const profileTimezoneDisplay = document.getElementById('profileTimezoneDisplay');

  // Account Settings Modal Elements
  const accountSettingsModal = document.getElementById('accountSettingsModal');
  const closeAccountSettingsModal = document.getElementById('closeAccountSettingsModal');
  const cancelAccountSettings = document.getElementById('cancelAccountSettings');
  const saveAccountSettings = document.getElementById('saveAccountSettings');

  // ==================== GLOBAL PROFILE SYNC FUNCTIONS ====================

  // Global function to update profile picture across the entire app
  window.updateProfilePictureEverywhere = function(imageData) {
    // Update in settings manager if it exists
    if (window.settingsManager) {
      window.settingsManager.updateProfilePictureAcrossApp(imageData);
    } else {
      // Fallback: update localStorage and refresh visible elements
      localStorage.setItem('socialgenius_profile_image', imageData);
      refreshVisibleProfilePictures();
    }
  };

  // Global function to update user profile name across the entire app
  window.updateUserProfileNameEverywhere = function(newName) {
    // Save user name to localStorage
    localStorage.setItem('userName', newName);
    
    // Update in settings manager if it exists
    if (window.settingsManager) {
      window.settingsManager.updateUserNameAcrossApp(newName);
    } else {
      // Fallback: refresh visible elements
      refreshVisibleUserNames();
    }
    
    // NEW: Also update the default author name to match
    updateDefaultAuthorNameFromProfile(newName);
  };

  // NEW: Update default author name when profile name changes
  function updateDefaultAuthorNameFromProfile(profileName) {
    // Save to localStorage
    localStorage.setItem('defaultAuthorName', profileName);
    
    // Update the default author name input field
    refreshDefaultAuthorNames();
  }

  // Helper function to refresh visible profile pictures
  function refreshVisibleProfilePictures() {
    const imageData = localStorage.getItem('socialgenius_profile_image');
    
    // Update all profile picture elements
    const profileElements = [
      profilePicture,
      profilePictureSmall,
      profilePictureLarge,
      ...document.querySelectorAll(`
        .profile-picture,
        .profile-picture-large,
        .profile-picture-small,
        [data-profile-picture]
      `)
    ].filter(el => el);

    profileElements.forEach(element => {
      if (!element) return;
      
      if (element.tagName === 'IMG') {
        if (imageData) {
          element.src = imageData;
        }
      } else {
        element.innerHTML = '';
        if (imageData) {
          const img = document.createElement('img');
          img.src = imageData;
          img.className = 'w-full h-full object-cover rounded-full';
          img.alt = 'Profile picture';
          element.appendChild(img);
        } else {
          const icon = document.createElement('i');
          icon.className = 'fas fa-user text-white text-xl';
          element.appendChild(icon);
        }
      }
    });
  }

  // Helper function to refresh visible user names (profile names)
  function refreshVisibleUserNames() {
    const userName = localStorage.getItem('userName') || 'Prime Alpha';
    
    // Update all user name elements (profile display names)
    const nameElements = [
      dropdownUserName,
      profileNameDisplay,
      ...document.querySelectorAll(`
        .user-name,
        [data-user-name],
        .profile-name
      `)
    ].filter(el => el);
    
    nameElements.forEach(element => {
      if (element) {
        element.textContent = userName;
      }
    });
  }

  // Helper function to refresh default author names (for posting)
  function refreshDefaultAuthorNames() {
    const authorName = localStorage.getItem('defaultAuthorName') || localStorage.getItem('userName') || 'SocialGenius Team';
    
    // Update default author name input field
    const authorNameInput = document.querySelector('input[value="SocialGenius Team"]');
    if (authorNameInput) {
      authorNameInput.value = authorName;
    }
    
    // Update any other instances of default author name
    const authorNameElements = document.querySelectorAll('[data-default-author]');
    authorNameElements.forEach(element => {
      element.textContent = authorName;
    });
  }

  // Listen for storage changes to sync profile data across tabs
  window.addEventListener('storage', (e) => {
    if (e.key === 'socialgenius_profile_image') {
      refreshVisibleProfilePictures();
    }
    if (e.key === 'userName') {
      refreshVisibleUserNames();
      // NEW: Also update default author name when user name changes
      updateDefaultAuthorNameFromProfile(e.newValue || 'Prime Alpha');
    }
    if (e.key === 'defaultAuthorName') {
      refreshDefaultAuthorNames();
    }
  });

  // Initialize profile sync when page loads
  function initializeProfileSync() {
    // Load any saved profile data
    setTimeout(() => {
      refreshVisibleProfilePictures();
      refreshVisibleUserNames();
      refreshDefaultAuthorNames();
      
      // NEW: If no default author name is set, use the user name
      if (!localStorage.getItem('defaultAuthorName') && localStorage.getItem('userName')) {
        updateDefaultAuthorNameFromProfile(localStorage.getItem('userName'));
      }
    }, 500);
  }

  // Add this function to your Global Profile Sync Functions section
  function refreshViewProfileModal() {
      // If the profile modal is currently open, reload the data
      if (profileModal && profileModal.classList.contains('show')) {
          loadProfileData();
      }
  }

  // Also update the refreshVisibleUserNames function to call this:
  function refreshVisibleUserNames() {
      const userName = localStorage.getItem('userName') || 'Prime Alpha';
      
      // Update all user name elements (profile display names)
      const nameElements = [
          dropdownUserName,
          profileNameDisplay,
          ...document.querySelectorAll(`
          .user-name,
          [data-user-name],
          .profile-name
          `)
      ].filter(el => el);
      
      nameElements.forEach(element => {
          if (element) {
              element.textContent = userName;
          }
      });
      
      // NEW: Also refresh the view profile modal if it's open
      refreshViewProfileModal();
  }

  // ==================== PROFILE DROPDOWN FUNCTIONALITY ====================
  
  // Toggle dropdown
  profileDropdownBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    profileDropdownContent.classList.toggle('show');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', function() {
    profileDropdownContent.classList.remove('show');
  });

  // ==================== VIEW PROFILE MODAL FUNCTIONALITY ====================

  // Enhanced loadProfileData function with real user data
  function loadProfileData() {
    // Get subscription data from SubscriptionManager
    const subscriptionManager = window.subscriptionManager;
    const currentPlan = subscriptionManager ? subscriptionManager.getCurrentPlan() : null;
    const subscriptionData = subscriptionManager ? subscriptionManager.subscription : { plan: 'trial' };
    
    // Get social accounts data
    const socialAccounts = JSON.parse(localStorage.getItem('socialgenius_social_accounts') || '{}');
    const connectedCount = Object.values(socialAccounts).filter(acc => acc.connected).length;

    // Get user data from localStorage
    const userName = localStorage.getItem('userName') || 'Prime Alpha';
    const userEmail = localStorage.getItem('userEmail') || 'john.doe@example.com';
    const savedProfileImage = localStorage.getItem('socialgenius_profile_image');
    const defaultAuthorName = localStorage.getItem('defaultAuthorName') || userName; // Use userName as fallback

    const userData = {
      name: userName,
      email: userEmail,
      timezone: "est",
      subscription: currentPlan ? currentPlan.name : "Free Trial",
      memberSince: "January 15, 2024",
      connectedAccounts: connectedCount,
      postsThisMonth: 127,
      engagementRate: "24%",
      planType: subscriptionData.plan,
      maxAccounts: currentPlan ? currentPlan.limitations.maxAccounts : 1,
      defaultAuthorName: defaultAuthorName // NEW: Include default author name
    };

    // Update display elements with real data
    if (profileNameDisplay) profileNameDisplay.textContent = userData.name;
    if (profileEmailDisplay) profileEmailDisplay.textContent = userData.email;
    
    // Update timezone display
    const timezoneMap = {
      'est': 'Eastern Time (ET)',
      'cst': 'Central Time (CT)',
      'mst': 'Mountain Time (MT)',
      'pst': 'Pacific Time (PT)'
    };
    if (profileTimezoneDisplay) {
      profileTimezoneDisplay.textContent = timezoneMap[userData.timezone] || 'Eastern Time (ET)';
    }

    // Close profile modal
    function closeProfileModalFunc() {
      profileModal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }
  
  closeProfileModal.addEventListener('click', closeProfileModalFunc);
  closeProfileView.addEventListener('click', closeProfileModalFunc);

    
    // Update account stats with dynamic subscription data
    const subscriptionElement = document.querySelector('.stat-card:nth-child(1) .stat-value');
    const accountsElement = document.querySelector('.stat-card:nth-child(2) .stat-value');
    
    if (subscriptionElement) {
      subscriptionElement.textContent = userData.subscription;
    }
    
    if (accountsElement) {
      if (userData.maxAccounts === null) {
        accountsElement.textContent = `${userData.connectedAccounts}/Unlimited`;
      } else {
        accountsElement.textContent = `${userData.connectedAccounts}/${userData.maxAccounts}`;
      }
    }
    
    const postsElement = document.querySelector('.stat-card:nth-child(3) .stat-value');
    const engagementElement = document.querySelector('.stat-card:nth-child(4) .stat-value');
    
    if (postsElement) postsElement.textContent = userData.postsThisMonth;
    if (engagementElement) engagementElement.textContent = userData.engagementRate;
    
    // Update member since
    const memberSinceElement = document.querySelector('.member-since .text-gray-900');
    if (memberSinceElement) {
      memberSinceElement.textContent = userData.memberSince;
    }
    
    // Load profile picture in view modal
    if (savedProfileImage && profilePictureLarge) {
      profilePictureLarge.innerHTML = '';
      const img = document.createElement('img');
      img.src = savedProfileImage;
      img.className = 'w-full h-full object-cover rounded-full';
      img.alt = 'Profile picture';
      profilePictureLarge.appendChild(img);
    }
    
    // NEW: Display default author name in profile if you want
    const authorNameElement = document.querySelector('.default-author-name');
    if (authorNameElement) {
      authorNameElement.textContent = userData.defaultAuthorName;
    }
    
    // Update subscription badge
    updateSubscriptionBadge(userData.planType);
  }

  // Function to update subscription badge in profile
  function updateSubscriptionBadge(planType) {
    let badgeElement = document.querySelector('.subscription-badge');
    
    if (!badgeElement) {
      // Create badge element if it doesn't exist
      badgeElement = document.createElement('div');
      badgeElement.className = 'subscription-badge';
      const profileHeader = document.querySelector('.profile-header');
      if (profileHeader) {
        profileHeader.appendChild(badgeElement);
      }
    }
    
    const badgeConfig = {
      'trial': { 
        text: 'Trial Plan', 
        color: 'bg-blue-100 text-blue-800 border-blue-200',
        icon: 'fa-star'
      },
      'basic': { 
        text: 'Basic Plan', 
        color: 'bg-green-100 text-green-800 border-green-200',
        icon: 'fa-gem'
      },
      'premium': { 
        text: 'Premium Plan', 
        color: 'bg-purple-100 text-purple-800 border-purple-200',
        icon: 'fa-crown'
      },
      'pro': { 
        text: 'Pro Plan', 
        color: 'bg-orange-100 text-orange-800 border-orange-200',
        icon: 'fa-rocket'
      }
    };
    
    const config = badgeConfig[planType] || badgeConfig.trial;
    badgeElement.innerHTML = `
      <div class="inline-flex items-center px-3 py-1 rounded-full border ${config.color}">
        <i class="fas ${config.icon} mr-2 text-xs"></i>
        <span class="text-sm font-medium">${config.text}</span>
      </div>
    `;
  }

  // Add this function to refresh profile data when subscription changes
  function refreshProfileData() {
    if (profileModal.classList.contains('show')) {
      loadProfileData();
    }
  }

  // Make refreshProfileData available globally
  window.refreshProfileData = refreshProfileData;

  // Open view profile modal
  viewProfileBtn.addEventListener('click', function() {
    profileModal.classList.add('show');
    profileDropdownContent.classList.remove('show');
    document.body.style.overflow = 'hidden';
    loadProfileData();
  });

  // ==================== ACCOUNT SETTINGS MODAL FUNCTIONALITY ====================
  
  // Open account settings modal
  accountSettingsBtn.addEventListener('click', function() {
    accountSettingsModal.classList.add('show');
    profileDropdownContent.classList.remove('show');
    document.body.style.overflow = 'hidden';
  });
  
  // Close account settings modal
  function closeAccountSettingsModalFunc() {
    accountSettingsModal.classList.remove('show');
    document.body.style.overflow = 'auto';
  }
  
  closeAccountSettingsModal.addEventListener('click', closeAccountSettingsModalFunc);
  cancelAccountSettings.addEventListener('click', closeAccountSettingsModalFunc);
  
  // Save account settings
  saveAccountSettings.addEventListener('click', function() {
    // Get values from settings form
    const language = document.getElementById('languageSelect')?.value;
    const theme = document.getElementById('themeSelect')?.value;
    const resultsPerPage = document.getElementById('resultsPerPage')?.value;
    
    // In a real app, this would save to your backend
    console.log('Saving settings:', { language, theme, resultsPerPage });
    
    // Show success message
    showNotification('Account settings saved successfully!', 'success');
    closeAccountSettingsModalFunc();
  });

  // ==================== LOGOUT FUNCTIONALITY ====================
  
  // Logout functionality
  logoutBtn.addEventListener('click', function() {
    if (confirm('Are you sure you want to logout?')) {
      // Show loading state
      const originalText = logoutBtn.innerHTML;
      logoutBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging out...';
      logoutBtn.disabled = true;
      
      // Simulate logout process
      setTimeout(() => {
        // In a real app, this would redirect to logout endpoint
        showNotification('Logged out successfully!', 'success');
        
        // Reset button
        logoutBtn.innerHTML = originalText;
        logoutBtn.disabled = false;
        
        // Redirect to login page (simulated)
        setTimeout(() => {
          alert('Redirecting to login page...');
          // window.location.href = '/login';
        }, 1000);
      }, 1500);
    }
  });

  // ==================== ACCOUNT SETTINGS ACTION BUTTONS ====================
  
  // Handle action buttons in account settings
  document.querySelectorAll('.btn-secondary').forEach(button => {
    if (button.textContent.includes('Enable') || 
        button.textContent.includes('View') || 
        button.textContent.includes('Export') ||
        button.textContent.includes('Update') ||
        button.textContent.includes('Edit')) {
      button.addEventListener('click', function() {
        const action = button.textContent.trim();
        showNotification(`Opening ${action} functionality...`, 'info');
        
        // Simulate action
        setTimeout(() => {
          if (action === 'Enable') {
            showNotification('Two-factor authentication enabled!', 'success');
            button.textContent = 'Disable';
            button.classList.add('bg-green-600', 'hover:bg-green-700');
            button.classList.remove('bg-gray-600', 'hover:bg-gray-500');
          }
        }, 1000);
      });
    }
  });

  // Danger zone buttons
  document.querySelectorAll('.btn-danger, .btn-secondary').forEach(button => {
    if (button.textContent.includes('Delete') || button.textContent.includes('Deactivate')) {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        const action = button.textContent.includes('Delete') ? 'delete' : 'deactivate';
        const actionText = button.textContent.includes('Delete') ? 'permanently delete' : 'deactivate';
        
        if (confirm(`Are you sure you want to ${actionText} your account? This action cannot be undone.`)) {
          // Show loading state
          const originalText = button.innerHTML;
          button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
          button.disabled = true;
          
          // Simulate account action
          setTimeout(() => {
            showNotification(`Account ${action} process initiated. You will receive a confirmation email.`, 'warning');
            
            // Reset button
            button.innerHTML = originalText;
            button.disabled = false;
            
            closeAccountSettingsModalFunc();
          }, 2000);
        }
      });
    }
  });

  // ==================== MODAL MANAGEMENT ====================
  
  // Close modals when clicking outside
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) {
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
      }
    });
  });
  
  // Close modals with Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal.show').forEach(modal => {
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
      });
    }
  });

  // ==================== NOTIFICATION SYSTEM ====================
  
  // Notification function
  function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.custom-notification');
    if (existingNotification) {
      existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `custom-notification fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transform transition-transform duration-300 ${
      type === 'success' ? 'bg-green-500 text-white' :
      type === 'error' ? 'bg-red-500 text-white' :
      type === 'warning' ? 'bg-yellow-500 text-white' :
      'bg-blue-500 text-white'
    }`;
    
    // Add icon based on type
    const icon = type === 'success' ? 'fa-check-circle' :
                 type === 'error' ? 'fa-exclamation-circle' :
                 type === 'warning' ? 'fa-exclamation-triangle' :
                 'fa-info-circle';
    
    notification.innerHTML = `
      <div class="flex items-center space-x-2">
        <i class="fas ${icon}"></i>
        <span>${message}</span>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      notification.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, 300);
    }, 5000);
    
    // Click to dismiss
    notification.addEventListener('click', () => {
      notification.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, 300);
    });
  }

  // ==================== PROFILE PICTURE FUNCTIONALITY ====================
  
  // Profile picture upload preview (if you add this functionality back)
  function setupProfilePictureUpload() {
    const profilePictureInput = document.getElementById('profilePictureInput');
    if (profilePictureInput) {
      profilePictureInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
          const file = this.files[0];
          
          // Validate file type
          const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
          if (!validTypes.includes(file.type)) {
            showNotification('Please select a valid image file (JPEG, PNG, GIF)', 'error');
            this.value = '';
            return;
          }
          
          // Validate file size (max 5MB)
          if (file.size > 5 * 1024 * 1024) {
            showNotification('Image size must be less than 5MB', 'error');
            this.value = '';
            return;
          }
          
          const reader = new FileReader();
          reader.onload = function(e) {
            // Update all profile picture instances using global function
            window.updateProfilePictureEverywhere(e.target.result);
            showNotification('Profile picture updated successfully!', 'success');
          };
          reader.readAsDataURL(file);
        }
      });
    }
  }
  
  // Update profile picture in all locations (legacy function - now uses global function)
  function updateProfilePicture(imageSrc) {
    // Use the global function instead
    window.updateProfilePictureEverywhere(imageSrc);
  }

  // ==================== INITIALIZATION ====================
  
  // Initialize with demo data
  function initializeDemoData() {
    // Set initial user data
    if (userName) userName.textContent = 'Profile';
    if (dropdownUserName) dropdownUserName.textContent = 'Prime Alpha';
    if (dropdownUserEmail) dropdownUserEmail.textContent = 'john.doe@example.com';
    
    // Initialize profile picture upload if needed
    setupProfilePictureUpload();
  }
  
  // Call initialization
  initializeDemoData();
  initializeProfileSync(); // NEW: Initialize profile sync
});