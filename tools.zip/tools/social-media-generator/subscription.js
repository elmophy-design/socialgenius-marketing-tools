class SubscriptionManager {
    constructor() {
        this.subscription = {
            plan: 'trial',
            trialStartDate: null,
            trialEndDate: null,
            isActive: true,
            autoRenew: false,
            paymentMethod: null,
            billingCycle: 'monthly'
        };
        
        this.plans = {
            'trial': {
                name: '7-Day Free Trial',
                price: 0,
                period: '7 days',
                features: [
                    'Facebook access only',
                    'Basic content ',
                    'Standard analytics for Facebook',
                    'Email support',
                    'No credit card required'
                ],
                limitations: {
                    maxAccounts: 1,
                    allowedPlatforms: ['Facebook'],
                    aiContent: false,
                    advancedAnalytics: false,
                    customBranding: false,
                    teamCollaboration: false,
                    apiAccess: false
                }
            },
            'basic': {
                name: 'Basic Plan',
                price: 19,
                period: 'month',
                features: [
                    'Up to 3 social accounts',
                    'Basic content scheduling',
                    'Standard analytics',
                    'Email support'
                ],
                limitations: {
                    maxAccounts: 3,
                    allowedPlatforms: ['Facebook', 'Instagram', 'Twitter', 'TikTok', 'LinkedIn'],
                    aiContent: false,
                    advancedAnalytics: false,
                    customBranding: false,
                    teamCollaboration: false,
                    apiAccess: false
                }
            },
            'premium': {
                name: 'Premium Plan',
                price: 49,
                period: 'month',
                features: [
                    'Unlimited social accounts',
                    'AI content generation',
                    'Advanced analytics',
                    'Priority customer support',
                    'Custom branding'
                ],
                limitations: {
                    maxAccounts: null, // unlimited
                    allowedPlatforms: ['Facebook', 'Instagram', 'Twitter', 'TikTok', 'LinkedIn'],
                    aiContent: true,
                    advancedAnalytics: true,
                    customBranding: true,
                    teamCollaboration: false,
                    apiAccess: false
                }
            },
            'pro': {
                name: 'Pro Plan',
                price: 99,
                period: 'month',
                features: [
                    'Everything in Premium',
                    'Team collaboration',
                    'White-label solutions',
                    'API access',
                    'Dedicated account manager'
                ],
                limitations: {
                    maxAccounts: null,
                    allowedPlatforms: ['Facebook', 'Instagram', 'Twitter', 'TikTok', 'LinkedIn'],
                    aiContent: true,
                    advancedAnalytics: true,
                    customBranding: true,
                    teamCollaboration: true,
                    apiAccess: true
                }
            }
        };
        
        this.init();
    }

    init() {
        this.loadSubscriptionData();
        this.startTrialIfNewUser();
        this.initializeEventListeners();
        this.updateSubscriptionDisplay();
        this.startTrialCountdown();
        this.enforceTrialLimitations();
        
    }

    // Data Management
    loadSubscriptionData() {
        const savedSubscription = localStorage.getItem('socialgenius_subscription');
        if (savedSubscription) {
            this.subscription = JSON.parse(savedSubscription);
        }
    }

    saveSubscriptionData() {
        localStorage.setItem('socialgenius_subscription', JSON.stringify(this.subscription));
    }

    // Trial Management
    startTrialIfNewUser() {
        const hasSubscription = localStorage.getItem('socialgenius_subscription');
        
        if (!hasSubscription) {
            const startDate = new Date();
            const endDate = new Date(startDate);
            endDate.setDate(startDate.getDate() + 7); // 7-day trial
            
            this.subscription = {
                plan: 'trial',
                trialStartDate: startDate.toISOString(),
                trialEndDate: endDate.toISOString(),
                isActive: true,
                autoRenew: false,
                paymentMethod: null,
                billingCycle: 'monthly'
            };
            
            this.saveSubscriptionData();
            this.showNotification('🎉 7-day free trial started! You can now use Facebook.', 'success');
        }
    }

    // ENFORCE FACEBOOK-ONLY FOR TRIAL
    enforceTrialLimitations() {
        if (this.subscription.plan === 'trial' && this.subscription.isActive) {
            // Disable all platforms except Facebook
            const socialAccounts = JSON.parse(localStorage.getItem('socialgenius_social_accounts') || '{}');
            
            Object.keys(socialAccounts).forEach(platform => {
                if (platform !== 'Facebook') {
                    socialAccounts[platform].connected = false;
                    socialAccounts[platform].disabled = true;
                } else {
                    // Ensure Facebook is enabled
                    socialAccounts[platform].disabled = false;
                }
            });
            
            localStorage.setItem('socialgenius_social_accounts', JSON.stringify(socialAccounts));
            
            // Update UI to reflect limitations
            this.updateSocialAccountsDisplay();
        }
    }

    updateSocialAccountsDisplay() {
        const socialAccounts = JSON.parse(localStorage.getItem('socialgenius_social_accounts') || '{}');
        
        Object.keys(socialAccounts).forEach(platform => {
            const accountElement = this.findSocialAccountElement(platform);
            if (accountElement) {
                this.updateAccountDisplay(accountElement, platform, socialAccounts[platform]);
            }
        });
    }

    findSocialAccountElement(platform) {
        const accounts = document.querySelectorAll('.social-account-setting');
        for (let account of accounts) {
            if (account.querySelector('span').textContent === platform) {
                return account;
            }
        }
        return null;
    }

    updateAccountDisplay(account, platform, accountData) {
        const statusText = account.querySelector('.status-text');
        const button = account.querySelector('button');
        const isConnected = accountData?.connected || false;
        const isDisabled = accountData?.disabled || false;

        if (isDisabled) {
            statusText.textContent = 'Trial Limited';
            statusText.className = 'status-text bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-medium';
            button.textContent = 'Upgrade';
            button.disabled = false;
            button.className = 'px-4 py-2 bg-gray-300 text-gray-600 rounded-lg text-sm font-medium cursor-not-allowed';
        } else if (isConnected) {
            statusText.textContent = 'Connected';
            statusText.className = 'status-text bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium';
            button.textContent = 'Manage';
            button.disabled = false;
            button.className = 'px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition';
        } else {
            statusText.textContent = 'Not Connected';
            statusText.className = 'status-text bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-medium';
            button.textContent = 'Connect';
            button.disabled = false;
            button.className = 'px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition';
        }
    }

    getTrialTimeLeft() {
        if (!this.subscription.trialEndDate) {
            return { days: 0, hours: 0, minutes: 0, expired: true };
        }

        const now = new Date();
        const endDate = new Date(this.subscription.trialEndDate);
        const timeLeft = endDate - now;

        if (timeLeft <= 0) {
            return { days: 0, hours: 0, minutes: 0, expired: true };
        }

        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));

        return { days, hours, minutes, expired: false };
    }

    startTrialCountdown() {
        if (this.subscription.plan === 'trial') {
            setInterval(() => {
                this.updateTrialCountdown();
                this.checkTrialExpiry();
            }, 60000);
            
            this.updateTrialCountdown();
        }
    }

    updateTrialCountdown() {
        const countdownElement = document.querySelector('.countdown-timer');
        const countdownContainer = document.querySelector('.trial-countdown');
        
        if (countdownElement) {
            const timeLeft = this.getTrialTimeLeft();
            
            if (timeLeft.expired) {
                countdownElement.textContent = 'Trial Expired';
                countdownElement.className = 'countdown-timer expired';
                if (countdownContainer) {
                    countdownContainer.className = 'trial-countdown expired';
                }
            } else {
                countdownElement.textContent = `${timeLeft.days}d ${timeLeft.hours}h ${timeLeft.minutes}m`;
                
                if (timeLeft.days <= 1) {
                    countdownElement.className = 'countdown-timer expiring';
                    if (countdownContainer) {
                        countdownContainer.className = 'trial-countdown expiring';
                    }
                }
            }
        }
    }

    checkTrialExpiry() {
        const timeLeft = this.getTrialTimeLeft();
        
        if (timeLeft.expired && this.subscription.isActive) {
            this.subscription.isActive = false;
            this.saveSubscriptionData();
            this.showTrialExpiredModal();
        }
        
        if (timeLeft.days === 0 && timeLeft.hours <= 24 && !this.trialWarningShown) {
            this.showTrialWarning();
            this.trialWarningShown = true;
        }
    }

    showTrialWarning() {
        this.showNotification(
            '⚠️ Your trial ends in less than 24 hours! Upgrade to keep access to Facebook and unlock other platforms.',
            'warning',
            10000
        );
    }

    showTrialExpiredModal() {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                <div class="p-6 border-b border-gray-200 text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Trial Expired</h3>
                </div>
                
                <div class="p-6 text-center">
                    <p class="text-gray-600 mb-6">
                        Your 7-day free trial has ended. Upgrade to continue using Facebook and unlock all other platforms.
                    </p>
                    
                    <div class="space-y-3">
                        <button onclick="subscriptionManager.processPaymentDirectly('premium')" 
                                class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                            Upgrade to Premium - $49/month
                        </button>
                        
                        <button onclick="subscriptionManager.processPaymentDirectly('basic')" 
                                class="w-full py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition font-medium">
                            Choose Basic - $19/month
                        </button>
                        
                        <button onclick="subscriptionManager.closeModal()" 
                                class="w-full py-3 bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-lg transition font-medium">
                            Maybe Later
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        this.showModal(modalContent);
    }

    // Event Listeners
    initializeEventListeners() {
        // Plan selection
        document.addEventListener('click', (e) => {
            if (e.target.closest('.upgrade-option')) {
                const planElement = e.target.closest('.upgrade-option');
                this.selectPlan(planElement);
            }
        });

        // Continue button
        document.getElementById('changePlan')?.addEventListener('click', () => {
            this.processPlanSelection();
        });

        // Close button
        document.getElementById('cancelSubscription')?.addEventListener('click', () => {
            this.closeSubscriptionModal();
        });
    }

    selectPlan(planElement) {
        document.querySelectorAll('.upgrade-option').forEach(plan => {
            plan.classList.remove('selected');
        });
        
        planElement.classList.add('selected');
    }

        processPlanSelection() {
            const selectedPlan = document.querySelector('.upgrade-option.selected');
            if (!selectedPlan) {
                this.showNotification('Please select a plan', 'error');
                return;
            }

            const planName = selectedPlan.querySelector('.plan-name').textContent;
            const planType = this.getPlanTypeFromName(planName);

            if (planType === 'trial') {
                if (this.subscription.plan === 'trial') {
                    this.showNotification('You are already on the free trial', 'info');
                } else {
                    this.showConfirmationModal(
                        'Start Free Trial',
                        'Are you sure you want to start a new 7-day free trial? You will have access to Facebook only.',
                        'Start Trial',
                        () => this.startNewTrial()
                    );
                }
                return;
            }

            // Close subscription modal and process payment directly via API
            this.closeSubscriptionModal();
            setTimeout(() => {
                this.processPaymentDirectly(planType);
            }, 300);
        }

    getPlanTypeFromName(planName) {
        const planMap = {
            '7-Day Free Trial': 'trial',
            'Basic Plan': 'basic',
            'Premium Plan': 'premium',
            'Pro Plan': 'pro'
        };
        return planMap[planName] || 'trial';
    }

    startNewTrial() {
        const startDate = new Date();
        const endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + 7);

        this.subscription = {
            plan: 'trial',
            trialStartDate: startDate.toISOString(),
            trialEndDate: endDate.toISOString(),
            isActive: true,
            autoRenew: false,
            paymentMethod: null,
            billingCycle: 'monthly'
        };

        this.saveSubscriptionData();
        this.enforceTrialLimitations();
        this.updateSubscriptionDisplay();
        this.updateProfileSubscriptionDisplay(); // NEW: Update profile
        this.closeSubscriptionModal();
        this.showNotification('🎉 7-day free trial started! You now have access to Facebook.', 'success');
    }

    // Close Subscription Modal
    closeSubscriptionModal() {
        const subscriptionModal = document.getElementById('subscriptionModal');
        if (subscriptionModal) {
            subscriptionModal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
        this.closeModal();
    }

    // Payment Gateway Selection Modal
        showPaymentGatewayModal(planType) {
            const plan = this.plans[planType];
            
            // Show loading state immediately and process payment via API
            const modalContent = `
                <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                    <div class="p-6 border-b border-gray-200 text-center">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-spinner fa-spin text-blue-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800">Processing Payment</h3>
                    </div>
                    
                    <div class="p-6 text-center">
                        <p class="text-gray-600 mb-4">
                            Processing your ${plan.name} subscription...
                        </p>
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h4 class="font-medium text-blue-800">${plan.name}</h4>
                                    <p class="text-blue-600 text-sm">$${plan.price}/${plan.period}</p>
                                </div>
                                <div class="text-2xl font-bold text-blue-800">$${plan.price}</div>
                            </div>
                        </div>
                        <p class="text-sm text-gray-500">
                            You will be redirected to complete your payment...
                        </p>
                    </div>
                </div>
            `;
            
            this.showModal(modalContent);
            
            // Process payment via your API
            setTimeout(() => {
                this.processPaymentViaAPI(planType);
            }, 2000);
        }
        
   

        processPaymentDirectly(planType) {
            const plan = this.plans[planType];
            
            // Show payment processing modal immediately
            const modalContent = `
                <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                    <div class="p-6 border-b border-gray-200">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xl font-semibold text-gray-800">Complete Payment</h3>
                            <button onclick="subscriptionManager.closeModal()" class="text-gray-400 hover:text-gray-600 transition">
                                <i class="fas fa-times text-lg"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="p-6 space-y-6">
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h4 class="font-medium text-blue-800">${plan.name}</h4>
                                    <p class="text-blue-600 text-sm">$${plan.price}/${plan.period}</p>
                                </div>
                                <div class="text-2xl font-bold text-blue-800">$${plan.price}</div>
                            </div>
                        </div>

                        <!-- Add your payment form fields here -->
                        <div class="space-y-4" id="payment-form">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Card Number</label>
                                <input type="text" 
                                    class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                                    placeholder="1234 5678 9012 3456"
                                    maxlength="19">
                            </div>
                            
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Expiry Date</label>
                                    <input type="text" 
                                        class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                                        placeholder="MM/YY"
                                        maxlength="5">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">CVV</label>
                                    <input type="text" 
                                        class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                                        placeholder="123"
                                        maxlength="3">
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Cardholder Name</label>
                                <input type="text" 
                                    class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                                    placeholder="John Doe">
                            </div>
                        </div>

                        <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                            <div class="flex items-center">
                                <i class="fas fa-shield-alt text-green-500 text-lg mr-3"></i>
                                <div>
                                    <h4 class="font-medium text-green-800">Secure Payment</h4>
                                    <p class="text-green-600 text-sm">Your payment information is encrypted and secure</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                        <button onclick="subscriptionManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                            Cancel
                        </button>
                        <button onclick="subscriptionManager.submitPayment('${planType}')" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                            Pay $${plan.price}
                        </button>
                    </div>
                </div>
            `;
            
            this.showModal(modalContent);
        }

        submitPayment(planType) {
            // Show processing state
            const modalContent = document.querySelector('.modal-content');
            modalContent.innerHTML = `
                <div class="p-6 text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-spinner fa-spin text-blue-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Processing Payment</h3>
                    <p class="text-gray-600">Please wait while we process your payment...</p>
                </div>
            `;

            // Process payment via your API
            setTimeout(() => {
                this.processPaymentViaAPI(planType);
            }, 2000);
        }

        processPaymentViaAPI(planType) {
            const plan = this.plans[planType];
            
            // Show processing state
            const modalContent = document.querySelector('.modal-content');
            if (modalContent) {
                modalContent.innerHTML = `
                    <div class="p-6 text-center">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-spinner fa-spin text-blue-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Processing Payment</h3>
                        <p class="text-gray-600">Please wait while we process your payment...</p>
                    </div>
                `;
            }

            // =============================================
            // INTEGRATE YOUR PAYMENT API HERE
            // =============================================
            
            // Example structure for your API call:
            const paymentData = {
                plan: planType,
                amount: plan.price,
                currency: 'USD',
                userId: this.getUserId(), // You'll need to implement this
                userEmail: this.getUserEmail() // You'll need to implement this
            };

            // Make API call to your payment endpoint
            this.makePaymentAPICall(paymentData)
                .then(response => {
                    // Handle successful payment
                    this.handlePaymentSuccess(planType, response);
                })
                .catch(error => {
                    // Handle payment failure
                    this.handlePaymentFailure(error);
                });
        }

        // Add these helper methods for API integration:

        makePaymentAPICall(paymentData) {
            // Replace this with your actual API endpoint
            return fetch('/api/payments/process', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.getAuthToken()}` // If using authentication
                },
                body: JSON.stringify(paymentData)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Payment processing failed');
                }
                return response.json();
            });
        }

        handlePaymentSuccess(planType, response) {
            // Close modal
            this.closeModal();
            
            // Update subscription
            this.upgradeToPlan(planType, 'api_payment');
            
            // Show success notification
            this.showNotification(`🎉 Payment successful! Welcome to ${this.plans[planType].name}.`, 'success');
            
            // Optional: Redirect or show receipt
            if (response.redirectUrl) {
                setTimeout(() => {
                    window.location.href = response.redirectUrl;
                }, 2000);
            }
        }

        handlePaymentFailure(error) {
            // Show error modal
            const modalContent = `
                <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                    <div class="p-6 border-b border-gray-200 text-center">
                        <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800">Payment Failed</h3>
                    </div>
                    
                    <div class="p-6 text-center">
                        <p class="text-gray-600 mb-6">
                            We couldn't process your payment. Please try again or use a different payment method.
                        </p>
                        
                        <div class="space-y-3">
                            <button onclick="subscriptionManager.closeModal()" 
                                    class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                                Try Again
                            </button>
                            
                            <button onclick="subscriptionManager.closeModal()" 
                                    class="w-full py-3 bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-lg transition font-medium">
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            this.showModal(modalContent);
            
            // Show error notification
            this.showNotification('Payment failed. Please try again.', 'error');
        }

        // Helper methods for user data (you'll need to implement these based on your app)
        getUserId() {
            // Return current user ID from your authentication system
            return localStorage.getItem('userId') || 'unknown';
        }

        getUserEmail() {
            // Return current user email from your authentication system
            return localStorage.getItem('userEmail') || 'user@example.com';
        }

        getAuthToken() {
            // Return authentication token if needed
            return localStorage.getItem('authToken') || '';
        }

    upgradeToPlan(planType, paymentGateway = null) {
        const plan = this.plans[planType];
        
        this.subscription = {
            plan: planType,
            trialStartDate: null,
            trialEndDate: null,
            isActive: true,
            autoRenew: true,
            paymentMethod: paymentGateway || 'gateway',
            billingCycle: 'monthly',
            upgradedAt: new Date().toISOString()
        };

        // Remove all platform limitations when upgrading
        const socialAccounts = JSON.parse(localStorage.getItem('socialgenius_social_accounts') || '{}');
        Object.keys(socialAccounts).forEach(platform => {
            if (socialAccounts[platform].disabled) {
                socialAccounts[platform].disabled = false;
            }
        });
        localStorage.setItem('socialgenius_social_accounts', JSON.stringify(socialAccounts));

        this.saveSubscriptionData();
        this.updateSubscriptionDisplay();
        this.updateProfileSubscriptionDisplay(); // NEW: Update profile
        
        // Refresh the social accounts display
        if (window.settingsManager) {
            window.settingsManager.updateAllDisplays();
        }
    }

    // UI Updates
    updateSubscriptionDisplay() {
        // Update current plan display
        const currentPlanElement = document.querySelector('.current-plan');
        if (currentPlanElement) {
            const planName = this.plans[this.subscription.plan]?.name || 'Free Trial';
            currentPlanElement.textContent = planName;
        }

        // Update trial countdown if applicable
        if (this.subscription.plan === 'trial') {
            this.updateTrialCountdown();
        }

        // Update feature access throughout the app
        this.updateFeatureAccess();
        
        // NEW: Always update profile subscription display
        this.updateProfileSubscriptionDisplay();
    }

    // NEW: Profile Subscription Display Updates
    updateProfileSubscriptionDisplay() {
        // Update the subscription plan in the profile modal
        const subscriptionPlanElement = document.querySelector('.stat-card:nth-child(1) .stat-value');
        if (subscriptionPlanElement) {
            const planName = this.plans[this.subscription.plan]?.name || 'Free Trial';
            subscriptionPlanElement.textContent = planName;
        }

        // Update connected accounts count based on plan limitations
        const connectedAccountsElement = document.querySelector('.stat-card:nth-child(2) .stat-value');
        if (connectedAccountsElement) {
            const plan = this.plans[this.subscription.plan];
            const socialAccounts = JSON.parse(localStorage.getItem('socialgenius_social_accounts') || '{}');
            const connectedCount = Object.values(socialAccounts).filter(acc => acc.connected).length;
            
            if (plan.limitations.maxAccounts === null) {
                connectedAccountsElement.textContent = `${connectedCount}/Unlimited`;
            } else {
                connectedAccountsElement.textContent = `${connectedCount}/${plan.limitations.maxAccounts}`;
            }
        }

        // Update subscription badge
        this.updateProfileBadge();
        
        // Trigger profile data refresh if profile modal is open
        this.refreshProfileData();
    }

    // NEW: Update profile badge
    updateProfileBadge() {
        const profileBadgeElement = document.querySelector('.subscription-badge');
        if (!profileBadgeElement) {
            // Create badge element if it doesn't exist
            const profileHeader = document.querySelector('.profile-header');
            if (profileHeader) {
                const badgeElement = document.createElement('div');
                badgeElement.className = 'subscription-badge mt-2';
                profileHeader.appendChild(badgeElement);
            }
            return;
        }

        const plan = this.subscription.plan;
        const badgeConfig = {
            'trial': { 
                text: 'Trial Plan', 
                color: 'bg-blue-100 text-blue-800 border-blue-200',
                icon: 'fa-star'
            },
            'basic': { 
                text: 'Basic Plan', 
                color: 'bg-green-100 text-green-800 border-green-200',
                icon: 'fa-gem'
            },
            'premium': { 
                text: 'Premium Plan', 
                color: 'bg-purple-100 text-purple-800 border-purple-200',
                icon: 'fa-crown'
            },
            'pro': { 
                text: 'Pro Plan', 
                color: 'bg-orange-100 text-orange-800 border-orange-200',
                icon: 'fa-rocket'
            }
        };
        
        const config = badgeConfig[plan] || badgeConfig.trial;
        profileBadgeElement.innerHTML = `
            <div class="inline-flex items-center px-3 py-1 rounded-full border ${config.color}">
                <i class="fas ${config.icon} mr-2 text-xs"></i>
                <span class="text-sm font-medium">${config.text}</span>
            </div>
        `;
    }

    // NEW: Refresh profile data
    refreshProfileData() {
        if (window.refreshProfileData) {
            window.refreshProfileData();
        }
    }

    updateFeatureAccess() {
        const plan = this.subscription.plan;
        const limitations = this.plans[plan]?.limitations;

        // Update UI elements based on plan limitations
        document.querySelectorAll('.premium-feature').forEach(feature => {
            if (limitations && !limitations.aiContent) {
                feature.style.opacity = '0.6';
                feature.title = 'Upgrade to Premium for AI Content Generation';
            }
        });

        // Add upgrade prompts for limited features
        if (plan === 'trial') {
            this.addUpgradePrompts();
        }
    }

    addUpgradePrompts() {
        // Add upgrade prompts next to limited platforms
        document.querySelectorAll('.social-account-setting').forEach(account => {
            const platform = account.querySelector('span').textContent;
            if (platform !== 'Facebook' && !account.querySelector('.upgrade-prompt')) {
                const prompt = document.createElement('div');
                prompt.className = 'upgrade-prompt mt-2';
                prompt.innerHTML = `
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-2 text-center">
                        <p class="text-blue-700 text-xs font-medium">Upgrade to unlock ${platform}</p>
                    </div>
                `;
                account.appendChild(prompt);
            }
        });
    }

    // Utility Methods
    showNotification(message, type = 'info', duration = 4000) {
        const notification = document.createElement('div');
        notification.className = `notification ${type} fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 flex items-center gap-3`;
        
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            info: 'fa-info-circle',
            warning: 'fa-exclamation-triangle'
        };
        
        notification.innerHTML = `
            <i class="fas ${icons[type]} text-white text-lg"></i>
            <span class="text-white font-medium">${message}</span>
        `;
        
        // Add background colors based on type
        const backgrounds = {
            success: 'linear-gradient(135deg, #10b981, #059669)',
            error: 'linear-gradient(135deg, #ef4444, #dc2626)',
            info: 'linear-gradient(135deg, #3b82f6, #2563eb)',
            warning: 'linear-gradient(135deg, #f59e0b, #d97706)'
        };
        
        notification.style.background = backgrounds[type];
        
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('show'), 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, duration);
    }

    showModal(content) {
        const container = document.getElementById('modalContainer') || this.createModalStructure();
        container.innerHTML = content;
        container.classList.remove('hidden');
        
        setTimeout(() => {
            const modalContent = container.querySelector('.modal-content');
            if (modalContent) modalContent.classList.add('modal-open');
        }, 10);
    }

    closeModal() {
        const container = document.getElementById('modalContainer');
        const backdrop = document.getElementById('modalBackdrop');
        
        if (container) container.classList.add('hidden');
        if (backdrop) backdrop.classList.add('hidden');
    }

    createModalStructure() {
        const backdrop = document.createElement('div');
        backdrop.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 hidden';
        backdrop.id = 'modalBackdrop';
        
        const container = document.createElement('div');
        container.className = 'fixed inset-0 z-50 flex items-center justify-center hidden';
        container.id = 'modalContainer';

        document.body.appendChild(backdrop);
        document.body.appendChild(container);

        backdrop.addEventListener('click', () => this.closeModal());
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
        });

        return container;
    }

    showConfirmationModal(title, message, confirmText, onConfirm) {
        const modalContent = `
            <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
                <div class="p-6 border-b border-gray-200">
                    <h3 class="text-xl font-semibold text-gray-800">${title}</h3>
                </div>
                
                <div class="p-6">
                    <p class="text-gray-600 leading-relaxed">${message}</p>
                </div>
                
                <div class="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl flex space-x-3">
                    <button onclick="subscriptionManager.closeModal()" class="flex-1 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-medium">
                        Cancel
                    </button>
                    <button onclick="subscriptionManager.executeConfirmAction()" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                        ${confirmText}
                    </button>
                </div>
            </div>
        `;
        
        window.subscriptionManagerConfirmAction = onConfirm;
        this.showModal(modalContent);
    }

    executeConfirmAction() {
        if (window.subscriptionManagerConfirmAction) {
            window.subscriptionManagerConfirmAction();
        }
        this.closeModal();
    }

    // Check if feature is available
    isFeatureAvailable(feature) {
        const plan = this.subscription.plan;
        const trialActive = this.subscription.plan === 'trial' && this.subscription.isActive;
        const limitations = this.plans[plan]?.limitations;
        
        if (!limitations) return false;
        
        if (trialActive) {
            // Trial users only get Facebook
            if (feature === 'platform_access') {
                return false; // Handled separately in enforceTrialLimitations
            }
            return false; // No other features in trial
        }
        
        const featureMap = {
            'ai_content': limitations.aiContent,
            'advanced_analytics': limitations.advancedAnalytics,
            'custom_branding': limitations.customBranding,
            'team_collaboration': limitations.teamCollaboration,
            'api_access': limitations.apiAccess
        };
        
        return featureMap[feature] || false;
    }

    // Get current plan info
    getCurrentPlan() {
        return this.plans[this.subscription.plan];
    }

    // Check if user can connect platform
    canConnectPlatform(platform) {
        if (this.subscription.plan === 'trial') {
            return platform === 'Facebook';
        }
        
        const plan = this.plans[this.subscription.plan];
        return plan?.limitations?.allowedPlatforms?.includes(platform) || false;
    }

    // Check if user can connect more accounts
    canConnectMoreAccounts() {
        if (this.subscription.plan === 'trial') {
            return false; // Only Facebook in trial
        }
        
        const plan = this.plans[this.subscription.plan];
        const maxAccounts = plan?.limitations?.maxAccounts;
        
        if (maxAccounts === null) return true; // Unlimited
        
        const socialAccounts = JSON.parse(localStorage.getItem('socialgenius_social_accounts') || '{}');
        const connectedCount = Object.values(socialAccounts).filter(acc => acc.connected).length;
        
        return connectedCount < maxAccounts;
    }
}

// ==================== SUBSCRIPTION MODAL FUNCTIONALITY ====================
  
// Open subscription modal
subscriptionBtn.addEventListener('click', function() {
    subscriptionModal.classList.add('show');
    profileDropdownContent.classList.remove('show');
    document.body.style.overflow = 'hidden';
});

// Close subscription modal
function closeSubscriptionModalFunc() {
    subscriptionModal.classList.remove('show');
    document.body.style.overflow = 'auto';
}

closeSubscriptionModal.addEventListener('click', closeSubscriptionModalFunc);
cancelSubscription.addEventListener('click', closeSubscriptionModalFunc);

// Initialize the subscription manager
document.addEventListener('DOMContentLoaded', () => {
    window.subscriptionManager = new SubscriptionManager();
});

// Add CSS for subscription elements
const subscriptionStyles = document.createElement('style');
subscriptionStyles.textContent = `
    .trial-plan {
        border: 2px solid #3b82f6;
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        position: relative;
    }

    .trial-badge {
        position: absolute;
        top: -10px;
        right: 20px;
        background: linear-gradient(135deg, #3b82f6, #1d4ed8);
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
    }

    .price-period {
        font-size: 0.875rem;
        color: #6b7280;
        font-weight: normal;
    }

    .trial-countdown {
        background: #dcfce7;
        border: 1px solid #bbf7d0;
        border-radius: 8px;
        padding: 12px;
        margin-top: 12px;
        text-align: center;
    }

    .trial-countdown.expiring {
        background: #fef3c7;
        border-color: #fde68a;
        color: #92400e;
    }

    .trial-countdown.expired {
        background: #fef2f2;
        border-color: #fecaca;
        color: #dc2626;
    }

    .countdown-timer {
        font-family: monospace;
        font-weight: bold;
        font-size: 1.1rem;
        color: #059669;
    }

    .countdown-timer.expiring {
        color: #d97706;
    }

    .countdown-timer.expired {
        color: #dc2626;
    }

    .upgrade-option {
        transition: all 0.3s ease;
        cursor: pointer;
        border: 2px solid transparent;
    }

    .upgrade-option:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
    }

    .upgrade-option.selected {
        border-color: #3b82f6;
        background-color: #eff6ff;
    }

    .upgrade-prompt {
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border: 1px solid #bae6fd;
        border-radius: 8px;
        padding: 12px;
        margin: 10px 0;
    }

    .upgrade-prompt h4 {
        color: #0369a1;
        font-size: 0.875rem;
        font-weight: 600;
        margin-bottom: 4px;
    }

    .upgrade-prompt p {
        color: #0c4a6e;
        font-size: 0.75rem;
        margin: 0;
    }

    .payment-option {
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .payment-option:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        background-color: #f8fafc;
    }

    .notification {
        animation: slideIn 0.3s ease-out;
    }

    .notification.show {
        transform: translateX(0);
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .modal-content {
        transition: all 0.3s ease;
    }

    .modal-content.modal-open {
        opacity: 1;
        transform: scale(1);
    }

    /* Subscription Modal Styles */
    #subscriptionModal {
        transition: all 0.3s ease;
    }

    #subscriptionModal.show {
        opacity: 1;
        visibility: visible;
    }

    #subscriptionModal:not(.show) {
        opacity: 0;
        visibility: hidden;
    }

    /* Profile Subscription Badge Styles */
    .subscription-badge {
        margin-top: 8px;
    }

    .stat-card {
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .stat-value {
        transition: all 0.3s ease;
    }

    .stat-value.updating {
        opacity: 0.6;
        transform: scale(0.95);
    }
`;
document.head.appendChild(subscriptionStyles);