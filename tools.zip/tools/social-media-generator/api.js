// tools/social-media-generator/api.js
class SocialMediaAPI {
    constructor() {
        this.baseURL = 'http://localhost:4000/api';
        this.isPremium = false;
        this.checkPremiumStatus();
    }

    async checkPremiumStatus() {
        try {
            // Check if user has premium access
            const userData = this.getUserData();
            this.isPremium = userData?.subscription === 'premium';
            
            // Update UI based on premium status
            this.updateUIPremiumStatus();
        } catch (error) {
            console.log('Premium check failed:', error);
        }
    }

    getUserData() {
        // Get user data from localStorage or session
        const userData = localStorage.getItem('socialGenius_user');
        return userData ? JSON.parse(userData) : null;
    }

    updateUIPremiumStatus() {
        if (!this.isPremium) {
            // Add trial badges to premium features
            const premiumFeatures = [
                'autoPostToggle',
                'scheduleBtn',
                'variationsBtn'
            ];
            
            premiumFeatures.forEach(featureId => {
                const element = document.getElementById(featureId);
                if (element) {
                    element.classList.add('premium-feature');
                }
            });

            // Show trial banner
            this.showTrialBanner();
        }
    }

    showTrialBanner() {
        const existingBanner = document.getElementById('trial-banner');
        if (existingBanner) return;

        const banner = document.createElement('div');
        banner.id = 'trial-banner';
        banner.className = 'bg-gradient-to-r from-blue-500 to-purple-600 text-white p-4 mb-6 rounded-lg';
        banner.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-crown text-yellow-300"></i>
                    <div>
                        <h4 class="font-bold">Trial Mode Active</h4>
                        <p class="text-sm opacity-90">Upgrade to Premium for unlimited AI generations and auto-posting</p>
                    </div>
                </div>
                <button onclick="upgradeToPremium()" class="bg-white text-blue-600 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition">
                    Upgrade Now
                </button>
            </div>
        `;
        
        const mainContent = document.querySelector('main');
        if (mainContent) {
            mainContent.insertBefore(banner, mainContent.firstChild);
        }
    }

    async generateContent(contentData) {
        // Check if this is a premium feature request
        if (contentData.autoPost && !this.isPremium) {
            this.showPremiumWall('auto-posting');
            return this.getTrialData(contentData);
        }

        if (contentData.quantity > 3 && !this.isPremium) {
            contentData.quantity = 3; // Limit trial users to 3 posts
        }

        if (!this.isPremium) {
            return this.getTrialData(contentData);
        }

        try {
            const response = await fetch(`${this.baseURL}/ai/generate-content`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(contentData)
            });
            
            if (response.status === 403) {
                this.showPremiumWall('content-generation');
                return this.getTrialData(contentData);
            }
            
            if (!response.ok) throw new Error('API request failed');
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            return this.getTrialData(contentData);
        }
    }

    getTrialData(contentData) {
        // Limited trial version
        const platforms = contentData.platforms || ['instagram', 'twitter'];
        const posts = platforms.map((platform, index) => {
            const platformTemplates = {
                instagram: `🌟 ${contentData.brandName} 🌟\n\n${contentData.postTopic}\n\n💡 Trial Version - Upgrade for full features!\n\n#${contentData.brandName.replace(/\s+/g, '')} #Trial #AI`,
                twitter: `🚀 ${contentData.brandName} Update!\n\n${contentData.postTopic}\n\n✨ Trial Version - Limited features\n\n#${contentData.brandName.replace(/\s+/g, '')} #Tech #AI`,
                linkedin: `Professional Update: ${contentData.brandName}\n\n${contentData.postTopic}\n\n💼 Trial Version - Upgrade for full capabilities\n\n#Business #${contentData.brandName.replace(/\s+/g, '')}`,
                facebook: `📢 ${contentData.brandName} News!\n\n${contentData.postTopic}\n\n⭐ Trial Version - Get premium for more!\n\n#Update #${contentData.brandName.replace(/\s+/g, '')}`
            };

            return {
                platform: platform,
                content: platformTemplates[platform] || platformTemplates.instagram,
                hashtags: ['#TrialVersion', '#UpgradeForMore', `#${contentData.brandName.replace(/\s+/g, '')}`],
                isTrial: true
            };
        });

        return {
            posts: posts.slice(0, contentData.quantity || 2),
            analysis: "✨ Trial version - Upgrade to premium for unlimited AI-generated content, multi-platform posts, auto-posting, and advanced features!",
            isTrial: true,
            limitations: {
                maxPosts: 3,
                noAutoPost: true,
                watermarked: true
            }
        };
    }

    async connectSocialAccount(platform) {
        if (!this.isPremium) {
            this.showPremiumWall('social-connections');
            return;
        }
        
        // Redirect to backend OAuth flow
        window.location.href = `${this.baseURL}/auth/${platform}`;
    }

    showPremiumWall(feature) {
        const featureNames = {
            'auto-posting': 'Auto-Posting',
            'content-generation': 'AI Content Generation',
            'social-connections': 'Social Media Connections'
        };

        const existingWall = document.getElementById('premium-wall');
        if (existingWall) return;
        
        const premiumWall = document.createElement('div');
        premiumWall.id = 'premium-wall';
        premiumWall.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        premiumWall.innerHTML = `
            <div class="bg-white p-8 rounded-2xl max-w-md mx-4">
                <div class="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-crown text-white text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-center mb-2">Premium Feature Locked</h3>
                <p class="text-gray-600 text-center mb-2">${featureNames[feature]} requires Premium subscription</p>
                
                <div class="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-6">
                    <h4 class="font-semibold text-purple-800 mb-2">Premium Includes:</h4>
                    <ul class="text-sm text-purple-600 space-y-1">
                        <li>✓ Unlimited AI content generation</li>
                        <li>✓ Auto-posting to all platforms</li>
                        <li>✓ Multi-platform scheduling</li>
                        <li>✓ Advanced analytics</li>
                        <li>✓ Priority support</li>
                    </ul>
                </div>
                
                <div class="space-y-3">
                    <button onclick="upgradeToPremium()" class="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition">
                        Upgrade to Premium - $29/month
                    </button>
                    <button onclick="closePremiumWall()" class="w-full bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition">
                        Continue with Trial
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(premiumWall);
    }

    // Analytics for dashboard
    async getDashboardStats() {
        if (!this.isPremium) {
            return {
                connectedAccounts: 0,
                postsThisMonth: 0,
                engagementRate: '0%',
                scheduledPosts: 0
            };
        }

        try {
            const response = await fetch(`${this.baseURL}/dashboard/stats`);
            return await response.json();
        } catch (error) {
            return this.getTrialDashboardStats();
        }
    }

    getTrialDashboardStats() {
        return {
            connectedAccounts: 0,
            postsThisMonth: 0,
            engagementRate: '0%',
            scheduledPosts: 0,
            isTrial: true
        };
    }
}

// Global functions for UI interactions
function upgradeToPremium(feature = 'general') {
    // Open the subscription modal directly
    const subscriptionModal = document.getElementById('subscriptionModal');
    if (subscriptionModal) {
        subscriptionModal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Close any other open modals
        document.querySelectorAll('.modal.show').forEach(modal => {
            if (modal !== subscriptionModal) {
                modal.classList.remove('show');
            }
        });
        
        // Close premium wall if open
        closePremiumWall();
        
        // Optional: Scroll to premium plan
        setTimeout(() => {
            const premiumPlan = document.querySelector('.upgrade-option.selected');
            if (premiumPlan) {
                premiumPlan.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 300);
    }
}

// Initialize when script loads
window.SocialMediaAPI = SocialMediaAPI;