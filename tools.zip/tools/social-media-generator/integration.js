// tools/social-media-generator/integration.js
// This file handles how the tool integrates with your main dashboard

class SocialMediaToolIntegration {
    static initFromDashboard(user) {
        // Called when accessing from main dashboard
        const api = new SocialMediaAPI();
        api.isPremium = user.subscription?.plan === 'premium';
        
        if (!api.isPremium) {
            this.showDashboardPremiumPrompt();
        }
        
        return api;
    }
    
    static showDashboardPremiumPrompt() {
        // Show upgrade prompt when accessed from dashboard
        console.log('User needs premium for full access');
    }
    
    static getToolInfo() {
        return {
            name: 'Social Media Generator',
            description: 'AI-powered social media content creation',
            path: '/tools/social-media-generator/',
            premium: true,
            icon: 'fas fa-share-alt',
            category: 'content'
        };
    }
}

window.SocialMediaToolIntegration = SocialMediaToolIntegration;