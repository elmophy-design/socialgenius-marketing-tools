document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const generateBtn = document.getElementById('generate-btn');
    const regenerateBtn = document.getElementById('regenerate-btn');
    const copyAllBtn = document.getElementById('copy-all-btn');
    const saveBtn = document.getElementById('save-btn');
    const tabButtons = document.querySelectorAll('.tab-btn');
    const copyButtons = document.querySelectorAll('.copy-btn');
    const resultsPlaceholder = document.getElementById('results-placeholder');
    const resultsContent = document.getElementById('results-content');
    const loadingIndicator = document.getElementById('loading-indicator');

    // Form Elements
    const pageTitleInput = document.getElementById('page-title');
    const pageContentInput = document.getElementById('page-content');
    const primaryKeywordInput = document.getElementById('primary-keyword');
    const contentTypeSelect = document.getElementById('content-type');
    const toneSelect = document.getElementById('tone');
    const targetAudienceSelect = document.getElementById('target-audience');
    const competitorsInput = document.getElementById('competitors');
    const secondaryKeywordsInput = document.getElementById('secondary-keywords');

    // Result Elements
    const contentTypeBadge = document.getElementById('content-type-badge');
    const scoreBadge = document.getElementById('score-badge');
    const scoreValue = document.querySelector('.score-value');
    const previewTitle = document.getElementById('preview-title');
    const previewUrl = document.getElementById('preview-url');
    const previewDescription = document.getElementById('preview-description');
    const keywordsGrid = document.getElementById('keywords-grid');

    // Analysis Elements
    const keywordScore = document.getElementById('keyword-score');
    const lengthScore = document.getElementById('length-score');
    const engagementScore = document.getElementById('engagement-score');
    const readabilityScore = document.getElementById('readability-score');
    const keywordDetails = document.getElementById('keyword-details');
    const lengthDetails = document.getElementById('length-details');
    const engagementDetails = document.getElementById('engagement-details');
    const readabilityDetails = document.getElementById('readability-details');

    // Create tools links container
    const toolsContainer = document.createElement('div');
    toolsContainer.className = 'tools-links-container';
    toolsContainer.innerHTML = `
        <div class="tools-header">
            <h3>🚀 More Content Tools</h3>
            <p>Enhance your content creation workflow</p>
        </div>
        <div class="tools-grid">
            <a href="../social-media-generator/index.html" class="tool-link" data-tool="social-media">
                <div class="tool-icon">📱</div>
                <div class="tool-content">
                    <h4>AI Social Media Generator</h4>
                    <p>Create engaging social media posts and captions</p>
                </div>
            </a>
            
            <a href="../headline-Analyzer/index.html" class="tool-link" data-tool="ai-writer">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Headline Analyzer</h4>
                    <p>Generate full articles and blog posts</p>
                </div>
            </a>
            
            <a href="../funnel-builder/index.html" class="tool-link" data-tool="seo-analyzer">
                <div class="tool-icon">🔄</div>
                <div class="tool-content">
                    <h4>Funnel Builder</h4>
                    <p>Build complete marketing funnels</p>
                </div>
            </a>
            
            <a href="../email-subject-tester/index.html" class="tool-link" data-tool="video-generator">
                <div class="tool-icon">✉️</div>
                <div class="tool-content">
                    <h4>Email Subject Line Tester</h4>
                    <p>analyze and scores subject effectiveness.</p>
                </div>
            </a>
            
            <a href="../Ad-Copy-Generator/index.html" class="tool-link" data-tool="content-planner">
                <div class="tool-icon">🎯</div>
                <div class="tool-content">
                    <h4>Ad Copy Generator</h4>
                    <p>create engaging, high-converting advertisements automatically.</p>
                </div>
            </a>
        </div>
    `;

    // Insert tools container after the main content
    const mainContainer = document.querySelector('.container') || document.querySelector('main');
    if (mainContainer) {
        mainContainer.appendChild(toolsContainer);
    }
    // SEO configurations
    const contentTemplates = {
        blog: {
            titlePatterns: [
                "The Ultimate Guide to [Topic] | [Year]",
                "[Number] Best [Topic] Strategies That Actually Work",
                "How to [Achieve Goal]: Complete [Year] Guide",
                "[Topic] Made Simple: Step-by-Step Tutorial"
            ],
            descriptionPatterns: [
                "Learn how to [achieve goal] with our comprehensive guide. Discover [benefits] and get [results]. Start today!",
                "Want to [solve problem]? Our [year] guide shows you exactly how. Get [number] proven strategies and [benefit].",
                "Discover the secrets of successful [topic]. Learn [key points] and avoid common mistakes. Read now!"
            ]
        },
        product: {
            titlePatterns: [
                "Buy [Product] | [Features] | [Brand]",
                "[Product] - [Key Benefit] | Free Shipping",
                "[Product] Review: [Year] Buyer's Guide",
                "Best [Product] for [Use Case] | [Brand]"
            ],
            descriptionPatterns: [
                "Shop [product] with [key features]. [Benefits]. Free shipping and [guarantee]. Order now and save!",
                "Looking for the best [product]? Our [product] offers [features] and [benefits]. Buy now with confidence!",
                "Get amazing [results] with our [product]. Features include [key features]. [Special offer]. Shop today!"
            ]
        },
        service: {
            titlePatterns: [
                "[Service] Services | [Location] | [Brand]",
                "Professional [Service] | [Benefits] | [Brand]",
                "Best [Service] Company | [Year] | [Location]",
                "[Service] Made Easy | Get Quote | [Brand]"
            ],
            descriptionPatterns: [
                "Get professional [service] services with [benefits]. Serving [location]. Free consultation. Contact us today!",
                "Need reliable [service]? Our experts provide [quality] service with [guarantee]. Get free quote now!",
                "Top-rated [service] company. We offer [services] with [benefits]. [Satisfaction guarantee]. Call today!"
            ]
        },
        landing: {
            titlePatterns: [
                "[Offer] | [Brand] | [Benefit]",
                "Get [Offer] Now | [Time Limit] | [Brand]",
                "[Solution] for [Problem] | [Brand]",
                "Transform Your [Area] | [Offer] | [Brand]"
            ],
            descriptionPatterns: [
                "Get [offer] and achieve [results]. Limited time offer. [Number] people have already [achievement]. Join now!",
                "Stop [problem] and start [benefit]. Our [solution] delivers [results]. [Guarantee]. Get started today!",
                "Discover how to [achieve goal] with our [solution]. [Social proof]. [Call to action]. Limited spots available!"
            ]
        }
    };

    const toneTemplates = {
        professional: {
            adjectives: ['comprehensive', 'professional', 'advanced', 'enterprise', 'strategic'],
            verbs: ['discover', 'learn', 'achieve', 'optimize', 'implement'],
            phrases: ['industry best practices', 'proven strategies', 'expert guidance']
        },
        casual: {
            adjectives: ['awesome', 'simple', 'easy', 'fun', 'practical'],
            verbs: ['check out', 'discover', 'get', 'try', 'enjoy'],
            phrases: ['you\'ll love', 'super helpful', 'game-changing tips']
        },
        authoritative: {
            adjectives: ['definitive', 'comprehensive', 'expert', 'master', 'ultimate'],
            verbs: ['master', 'dominate', 'excel', 'succeed', 'win'],
            phrases: ['must-know strategies', 'industry secrets', 'professional guidance']
        },
        urgent: {
            adjectives: ['limited', 'exclusive', 'urgent', 'time-sensitive', 'last-chance'],
            verbs: ['act now', 'don\'t miss', 'secure', 'claim', 'grab'],
            phrases: ['limited time offer', 'while supplies last', 'don\'t wait']
        },
        educational: {
            adjectives: ['educational', 'informative', 'comprehensive', 'detailed', 'thorough'],
            verbs: ['learn', 'understand', 'discover', 'explore', 'study'],
            phrases: ['step-by-step guide', 'comprehensive tutorial', 'in-depth analysis']
        }
    };

    // Power words for engagement
    const powerWords = [
        'ultimate', 'complete', 'essential', 'proven', 'secret', 'amazing',
        'incredible', 'unbelievable', 'revolutionary', 'breakthrough', 'exclusive',
        'limited', 'free', 'bonus', 'instant', 'easy', 'simple', 'quick', 'fast'
    ];

    // Event Listeners
    generateBtn.addEventListener('click', generateMetaTags);
    regenerateBtn.addEventListener('click', generateMetaTags);
    copyAllBtn.addEventListener('click', copyAllMetaTags);
    saveBtn.addEventListener('click', saveTemplate);

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const version = this.dataset.version;
            switchVersion(version);
        });
    });

    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const target = this.dataset.target;
            copyToClipboard(target);
        });
    });

    // Generate meta tags function
    function generateMetaTags() {
        const pageTitle = pageTitleInput.value.trim();
        const primaryKeyword = primaryKeywordInput.value.trim();

        if (!pageTitle) {
            alert('Please enter a page title or topic');
            return;
        }

        if (!primaryKeyword) {
            alert('Please enter a primary keyword');
            return;
        }

        setLoadingState(true);

        // Simulate API call delay
        setTimeout(() => {
            try {
                const metaTags = generateMetaTagsFromInputs();
                displayResults(metaTags);
                setLoadingState(false);
            } catch (error) {
                console.error('Error generating meta tags:', error);
                alert('Error generating meta tags. Please try again.');
                setLoadingState(false);
            }
        }, 1500);
    }

    // Generate meta tags from inputs
    function generateMetaTagsFromInputs() {
        const contentType = contentTypeSelect.value;
        const tone = toneSelect.value;
        const primaryKeyword = primaryKeywordInput.value;
        const secondaryKeywords = secondaryKeywordsInput.value.split(',').map(k => k.trim()).filter(k => k);
        const pageContent = pageContentInput.value;
        
        const template = contentTemplates[contentType] || contentTemplates.blog;
        const toneTemplate = toneTemplates[tone] || toneTemplates.professional;

        // Generate multiple variations
        const variations = [];
        for (let i = 0; i < 3; i++) {
            variations.push(generateVariation(i, template, toneTemplate, primaryKeyword, secondaryKeywords, pageContent));
        }

        // Generate keyword suggestions
        const keywordSuggestions = generateKeywordSuggestions(primaryKeyword, secondaryKeywords, pageContent);

        // Calculate overall score
        const analysis = analyzeMetaTags(variations[0], primaryKeyword);
        
        return {
            contentType: contentTypeSelect.options[contentTypeSelect.selectedIndex].text,
            variations: variations,
            keywordSuggestions: keywordSuggestions,
            analysis: analysis,
            url: generateUrl(pageTitleInput.value, primaryKeyword)
        };
    }

    // Generate a single variation
    function generateVariation(index, template, toneTemplate, primaryKeyword, secondaryKeywords, pageContent) {
        const title = generateTitle(index, template, toneTemplate, primaryKeyword, secondaryKeywords);
        const description = generateDescription(index, template, toneTemplate, primaryKeyword, secondaryKeywords, pageContent);
        
        return {
            title: title,
            description: description,
            titleLength: title.length,
            descLength: description.length
        };
    }

    // Generate title
    function generateTitle(index, template, toneTemplate, primaryKeyword, secondaryKeywords) {
        const patterns = template.titlePatterns;
        const pattern = patterns[index % patterns.length];
        
        let title = pattern
            .replace('[Topic]', primaryKeyword)
            .replace('[Year]', new Date().getFullYear())
            .replace('[Product]', primaryKeyword)
            .replace('[Service]', primaryKeyword)
            .replace('[Brand]', 'Your Brand')
            .replace('[Location]', 'Your Location')
            .replace('[Number]', getRandomNumber())
            .replace('[Offer]', primaryKeyword + ' Offer')
            .replace('[Benefit]', getRandomItem(toneTemplate.adjectives) + ' Results')
            .replace('[Solution]', primaryKeyword + ' Solution')
            .replace('[Problem]', getRandomProblem(primaryKeyword));

        // Add power word occasionally
        if (Math.random() > 0.5) {
            title = title.replace('Best', getRandomItem(powerWords).charAt(0).toUpperCase() + getRandomItem(powerWords).slice(1));
        }

        // Ensure optimal length
        if (title.length > 60) {
            title = title.substring(0, 57) + '...';
        }

        return title;
    }

    // Generate description
    function generateDescription(index, template, toneTemplate, primaryKeyword, secondaryKeywords, pageContent) {
        const patterns = template.descriptionPatterns;
        const pattern = patterns[index % patterns.length];
        
        let description = pattern
            .replace('[product]', primaryKeyword.toLowerCase())
            .replace('[service]', primaryKeyword.toLowerCase())
            .replace('[topic]', primaryKeyword.toLowerCase())
            .replace('[benefits]', getRandomItem(toneTemplate.adjectives) + ' results')
            .replace('[features]', getRandomFeatures(secondaryKeywords))
            .replace('[results]', getRandomItem(toneTemplate.verbs) + ' amazing outcomes')
            .replace('[goal]', getRandomGoal(primaryKeyword))
            .replace('[problem]', getRandomProblem(primaryKeyword))
            .replace('[solution]', primaryKeyword + ' solution')
            .replace('[year]', new Date().getFullYear())
            .replace('[number]', getRandomNumber())
            .replace('[location]', 'your area')
            .replace('[brand]', 'our company')
            .replace('[achievement]', getRandomAchievement())
            .replace('[offer]', 'special offer')
            .replace('[guarantee]', 'satisfaction guarantee');

        // Add secondary keywords if available
        if (secondaryKeywords.length > 0 && description.length < 120) {
            const extraKeywords = secondaryKeywords.slice(0, 2).join(', ');
            description += ` Features ${extraKeywords}.`;
        }

        // Ensure optimal length
        if (description.length > 155) {
            description = description.substring(0, 152) + '...';
        }

        return description;
    }

    // Generate keyword suggestions
    function generateKeywordSuggestions(primaryKeyword, secondaryKeywords, pageContent) {
        const baseSuggestions = [
            primaryKeyword,
            `best ${primaryKeyword}`,
            `${primaryKeyword} tips`,
            `${primaryKeyword} guide`,
            `how to ${primaryKeyword}`,
            `${primaryKeyword} strategies`,
            `${primaryKeyword} techniques`
        ];

        const contentBased = pageContent ? [
            `${primaryKeyword} for beginners`,
            `advanced ${primaryKeyword}`,
            `${primaryKeyword} tutorial`
        ] : [];

        return [...new Set([...baseSuggestions, ...contentBased, ...secondaryKeywords])].slice(0, 10);
    }

    // Analyze meta tags
    function analyzeMetaTags(variation, primaryKeyword) {
        const title = variation.title;
        const description = variation.description;

        // Keyword analysis
        const keywordInTitle = title.toLowerCase().includes(primaryKeyword.toLowerCase());
        const keywordInDesc = description.toLowerCase().includes(primaryKeyword.toLowerCase());
        const keywordPosition = title.toLowerCase().indexOf(primaryKeyword.toLowerCase());
        const keywordScore = calculateKeywordScore(keywordInTitle, keywordInDesc, keywordPosition);

        // Length analysis
        const titleLengthScore = calculateLengthScore(title.length, 50, 60);
        const descLengthScore = calculateLengthScore(description.length, 120, 155);
        const lengthScore = Math.round((titleLengthScore + descLengthScore) / 2);

        // Engagement analysis
        const engagementScore = calculateEngagementScore(title, description);

        // Readability analysis
        const readabilityScore = calculateReadabilityScore(title, description);

        // Overall score
        const overallScore = Math.round((keywordScore + lengthScore + engagementScore + readabilityScore) / 4);

        return {
            overallScore: overallScore,
            keywordScore: keywordScore,
            lengthScore: lengthScore,
            engagementScore: engagementScore,
            readabilityScore: readabilityScore,
            details: {
                keyword: generateKeywordDetails(keywordInTitle, keywordInDesc, keywordPosition),
                length: generateLengthDetails(title.length, description.length),
                engagement: generateEngagementDetails(title, description),
                readability: generateReadabilityDetails(title, description)
            }
        };
    }

    // Calculate individual scores
    function calculateKeywordScore(inTitle, inDesc, position) {
        let score = 0;
        if (inTitle) score += 40;
        if (inDesc) score += 30;
        if (position >= 0 && position <= 20) score += 30;
        return Math.min(100, score);
    }

    function calculateLengthScore(length, min, max) {
        if (length >= min && length <= max) return 100;
        if (length >= min - 5 && length <= max + 5) return 80;
        if (length >= min - 10 && length <= max + 10) return 60;
        return 40;
    }

    function calculateEngagementScore(title, description) {
        let score = 50;
        
        // Power words
        const titlePowerWords = powerWords.filter(word => title.toLowerCase().includes(word));
        const descPowerWords = powerWords.filter(word => description.toLowerCase().includes(word));
        score += (titlePowerWords.length + descPowerWords.length) * 5;

        // Numbers
        if (/\d/.test(title)) score += 10;
        if (/\d/.test(description)) score += 10;

        // Action words
        const actionWords = ['discover', 'learn', 'get', 'try', 'start', 'join'];
        const hasActionWord = actionWords.some(word => 
            description.toLowerCase().includes(word)
        );
        if (hasActionWord) score += 10;

        return Math.min(100, score);
    }

    function calculateReadabilityScore(title, description) {
        let score = 70;
        
        // Title readability
        const titleWords = title.split(' ').length;
        if (titleWords >= 5 && titleWords <= 8) score += 10;
        
        // Description readability
        const descWords = description.split(' ').length;
        if (descWords >= 15 && descWords <= 25) score += 10;
        
        // Sentence structure
        const hasComplexChars = /[|:—]/.test(title);
        if (!hasComplexChars) score += 10;

        return Math.min(100, score);
    }

    // Generate analysis details
    function generateKeywordDetails(inTitle, inDesc, position) {
        if (inTitle && inDesc && position <= 20) {
            return "Perfect keyword placement in title and description";
        } else if (inTitle && inDesc) {
            return "Good keyword usage in both title and description";
        } else if (inTitle) {
            return "Keyword in title but missing in description";
        } else if (inDesc) {
            return "Keyword in description but missing in title";
        } else {
            return "Primary keyword missing from both title and description";
        }
    }

    function generateLengthDetails(titleLength, descLength) {
        const titleStatus = titleLength >= 50 && titleLength <= 60 ? "optimal" :
                           titleLength < 50 ? "too short" : "too long";
        
        const descStatus = descLength >= 120 && descLength <= 155 ? "optimal" :
                          descLength < 120 ? "too short" : "too long";
        
        return `Title: ${titleLength} chars (${titleStatus}), Description: ${descLength} chars (${descStatus})`;
    }

    function generateEngagementDetails(title, description) {
        const features = [];
        if (powerWords.some(word => title.toLowerCase().includes(word))) features.push("power words");
        if (/\d/.test(title)) features.push("numbers");
        if (description.includes('!') || description.includes('?')) features.push("engagement punctuation");
        if (description.toLowerCase().includes('discover') || description.toLowerCase().includes('learn')) features.push("action-oriented");

        return features.length > 0 ? 
            `Good engagement features: ${features.join(', ')}` :
            "Consider adding power words, numbers, or action phrases";
    }

    function generateReadabilityDetails(title, description) {
        const titleWords = title.split(' ').length;
        const descSentences = description.split(/[.!?]+/).length;
        
        return `Title: ${titleWords} words, Description: ${descSentences} sentences - Good readability`;
    }

    // Display results
    function displayResults(results) {
        // Update header
        contentTypeBadge.textContent = results.contentType;
        scoreValue.textContent = results.analysis.overallScore;

        // Update preview
        previewTitle.textContent = results.variations[0].title;
        previewDescription.textContent = results.variations[0].description;
        previewUrl.textContent = results.url;

        // Update variations
        updateVariations(results.variations);

        // Update analysis
        updateAnalysis(results.analysis);

        // Update keywords
        updateKeywords(results.keywordSuggestions);

        // Show results
        resultsPlaceholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');
    }

    // Update variations
    function updateVariations(variations) {
        variations.forEach((variation, index) => {
            const version = index + 1;
            
            // Update titles
            const titleElement = document.getElementById(`title-${version}`);
            const titleCount = document.getElementById(`title-count-${version}`);
            titleElement.textContent = variation.title;
            titleCount.textContent = `${variation.titleLength}/60`;
            titleCount.className = `char-count ${getLengthClass(variation.titleLength, 50, 60)}`;
            
            // Update descriptions
            const descElement = document.getElementById(`description-${version}`);
            const descCount = document.getElementById(`desc-count-${version}`);
            descElement.textContent = variation.description;
            descCount.textContent = `${variation.descLength}/155`;
            descCount.className = `char-count ${getLengthClass(variation.descLength, 120, 155)}`;
        });
    }

    // Update analysis
    function updateAnalysis(analysis) {
        keywordScore.textContent = analysis.keywordScore + '%';
        keywordScore.className = `analysis-score ${getScoreClass(analysis.keywordScore)}`;
        keywordDetails.textContent = analysis.details.keyword;

        lengthScore.textContent = analysis.lengthScore + '%';
        lengthScore.className = `analysis-score ${getScoreClass(analysis.lengthScore)}`;
        lengthDetails.textContent = analysis.details.length;

        engagementScore.textContent = analysis.engagementScore + '%';
        engagementScore.className = `analysis-score ${getScoreClass(analysis.engagementScore)}`;
        engagementDetails.textContent = analysis.details.engagement;

        readabilityScore.textContent = analysis.readabilityScore + '%';
        readabilityScore.className = `analysis-score ${getScoreClass(analysis.readabilityScore)}`;
        readabilityDetails.textContent = analysis.details.readability;
    }

    // Update keywords
    function updateKeywords(keywords) {
        keywordsGrid.innerHTML = '';
        
        keywords.forEach((keyword, index) => {
            const tag = document.createElement('div');
            tag.className = `keyword-tag ${index === 0 ? 'primary' : ''}`;
            tag.textContent = keyword;
            tag.addEventListener('click', () => {
                primaryKeywordInput.value = keyword;
            });
            keywordsGrid.appendChild(tag);
        });
    }

    // Helper functions
    function getRandomItem(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    function getRandomNumber() {
        return [5, 7, 10, 15, 21, 25][Math.floor(Math.random() * 6)];
    }

    function getRandomProblem(keyword) {
        const problems = [
            `common ${keyword} challenges`,
            `struggling with ${keyword}`,
            `${keyword} difficulties`,
            `frustrating ${keyword} issues`
        ];
        return getRandomItem(problems);
    }

    function getRandomGoal(keyword) {
        const goals = [
            `master ${keyword}`,
            `improve your ${keyword}`,
            `excel at ${keyword}`,
            `succeed with ${keyword}`
        ];
        return getRandomItem(goals);
    }

    function getRandomFeatures(keywords) {
        if (keywords.length > 0) {
            return keywords.slice(0, 2).join(', ');
        }
        return 'advanced features, easy setup';
    }

    function getRandomAchievement() {
        const achievements = [
            'transformed their business',
            'achieved amazing results',
            'doubled their traffic',
            'improved their rankings'
        ];
        return getRandomItem(achievements);
    }

    function generateUrl(pageTitle, keyword) {
        const baseUrl = 'https://www.yourwebsite.com/';
        const slug = pageTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
        return baseUrl + slug;
    }

    function getLengthClass(length, min, max) {
        if (length >= min && length <= max) return 'good';
        if (length >= min - 5 && length <= max + 5) return 'warning';
        return 'danger';
    }

    function getScoreClass(score) {
        if (score >= 80) return 'good';
        if (score >= 60) return 'warning';
        return 'danger';
    }

    function switchVersion(version) {
        // Update tabs
        tabButtons.forEach(btn => btn.classList.remove('active'));
        document.querySelector(`[data-version="${version}"]`).classList.add('active');
        
        // Update content
        document.querySelectorAll('.meta-version').forEach(div => div.classList.remove('active'));
        document.getElementById(`version-${version}`).classList.add('active');
        
        // Update preview
        const titleElement = document.getElementById(`title-${version}`);
        const descElement = document.getElementById(`description-${version}`);
        previewTitle.textContent = titleElement.textContent;
        previewDescription.textContent = descElement.textContent;
    }

    function copyToClipboard(elementId) {
        const element = document.getElementById(elementId);
        const text = element.textContent;
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copied to clipboard!');
        });
    }

    function copyAllMetaTags() {
        const activeVersion = document.querySelector('.meta-version.active');
        const title = activeVersion.querySelector('.meta-content').textContent;
        const description = activeVersion.querySelectorAll('.meta-content')[1].textContent;
        
        const metaTags = `<title>${title}</title>\n<meta name="description" content="${description}">`;
        
        navigator.clipboard.writeText(metaTags).then(() => {
            showNotification('All meta tags copied to clipboard!');
        });
    }

    function saveTemplate() {
        showNotification('Template saved! (This is a demo)');
    }

    function setLoadingState(isLoading) {
        if (isLoading) {
            generateBtn.disabled = true;
            resultsPlaceholder.classList.add('hidden');
            resultsContent.classList.add('hidden');
            loadingIndicator.classList.remove('hidden');
            
            const btnText = generateBtn.querySelector('.btn-text');
            const btnLoading = generateBtn.querySelector('.btn-loading');
            btnText.classList.add('hidden');
            btnLoading.classList.remove('hidden');
        } else {
            generateBtn.disabled = false;
            loadingIndicator.classList.add('hidden');
            
            const btnText = generateBtn.querySelector('.btn-text');
            const btnLoading = generateBtn.querySelector('.btn-loading');
            btnText.classList.remove('hidden');
            btnLoading.classList.add('hidden');
        }
    }

    function showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            font-weight: 600;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }

    // Initialize with demo data
    function initializeDemo() {
        pageTitleInput.value = 'Digital Marketing Strategies';
        pageContentInput.value = 'Learn the latest digital marketing strategies for 2024 including SEO, social media marketing, content marketing, and email marketing. Discover proven techniques to grow your business online.';
        primaryKeywordInput.value = 'digital marketing';
        secondaryKeywordsInput.value = 'SEO, social media, content marketing, email marketing';
    }

    // Initialize the demo
    initializeDemo();
});
// Add CSS for tools links
const toolsStyles = document.createElement('style');
toolsStyles.textContent = `
    .tools-links-container {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 2px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    
    .tools-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    
    .tools-header h3 {
        color: #1e293b;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: 700;
    }
    
    .tools-header p {
        color: #64748b;
        font-size: 0.9rem;
    }
    
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .tool-link {
        background: white;
        border: 2px solid #f1f5f9;
        border-radius: 12px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        text-decoration: none;
        transition: all 0.3s ease;
        color: inherit;
    }
    
    .tool-link:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
        text-decoration: none;
        color: inherit;
    }
    
    .tool-icon {
        font-size: 2rem;
        flex-shrink: 0;
    }
    
    .tool-content h4 {
        color: #1e293b;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        font-weight: 600;
    }
    
    .tool-content p {
        color: #64748b;
        font-size: 0.8rem;
        margin: 0;
        line-height: 1.4;
    }
`;
document.head.appendChild(toolsStyles);