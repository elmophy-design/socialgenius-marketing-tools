<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Value Proposition Generator</title>
  <style>
    /* Your existing CSS styles remain exactly the same */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    body {
      background: #f9fafc;
      color: #333;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      padding: 2rem;
    }

    header {
      text-align: center;
      margin-bottom: 2rem;
    }

    header h1 {
      font-size: 2rem;
      color: #004aad;
      margin-bottom: 0.5rem;
    }

    header p {
      color: #555;
      font-size: 1rem;
    }

    form#value-prop-form {
      background: #fff;
      border-radius: 16px;
      padding: 2rem;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
      width: 100%;
      max-width: 600px;
      display: flex;
      flex-direction: column;
      gap: 1.2rem;
      transition: 0.3s ease-in-out;
    }

    form#value-prop-form label {
      font-weight: 600;
      color: #222;
    }

    form#value-prop-form select,
    form#value-prop-form input {
      padding: 0.75rem;
      border-radius: 10px;
      border: 1px solid #ccc;
      font-size: 1rem;
      width: 100%;
      transition: all 0.2s ease;
    }

    form#value-prop-form select:focus,
    form#value-prop-form input:focus {
      border-color: #004aad;
      outline: none;
      box-shadow: 0 0 5px rgba(0, 74, 173, 0.3);
    }

    button {
      background: #004aad;
      color: #fff;
      padding: 0.9rem;
      border: none;
      border-radius: 10px;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.3s;
    }

    button:hover {
      background: #0066ff;
    }

    #lead-magnet {
      background: #fff;
      border-radius: 16px;
      padding: 2rem;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
      margin-top: 2rem;
      width: 100%;
      max-width: 600px;
      display: none;
      text-align: center;
    }

    #lead-magnet.visible {
      display: block;
    }

    #lead-magnet h2 {
      color: #004aad;
      margin-bottom: 1rem;
    }

    #lead-magnet p#result-text {
      background: #eef4ff;
      padding: 1rem;
      border-radius: 10px;
      color: #333;
      margin-bottom: 1.5rem;
    }

    #lead-form {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    #lead-form input[type="email"] {
      padding: 0.75rem;
      border: 1px solid #ccc;
      border-radius: 10px;
      font-size: 1rem;
    }

    #lead-form button {
      background: #28a745;
    }

    #lead-form button:hover {
      background: #34c759;
    }

    .hidden {
      display: none;
    }

    .result-box {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      background: #f9f9f9;
      padding: 15px 20px;
      border-radius: 10px;
      margin: 15px 0;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    #result-text {
      flex: 1;
      margin-right: 10px;
      font-size: 1rem;
      color: #333;
    }

    #copy-btn {
      background: #007bff;
      color: #fff;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    #copy-btn:hover {
      background: #0056b3;
    }

    #error-message {
      color: #e74c3c;
      background-color: #ffebee;
      margin: 10px 0;
      font-size: 1rem;
      padding: 10px 15px;
      border-radius: 8px;
      border-left: 4px solid #e74c3c;
      width: 100%;
      max-width: 600px;
    }

    #success-message {
      color: #27ae60;
      background-color: #e8f5e9;
      margin: 10px 0;
      font-size: 1rem;
      padding: 10px 15px;
      border-radius: 8px;
      border-left: 4px solid #27ae60;
      width: 100%;
      max-width: 600px;
    }

    .loading {
      position: relative;
      color: transparent;
    }

    .loading::after {
      content: "";
      position: absolute;
      width: 20px;
      height: 20px;
      top: 50%;
      left: 50%;
      margin-left: -10px;
      margin-top: -10px;
      border: 2px solid #ffffff;
      border-radius: 50%;
      border-top-color: transparent;
      animation: spin 1s ease-in-out infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  <header>
    <h1>Value Proposition Generator</h1>
    <p>Create a compelling value proposition for your business</p>
  </header>

  <form id="value-prop-form">
    <label for="brand">Brand Name</label>
    <input id="brand" type="text" placeholder="e.g., Meritlives LLC" required>

    <label for="industry">Industry</label>
    <select id="industry" required>
      <option value="" disabled selected>Select an industry</option>
      <option value="technology">Technology</option>
      <option value="healthcare">Healthcare</option>
      <option value="retail">Retail</option>
      <option value="education">Education</option>
      <option value="finance">Finance & Banking</option>
      <option value="real-estate">Real Estate</option>
      <option value="hospitality">Hospitality & Tourism</option>
      <option value="manufacturing">Manufacturing</option>
      <option value="consulting">Consulting</option>
      <option value="non-profit">Non-Profit</option>
      <option value="ecommerce">E-commerce</option>
      <option value="automotive">Automotive</option>
      <option value="energy">Energy & Utilities</option>
      <option value="media">Media & Entertainment</option>
      <option value="construction">Construction</option>
    </select>

    <label for="audience">Target Audience</label>
    <select id="audience" required>
      <option value="" disabled selected>Select an audience</option>
      <option value="small-businesses">Small Businesses</option>
      <option value="startups">Startups</option>
      <option value="freelancers">Freelancers</option>
      <option value="enterprises">Enterprises</option>
      <option value="millennials">Millennials</option>
      <option value="gen-z">Gen Z</option>
      <option value="seniors">Seniors</option>
      <option value="parents">Parents</option>
      <option value="students">Students</option>
      <option value="professionals">Professionals</option>
      <option value="healthcare-providers">Healthcare Providers</option>
      <option value="educators">Educators</option>
      <option value="creators">Content Creators</option>
      <option value="investors">Investors</option>
      <option value="non-profit-organizations">Non-Profit Organizations</option>
    </select>

    <label for="goal">Goal</label>
    <select id="goal" required>
      <option value="" disabled selected>Select a goal</option>
      <option value="increase-sales">Increase Sales</option>
      <option value="improve-efficiency">Improve Efficiency</option>
      <option value="boost-engagement">Boost Engagement</option>
      <option value="reduce-costs">Reduce Costs</option>
      <option value="enhance-brand-awareness">Enhance Brand Awareness</option>
      <option value="generate-leads">Generate Leads</option>
      <option value="improve-customer-retention">Improve Customer Retention</option>
      <option value="expand-market-reach">Expand Market Reach</option>
      <option value="launch-new-product">Launch New Product</option>
      <option value="optimize-operations">Optimize Operations</option>
      <option value="increase-web-traffic">Increase Web Traffic</option>
      <option value="improve-customer-service">Improve Customer Service</option>
      <option value="build-community">Build Community</option>
      <option value="establish-thought-leadership">Establish Thought Leadership</option>
    </select>

    <label for="strength">Strength</label>
    <select id="strength" required>
      <option value="" disabled selected>Select a strength</option>
      <option value="innovative-solutions">Innovative Solutions</option>
      <option value="expert-support">Expert Support</option>
      <option value="user-friendly-tools">User-Friendly Tools</option>
      <option value="cost-effective-strategies">Cost-Effective Strategies</option>
      <option value="proven-methodology">Proven Methodology</option>
      <option value="cutting-edge-technology">Cutting-Edge Technology</option>
      <option value="personalized-approach">Personalized Approach</option>
      <option value="data-driven-insights">Data-Driven Insights</option>
      <option value="industry-expertise">Industry Expertise</option>
      <option value="seamless-integration">Seamless Integration</option>
      <option value="scalable-solutions">Scalable Solutions</option>
      <option value="quick-implementation">Quick Implementation</option>
      <option value="comprehensive-support">Comprehensive Support</option>
      <option value="competitive-pricing">Competitive Pricing</option>
    </select>

    <button type="submit" id="generate-btn">Generate Value Proposition</button>
  </form>

  <div id="lead-magnet" class="hidden">
    <h2>Your Value Proposition</h2>
    <div class="result-box">
      <p id="result-text"></p>
      <button id="copy-btn">Copy Text</button>
    </div>
    <form id="lead-form">
      <input id="email" type="email" placeholder="Enter your email for a free guide" required>
      <button type="submit" id="submit-email-btn">Get Free Guide</button>
    </form>
  </div>

  <div id="error-message" aria-live="assertive"></div>
  <div id="success-message" aria-live="polite"></div>

  <script>
    document.addEventListener("DOMContentLoaded", () => {
      // --- Get DOM Elements ---
      const form = document.getElementById("value-prop-form");
      const leadMagnet = document.getElementById("lead-magnet");
      const resultText = document.getElementById("result-text");
      const leadForm = document.getElementById("lead-form");
      const copyBtn = document.getElementById("copy-btn");
      const errorDiv = document.getElementById("error-message");
      const successDiv = document.getElementById("success-message");
      const generateBtn = document.getElementById("generate-btn");
      const submitEmailBtn = document.getElementById("submit-email-btn");

      // --- Backend API URL ---
      const API_BASE_URL = 'http://localhost:4000'; // Your backend server

      // --- Handle Main Form Submission (UPDATED) ---
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const industry = document.getElementById("industry").value;
        const audience = document.getElementById("audience").value;
        const goal = document.getElementById("goal").value;
        const strength = document.getElementById("strength").value;
        const brand = document.getElementById("brand").value.trim();

        if (!industry || !audience || !goal || !strength || !brand) {
          showError("Please complete all fields first.");
          return;
        }
        
        clearMessages();

        // Show loading state on generate button
        generateBtn.disabled = true;
        generateBtn.classList.add("loading");

        try {
          // Generate value proposition via backend (NEW ENDPOINT)
          const response = await fetch(`${API_BASE_URL}/generate-value-prop`, {
            method: "POST",
            headers: { 
              "Content-Type": "application/json" 
            },
            body: JSON.stringify({
              brand: brand,
              industry: industry,
              audience: audience,
              goal: goal,
              strength: strength
            })
          });

          const data = await response.json();

          if (!response.ok) {
            throw new Error(data.error || 'Failed to generate value proposition');
          }

          // Show result
          resultText.textContent = data.valueProposition;
          leadMagnet.classList.remove("hidden");
          leadMagnet.classList.add("visible");
          leadMagnet.scrollIntoView({ behavior: "smooth" });
          
        } catch (error) {
          console.error("❌ Failed to generate value proposition:", error);
          showError(error.message || "Something went wrong. Please try again later.");
        } finally {
          // Remove loading state
          generateBtn.disabled = false;
          generateBtn.classList.remove("loading");
        }
      });

      // --- Handle Lead Magnet Form Submission ---
      leadForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = document.getElementById("email").value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!email || !emailRegex.test(email)) {
          showError("Please enter a valid email address.");
          return;
        }
        
        clearMessages();

        // Show loading state
        submitEmailBtn.disabled = true;
        submitEmailBtn.classList.add("loading");

        try {
          // Send email via backend API
          const response = await fetch(`${API_BASE_URL}/send-email`, {
            method: "POST",
            headers: { 
              "Content-Type": "application/json" 
            },
            body: JSON.stringify({
              email: email,
              brand: document.getElementById("brand").value,
              valueProp: resultText.textContent
            })
          });

          const data = await response.json();

          if (!response.ok) {
            throw new Error(data.error || 'Failed to send email');
          }

          showSuccess(`Thanks, ${email}! Your free marketing guide is on its way 🚀`);
          leadForm.reset();
        } catch (error) {
          console.error("❌ Failed to send email:", error);
          showError(error.message || "Something went wrong. Please try again later.");
        } finally {
          // Remove loading state
          submitEmailBtn.disabled = false;
          submitEmailBtn.classList.remove("loading");
        }
      });

      // --- Copy to Clipboard Feature ---
      copyBtn.addEventListener("click", () => {
        const text = resultText.textContent;
        if (!text) {
          showError("There is no text to copy yet!");
          return;
        }
        
        clearMessages();

        navigator.clipboard.writeText(text)
          .then(() => {
            copyBtn.textContent = "Copied!";
            copyBtn.style.backgroundColor = "#28a745";
            setTimeout(() => {
              copyBtn.textContent = "Copy Text";
              copyBtn.style.backgroundColor = "#007bff";
            }, 2000);
          })
          .catch(() => {
            showError("Failed to copy. Please try again manually.");
          });
      });

      // --- Utility Functions ---
      function clearMessages() {
        errorDiv.textContent = "";
        successDiv.textContent = "";
      }

      function showError(message) {
        errorDiv.textContent = message;
        successDiv.textContent = "";
      }

      function showSuccess(message) {
        successDiv.textContent = message;
        errorDiv.textContent = "";
      }
    });
  </script>
</body>
</html>