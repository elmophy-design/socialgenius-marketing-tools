// ===============================
// 📦 Required Dependencies
// ===============================
import express from "express";
import dotenv from "dotenv";
import nodemailer from "nodemailer";
import cors from "cors";

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// ===============================
// ⚙️ Middleware
// ===============================
app.use(cors());
app.use(express.json());

// ===============================
// 📩 Brevo SMTP Setup - NO HARDCODED CREDENTIALS
// ===============================
if (!process.env.BREVO_SMTP_USER || !process.env.BREVO_SMTP_PASS) {
  console.error("❌ Missing Brevo SMTP credentials in environment variables");
  console.error("💡 Please check your .env file");
  process.exit(1);
}

const transporter = nodemailer.createTransport({
  host: process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com",
  port: parseInt(process.env.BREVO_SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.BREVO_SMTP_USER,
    pass: process.env.BREVO_SMTP_PASS,
  },
  tls: {
    rejectUnauthorized: false
  }
});

// ===============================
// 🎯 Grammar and Language Helpers
// ===============================
function capitalizeFirst(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function getArticle(word) {
  const vowels = ['a', 'e', 'i', 'o', 'u'];
  return vowels.includes(word[0]?.toLowerCase()) ? 'an' : 'a';
}

function cleanText(text) {
  return text.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

function chooseConnector(goal) {
  const verbLike = ["increase", "grow", "boost", "expand", "improve", "enhance", "generate", "optimize", "build", "establish"];
  const firstWord = goal.split('-')[0].toLowerCase();
  return verbLike.includes(firstWord) ? "to" : "for";
}

function formatGoal(goal) {
  const goalMap = {
    "increase-sales": "increasing sales",
    "improve-efficiency": "improving efficiency", 
    "boost-engagement": "boosting engagement",
    "reduce-costs": "reducing costs",
    "enhance-brand-awareness": "enhancing brand awareness",
    "generate-leads": "generating leads",
    "improve-customer-retention": "improving customer retention",
    "expand-market-reach": "expanding market reach",
    "launch-new-product": "launching new products",
    "optimize-operations": "optimizing operations",
    "increase-web-traffic": "increasing web traffic",
    "improve-customer-service": "improving customer service",
    "build-community": "building community",
    "establish-thought-leadership": "establishing thought leadership"
  };
  return goalMap[goal] || cleanText(goal);
}

function formatStrength(strength) {
  const strengthMap = {
    "innovative-solutions": "innovative solutions",
    "expert-support": "expert support",
    "user-friendly-tools": "user-friendly tools",
    "cost-effective-strategies": "cost-effective strategies",
    "proven-methodology": "proven methodology",
    "cutting-edge-technology": "cutting-edge technology",
    "personalized-approach": "personalized approach",
    "data-driven-insights": "data-driven insights",
    "industry-expertise": "industry expertise",
    "seamless-integration": "seamless integration",
    "scalable-solutions": "scalable solutions",
    "quick-implementation": "quick implementation",
    "comprehensive-support": "comprehensive support",
    "competitive-pricing": "competitive pricing"
  };
  return strengthMap[strength] || cleanText(strength);
}

function formatAudience(audience) {
  const audienceMap = {
    "small-businesses": "small businesses",
    "startups": "startups", 
    "freelancers": "freelancers",
    "enterprises": "enterprises",
    "millennials": "Millennials",
    "gen-z": "Gen Z",
    "seniors": "seniors",
    "parents": "parents",
    "students": "students",
    "professionals": "professionals",
    "healthcare-providers": "healthcare providers",
    "educators": "educators",
    "creators": "creators",
    "investors": "investors",
    "non-profit-organizations": "non-profit organizations"
  };
  return audienceMap[audience] || cleanText(audience);
}

function generateValueProposition(brand, industry, audience, goal, strength) {
  const cleanBrand = brand.trim();
  const cleanIndustry = cleanText(industry);
  const cleanAudience = formatAudience(audience);
  const cleanGoal = formatGoal(goal);
  const cleanStrength = formatStrength(strength);
  
  const connector = chooseConnector(goal);
  
  // Different sentence structures for variety and better grammar
  const templates = [
    `${cleanBrand} helps ${cleanAudience} in the ${cleanIndustry} industry ${connector} ${cleanGoal} through our ${cleanStrength}.`,
    `${cleanBrand} empowers ${cleanAudience} in ${getArticle(cleanIndustry)} ${cleanIndustry} industry ${connector} ${cleanGoal} with our ${cleanStrength}.`,
    `For ${cleanAudience} in the ${cleanIndustry} sector, ${cleanBrand} delivers ${cleanGoal} via our ${cleanStrength}.`,
    `${cleanBrand} provides ${cleanAudience} in the ${cleanIndustry} industry with the tools ${connector} ${cleanGoal}, powered by our ${cleanStrength}.`,
    `Through our ${cleanStrength}, ${cleanBrand} enables ${cleanAudience} in the ${cleanIndustry} industry ${connector} ${cleanGoal}.`
  ];
  
  // Choose a random template for variety
  const randomTemplate = templates[Math.floor(Math.random() * templates.length)];
  return capitalizeFirst(randomTemplate);
}

// Test SMTP connection on startup
console.log("🔧 Testing Brevo SMTP connection...");
console.log("📧 SMTP Server:", process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com");

transporter.verify(function (error, success) {
  if (error) {
    console.error("❌ SMTP Connection Failed:", error.message);
    console.log("\n💡 Please check your .env file configuration");
  } else {
    console.log("✅ Brevo SMTP Connection Successful!");
    console.log("🚀 Ready to send emails from your verified domains");
  }
});

// ===============================
// 📨 Route: Send Email
// ===============================
app.post("/send-email", async (req, res) => {
  const { email, brand, valueProp } = req.body;

  if (!email || !valueProp) {
    return res.status(400).json({ 
      success: false, 
      error: "Email and value proposition are required." 
    });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ 
      success: false, 
      error: "Please provide a valid email address." 
    });
  }

  // Use your verified sender email as the FROM address
  const fromEmail = "adamsemmanuel@meritlives.com";

  const mailOptions = {
    from: {
      name: brand ? `${brand} - Value Proposition` : "Value Proposition Tool",
      address: fromEmail
    },
    to: email,
    subject: `Your Value Proposition from ${brand || "Meritlives LLC"}`,
    text: `Here's your generated value proposition:\n\n${valueProp}\n\nThanks for using our Value Proposition Generator!\n\n- Meritlives LLC Team`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #004aad; color: white; padding: 25px; border-radius: 10px 10px 0 0; text-align: center;">
          <h1 style="margin: 0; font-size: 28px;">🎯 Your Value Proposition</h1>
          <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">From ${brand || "Meritlives LLC"}</p>
        </div>
        
        <div style="background: #f9fafc; padding: 30px; border-radius: 0 0 10px 10px;">
          <div style="background: white; padding: 25px; border-radius: 8px; border-left: 4px solid #004aad; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <p style="font-size: 18px; line-height: 1.6; margin: 0; color: #333; font-weight: 500; font-style: italic;">"${valueProp}"</p>
          </div>
          
          <p style="color: #666; line-height: 1.6; font-size: 16px;">We hope this value proposition helps you communicate your unique value to customers effectively.</p>
          
          <div style="background: #e8f4ff; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="margin: 0; color: #004aad; font-size: 14px;">
              <strong>💡 Pro Tip:</strong> Use this value proposition in your marketing materials, website, and sales conversations to clearly communicate your unique value.
            </p>
          </div>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0;">
            <p style="color: #888; font-size: 14px; margin: 0;">
              Best regards,<br>
              <strong>Meritlives LLC Team</strong><br>
              <em>Delivering innovative solutions for your business</em>
            </p>
          </div>
        </div>
      </div>
    `
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ Email sent successfully!`);
    console.log(`📨 To: ${email}`);
    console.log(`👤 From: ${fromEmail}`);
    console.log(`📝 Message ID: ${info.messageId}`);
    
    res.json({ 
      success: true, 
      message: "Email sent successfully! Check your inbox.",
      messageId: info.messageId,
      from: fromEmail
    });
    
  } catch (error) {
    console.error("❌ Error sending email:", error.message);
    
    let errorMessage = "Failed to send email. Please try again later.";
    
    if (error.code === 'EAUTH') {
      errorMessage = "SMTP authentication failed. Please check your server configuration.";
    } else if (error.code === 'EENVELOPE') {
      errorMessage = "Invalid email address. Please check the recipient email.";
    }
    
    res.status(500).json({ 
      success: false, 
      error: errorMessage
    });
  }
});

// ===============================
// 🎯 New Route: Generate Value Proposition
// ===============================
app.post("/generate-value-prop", async (req, res) => {
  const { brand, industry, audience, goal, strength } = req.body;

  if (!brand || !industry || !audience || !goal || !strength) {
    return res.status(400).json({ 
      success: false, 
      error: "All fields are required: brand, industry, audience, goal, and strength." 
    });
  }

  try {
    const valueProposition = generateValueProposition(brand, industry, audience, goal, strength);
    
    console.log(`✅ Generated value proposition for: ${brand}`);
    console.log(`📝 Proposition: ${valueProposition}`);
    
    res.json({ 
      success: true, 
      valueProposition: valueProposition,
      brand: brand
    });
    
  } catch (error) {
    console.error("❌ Error generating value proposition:", error.message);
    
    res.status(500).json({ 
      success: false, 
      error: "Failed to generate value proposition. Please try again."
    });
  }
});

// ===============================
// 🏥 Health Check Route
// ===============================
app.get("/health", (req, res) => {
  res.json({ 
    success: true,
    status: "OK", 
    service: "Value Proposition Generator API",
    timestamp: new Date().toISOString(),
    email: {
      service: "Brevo SMTP",
      configured: !!process.env.BREVO_SMTP_USER,
      verified_sender: "adamsemmanuel@meritlives.com",
      domain: "meritlives.com"
    }
  });
});

// ===============================
// 🚀 Start Server
// ===============================
app.listen(PORT, () => {
  console.log(`\n✨ ==========================================`);
  console.log(`🚀 VALUE PROPOSITION GENERATOR BACKEND`);
  console.log(`✨ ==========================================`);
  console.log(`📍 Server running on port: ${PORT}`);
  console.log(`🔗 Health check: http://localhost:${PORT}/health`);
  console.log(`📧 SMTP Server: ${process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com"}`);
  console.log(`👤 SMTP User: ${process.env.BREVO_SMTP_USER ? "Configured ✅" : "MISSING ❌"}`);
  console.log(`🎯 Sending from: adamsemmanuel@meritlives.com`);
  console.log(`🌐 Verified domain: meritlives.com`);
  console.log(`✨ ==========================================\n`);
});