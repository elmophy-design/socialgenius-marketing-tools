document.addEventListener('DOMContentLoaded', function() {
    // Headline Analyzer Functionality
    const headlineInput = document.getElementById('headline-input');
    const analyzeBtn = document.getElementById('analyze-btn');
    const loadingIndicator = document.getElementById('loading-indicator');
    const generateAlternativesBtn = document.getElementById('generate-alternatives');
// Create tools links container
    const toolsContainer = document.createElement('div');
    toolsContainer.className = 'tools-links-container';
    toolsContainer.innerHTML = `
        <div class="tools-header">
            <h3>🚀 More Content Tools</h3>
            <p>Enhance your content creation workflow</p>
        </div>
        <div class="tools-grid">
            <a href="../social-media-generator/index.html" class="tool-link" data-tool="social-media">
                <div class="tool-icon">📱</div>
                <div class="tool-content">
                    <h4>AI Social Media Generator</h4>
                    <p>Create engaging social media posts and captions</p>
                </div>
            </a>
            
            <a href="../seo-meta-generator/index.html" class="tool-link" data-tool="ai-writer">
                <div class="tool-icon">🔍</div>
                <div class="tool-content">
                    <h4>Seo Meta Generator</h4>
                    <p>create optimized meta tags automatically.</p>
                </div>
            </a>
            
            <a href="../funnel-builder/index.html" class="tool-link" data-tool="seo-analyzer">
                <div class="tool-icon">🔄</div>
                <div class="tool-content">
                    <h4>Funnel Builder</h4>
                    <p>Build complete marketing funnels</p>
                </div>
            </a>
            
            <a href="../email-subject-line-tester/index.html" class="tool-link" data-tool="video-generator">
                <div class="tool-icon">✉️</div>
                <div class="tool-content">
                    <h4>Email Subject Line Tester</h4>
                    <p>analyze and scores subject effectiveness.</p>
                </div>
            </a>
            
            <a href="../Ad-Copy-Generator/index.html" class="tool-link" data-tool="content-planner">
                <div class="tool-icon">🎪</div>
                <div class="tool-content">
                    <h4>Ad Copy Generator</h4>
                    <p>create engaging, high-converting advertisements automatically.</p>
                </div>
            </a>
        </div>
    `;

    // Insert tools container after the main content
    const mainContainer = document.querySelector('.container') || document.querySelector('main');
    if (mainContainer) {
        mainContainer.appendChild(toolsContainer);
    }
    // Analyze button click handler
    analyzeBtn.addEventListener('click', function() {
        const headline = headlineInput.value.trim();
        
        if (!headline) {
            alert('Please enter a headline to analyze');
            return;
        }
        
        analyzeHeadline(headline);
    });

    // Enter key handler for headline input
    headlineInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            analyzeBtn.click();
        }
    });

    // Generate alternatives button handler
    generateAlternativesBtn.addEventListener('click', function() {
        const headline = headlineInput.value.trim();
        
        if (!headline) {
            alert('Please analyze a headline first');
            return;
        }
        
        generateAlternativeHeadlines(headline);
    });

    // Headline analysis function
    function analyzeHeadline(headline) {
        // Show loading indicator
        loadingIndicator.classList.remove('hidden');
        analyzeBtn.disabled = true;
        
        // Simulate API call delay
        setTimeout(() => {
            // Calculate metrics
            const wordCount = headline.split(/\s+/).length;
            const charCount = headline.length;
            
            // Calculate sentiment (simplified)
            const sentimentScore = calculateSentiment(headline);
            
            // Calculate readability (simplified Flesch Reading Ease approximation)
            const readabilityScore = calculateReadability(headline);
            
            // Calculate overall score
            const overallScore = calculateOverallScore(headline, wordCount, charCount, sentimentScore, readabilityScore);
            
            // Update UI with results
            updateResults(headline, overallScore, wordCount, charCount, sentimentScore, readabilityScore);
            
            // Hide loading indicator
            loadingIndicator.classList.add('hidden');
            analyzeBtn.disabled = false;
        }, 1500);
    }

    // Calculate sentiment score (simplified)
    function calculateSentiment(headline) {
        const positiveWords = ['amazing', 'best', 'brilliant', 'excellent', 'fantastic', 'great', 'incredible', 'perfect', 'remarkable', 'superb', 'ultimate', 'winning'];
        const negativeWords = ['avoid', 'bad', 'beware', 'disaster', 'fail', 'horrible', 'mistake', 'never', 'terrible', 'warning', 'worst'];
        
        const words = headline.toLowerCase().split(/\s+/);
        let score = 50; // Neutral baseline
        
        words.forEach(word => {
            if (positiveWords.some(positive => word.includes(positive))) {
                score += 10;
            }
            if (negativeWords.some(negative => word.includes(negative))) {
                score -= 10;
            }
        });
        
        return Math.max(0, Math.min(100, score));
    }

    // Calculate readability score (simplified)
    function calculateReadability(headline) {
        const wordCount = headline.split(/\s+/).length;
        const sentenceCount = headline.split(/[.!?]+/).length;
        const syllableCount = estimateSyllables(headline);
        
        // Simplified Flesch Reading Ease approximation
        let score = 100 - (wordCount / sentenceCount * 1.015) - (syllableCount / wordCount * 84.6);
        
        return Math.max(0, Math.min(100, score));
    }

    // Estimate syllables in text (simplified)
    function estimateSyllables(text) {
        text = text.toLowerCase();
        let count = 0;
        
        // Count vowels (simplified approach)
        const vowels = 'aeiouy';
        let prevCharIsVowel = false;
        
        for (let i = 0; i < text.length; i++) {
            const char = text[i];
            if (vowels.includes(char)) {
                if (!prevCharIsVowel) {
                    count++;
                }
                prevCharIsVowel = true;
            } else {
                prevCharIsVowel = false;
            }
        }
        
        // Adjust for common exceptions
        if (text.endsWith('e')) count--;
        if (count === 0) count = 1;
        
        return count;
    }

    // Calculate overall score
    function calculateOverallScore(headline, wordCount, charCount, sentimentScore, readabilityScore) {
        let score = 0;
        
        // Word count scoring (optimal: 6-12 words)
        if (wordCount >= 6 && wordCount <= 12) {
            score += 25;
        } else if (wordCount >= 4 && wordCount <= 15) {
            score += 15;
        } else {
            score += 5;
        }
        
        // Character count scoring (optimal: 50-60 characters)
        if (charCount >= 50 && charCount <= 60) {
            score += 25;
        } else if (charCount >= 40 && charCount <= 70) {
            score += 15;
        } else {
            score += 5;
        }
        
        // Sentiment scoring
        score += sentimentScore * 0.25;
        
        // Readability scoring
        score += readabilityScore * 0.25;
        
        // Bonus for power words, numbers, etc.
        const powerWords = ['free', 'new', 'proven', 'secret', 'surprising', 'you', 'your'];
        const hasPowerWord = powerWords.some(word => headline.toLowerCase().includes(word));
        const hasNumber = /\d/.test(headline);
        
        if (hasPowerWord) score += 5;
        if (hasNumber) score += 5;
        
        return Math.round(Math.min(100, score));
    }

    // Update UI with analysis results
    function updateResults(headline, overallScore, wordCount, charCount, sentimentScore, readabilityScore) {
        // Update score circle
        document.getElementById('score-value').textContent = overallScore;
        const scoreCircle = document.getElementById('score-circle');
        scoreCircle.style.background = `conic-gradient(var(--primary) ${overallScore}%, #e9ecef ${overallScore}%)`;
        
        // Update score description
        const scoreDescription = document.getElementById('score-description');
        if (overallScore >= 80) {
            scoreDescription.textContent = "Excellent! This headline has high potential for engagement.";
        } else if (overallScore >= 60) {
            scoreDescription.textContent = "Good headline. With some optimization, it could perform even better.";
        } else if (overallScore >= 40) {
            scoreDescription.textContent = "Average headline. Consider implementing the suggestions below.";
        } else {
            scoreDescription.textContent = "This headline needs significant improvement. Check the suggestions below.";
        }
        
        // Update metrics
        document.getElementById('word-count').textContent = wordCount;
        document.getElementById('char-count').textContent = charCount;
        document.getElementById('sentiment-score').textContent = sentimentScore;
        document.getElementById('readability-score').textContent = Math.round(readabilityScore);
        
        // Generate strengths and improvements
        generateStrengthsAndImprovements(headline, overallScore, wordCount, charCount, sentimentScore, readabilityScore);
        
        // Generate suggestions
        generateSuggestions(headline, overallScore, wordCount, charCount, sentimentScore, readabilityScore);
    }

    // Generate strengths and improvements lists
    function generateStrengthsAndImprovements(headline, overallScore, wordCount, charCount, sentimentScore, readabilityScore) {
        const strengthsList = document.getElementById('strengths-list');
        const improvementsList = document.getElementById('improvements-list');
        
        // Clear previous content
        strengthsList.innerHTML = '';
        improvementsList.innerHTML = '';
        
        // Generate strengths based on analysis
        const strengths = [];
        const improvements = [];
        
        // Word count analysis
        if (wordCount >= 6 && wordCount <= 12) {
            strengths.push("Optimal word count for engagement");
        } else if (wordCount < 6) {
            improvements.push("Consider adding more words for better context");
        } else {
            improvements.push("Consider shortening for better readability");
        }
        
        // Character count analysis
        if (charCount >= 50 && charCount <= 60) {
            strengths.push("Ideal length for search engine visibility");
        } else if (charCount < 50) {
            improvements.push("Add more characters for better SEO");
        } else {
            improvements.push("Consider shortening to avoid truncation");
        }
        
        // Sentiment analysis
        if (sentimentScore > 70) {
            strengths.push("Positive emotional appeal");
        } else if (sentimentScore < 30) {
            improvements.push("Consider making the tone more positive");
        }
        
        // Readability analysis
        if (readabilityScore > 70) {
            strengths.push("Easy to read and understand");
        } else if (readabilityScore < 50) {
            improvements.push("Simplify language for better readability");
        }
        
        // Check for power words
        const powerWords = ['free', 'new', 'proven', 'secret', 'surprising', 'you', 'your'];
        const hasPowerWord = powerWords.some(word => headline.toLowerCase().includes(word));
        
        if (hasPowerWord) {
            strengths.push("Includes attention-grabbing power words");
        } else {
            improvements.push("Add power words to increase click-through rate");
        }
        
        // Check for numbers
        const hasNumber = /\d/.test(headline);
        
        if (hasNumber) {
            strengths.push("Numbers add specificity and credibility");
        } else {
            improvements.push("Consider adding numbers for better performance");
        }
        
        // Check for questions
        const isQuestion = headline.includes('?');
        
        if (isQuestion) {
            strengths.push("Question format engages curiosity");
        } else {
            improvements.push("Try a question format to pique interest");
        }
        
        // Populate strengths list
        strengths.forEach(strength => {
            const li = document.createElement('li');
            li.innerHTML = `<span class="strength-icon">✓</span> ${strength}`;
            strengthsList.appendChild(li);
        });
        
        // Populate improvements list
        improvements.forEach(improvement => {
            const li = document.createElement('li');
            li.innerHTML = `<span class="improvement-icon">💡</span> ${improvement}`;
            improvementsList.appendChild(li);
        });
    }

    // Generate optimization suggestions
    function generateSuggestions(headline, overallScore, wordCount, charCount, sentimentScore, readabilityScore) {
        const suggestionsGrid = document.getElementById('suggestions-grid');
        
        // Clear previous content
        suggestionsGrid.innerHTML = '';
        
        const suggestions = [];
        
        // Word count suggestions
        if (wordCount < 6) {
            suggestions.push({
                title: "Add More Context",
                text: "Consider expanding your headline to provide more context and value to readers."
            });
        } else if (wordCount > 12) {
            suggestions.push({
                title: "Simplify Your Headline",
                text: "Try to condense your headline to the most essential elements for better impact."
            });
        }
        
        // Character count suggestions
        if (charCount > 60) {
            suggestions.push({
                title: "Shorten for SEO",
                text: "Search engines may truncate long headlines. Aim for 50-60 characters."
            });
        }
        
        // Sentiment suggestions
        if (sentimentScore < 50) {
            suggestions.push({
                title: "Boost Emotional Appeal",
                text: "Add positive emotional triggers to make your headline more compelling."
            });
        }
        
        // Readability suggestions
        if (readabilityScore < 60) {
            suggestions.push({
                title: "Improve Readability",
                text: "Use simpler words and shorter sentences to make your headline easier to understand."
            });
        }
        
        // Power word suggestions
        const powerWords = ['free', 'new', 'proven', 'secret', 'surprising', 'you', 'your'];
        const hasPowerWord = powerWords.some(word => headline.toLowerCase().includes(word));
        
        if (!hasPowerWord) {
            suggestions.push({
                title: "Add Power Words",
                text: "Incorporate words like 'free', 'new', or 'you' to increase click-through rates."
            });
        }
        
        // Number suggestions
        const hasNumber = /\d/.test(headline);
        
        if (!hasNumber) {
            suggestions.push({
                title: "Include Numbers",
                text: "Headlines with numbers tend to perform better. Consider adding a specific number."
            });
        }
        
        // Question format suggestions
        const isQuestion = headline.includes('?');
        
        if (!isQuestion) {
            suggestions.push({
                title: "Try a Question",
                text: "Question-based headlines can increase curiosity and engagement."
            });
        }
        
        // Populate suggestions grid
        suggestions.forEach(suggestion => {
            const card = document.createElement('div');
            card.className = 'suggestion-card';
            card.innerHTML = `
                <div class="suggestion-title">${suggestion.title}</div>
                <div class="suggestion-text">${suggestion.text}</div>
            `;
            suggestionsGrid.appendChild(card);
        });
    }

    // Generate alternative headlines
    function generateAlternativeHeadlines(originalHeadline) {
        // Show loading for alternatives
        generateAlternativesBtn.disabled = true;
        generateAlternativesBtn.textContent = 'Generating...';
        
        // Simulate API call delay
        setTimeout(() => {
            const alternatives = [
                {
                    text: generateAlternative(originalHeadline, 'question'),
                    score: Math.min(100, calculateOverallScore(originalHeadline) + Math.floor(Math.random() * 10) + 5)
                },
                {
                    text: generateAlternative(originalHeadline, 'number'),
                    score: Math.min(100, calculateOverallScore(originalHeadline) + Math.floor(Math.random() * 10) + 5)
                },
                {
                    text: generateAlternative(originalHeadline, 'powerword'),
                    score: Math.min(100, calculateOverallScore(originalHeadline) + Math.floor(Math.random() * 10) + 5)
                },
                {
                    text: generateAlternative(originalHeadline, 'simplified'),
                    score: Math.min(100, calculateOverallScore(originalHeadline) + Math.floor(Math.random() * 10) + 5)
                }
            ];
            
            updateAlternativeHeadlines(alternatives);
            
            generateAlternativesBtn.disabled = false;
            generateAlternativesBtn.textContent = 'Generate Alternatives';
        }, 1000);
    }

    // Generate a single alternative headline
    function generateAlternative(headline, type) {
        const words = headline.split(' ');
        
        switch(type) {
            case 'question':
                if (headline.includes('?')) {
                    return headline.replace('?', ' - The Ultimate Guide');
                } else {
                    return `Is ${headline.toLowerCase()} The Right Solution For You?`;
                }
            
            case 'number':
                if (/\d/.test(headline)) {
                    return headline;
                } else {
                    const numbers = ['5', '7', '10', '15'];
                    const number = numbers[Math.floor(Math.random() * numbers.length)];
                    return `${number} ${headline}`;
                }
            
            case 'powerword':
                const powerWords = ['Amazing', 'Incredible', 'Proven', 'Secret', 'Ultimate'];
                const powerWord = powerWords[Math.floor(Math.random() * powerWords.length)];
                return `${powerWord} ${headline}`;
            
            case 'simplified':
                if (words.length > 8) {
                    return words.slice(0, 6).join(' ') + '...';
                } else {
                    return headline;
                }
            
            default:
                return headline;
        }
    }

    // Update alternative headlines in UI
    function updateAlternativeHeadlines(alternatives) {
        const comparisonCards = document.getElementById('comparison-cards');
        
        // Clear previous content
        comparisonCards.innerHTML = '';
        
        // Add alternative headlines
        alternatives.forEach(alt => {
            const card = document.createElement('div');
            card.className = 'comparison-card';
            card.innerHTML = `
                <div class="comparison-score">Score: ${alt.score}</div>
                <div class="comparison-text">${alt.text}</div>
            `;
            comparisonCards.appendChild(card);
        });
    }
});
// Add CSS for tools links
const toolsStyles = document.createElement('style');
toolsStyles.textContent = `
    .tools-links-container {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 2px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    
    .tools-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    
    .tools-header h3 {
        color: #1e293b;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: 700;
    }
    
    .tools-header p {
        color: #64748b;
        font-size: 0.9rem;
    }
    
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .tool-link {
        background: white;
        border: 2px solid #f1f5f9;
        border-radius: 12px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        text-decoration: none;
        transition: all 0.3s ease;
        color: inherit;
    }
    
    .tool-link:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
        text-decoration: none;
        color: inherit;
    }
    
    .tool-icon {
        font-size: 2rem;
        flex-shrink: 0;
    }
    
    .tool-content h4 {
        color: #1e293b;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        font-weight: 600;
    }
    
    .tool-content p {
        color: #64748b;
        font-size: 0.8rem;
        margin: 0;
        line-height: 1.4;
    }
`;
document.head.appendChild(toolsStyles);