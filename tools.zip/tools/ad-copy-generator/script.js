/**
 * AD COPY GENERATOR
 * Professional Ad Copy Creation Tool
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Ad Copy Generator Initialized');

    // DOM Elements
    const generateBtn = document.getElementById('generate-btn');
    const regenerateBtn = document.getElementById('regenerate-btn');
    const copyAllBtn = document.getElementById('copy-all-btn');
    const saveBtn = document.getElementById('save-btn');
    const resultsPlaceholder = document.getElementById('results-placeholder');
    const resultsContent = document.getElementById('results-content');
    const loadingIndicator = document.getElementById('loading-indicator');

    // Form Elements
    const productNameInput = document.getElementById('product-name');
    const productDescInput = document.getElementById('product-description');
    const platformSelect = document.getElementById('platform');
    const adFormatSelect = document.getElementById('ad-format');
    const toneSelect = document.getElementById('tone');
    const targetAudienceSelect = document.getElementById('target-audience');
    const keywordsInput = document.getElementById('keywords');
    const ctaSelect = document.getElementById('cta');

    // Result Elements
    const platformBadge = document.getElementById('platform-badge');
    const adTitle = document.getElementById('ad-title');
    const adUrl = document.getElementById('ad-url');
    const adDescription = document.getElementById('ad-description');
    const copyVariations = document.getElementById('copy-variations');
    const hashtagsContainer = document.getElementById('hashtags');

    // Create tools links container
    const toolsContainer = document.createElement('div');
    toolsContainer.className = 'tools-links-container';
    toolsContainer.innerHTML = `
        <div class="tools-header">
            <h3>More Marketing Tools</h3>
            <p>Explore our suite of professional marketing tools</p>
        </div>
        <div class="tools-grid">
            <a href="../social-media-generator/index.html" class="tool-link" data-tool="social-media">
                <div class="tool-icon">📱</div>
                <div class="tool-content">
                    <h4>Social Media Generator</h4>
                    <p>Create engaging social media posts and captions</p>
                </div>
            </a>
            
            <a href="../headline-Analyzer/index.html" class="tool-link" data-tool="headline-analyzer">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Headline Analyzer</h4>
                    <p>Analyze and improve your headline effectiveness</p>
                </div>
            </a>
            
            <a href="../seo-meta-generator/index.html" class="tool-link" data-tool="seo-meta">
                <div class="tool-icon">🔍</div>
                <div class="tool-content">
                    <h4>SEO Meta Generator</h4>
                    <p>Generate optimized meta tags and descriptions</p>
                </div>
            </a>
            
            <a href="../email-subject-tester/index.html" class="tool-link" data-tool="email-tester">
                <div class="tool-icon">✉️</div>
                <div class="tool-content">
                    <h4>Email Subject Line Tester</h4>
                    <p>Test and optimize email subject lines</p>
                </div>
            </a>
            
            <a href="../Ad-Copy-Generator/index.html" class="tool-link" data-tool="ad-copy">
                <div class="tool-icon">🎯</div>
                <div class="tool-content">
                    <h4>Ad Copy Generator</h4>
                    <p>Create high-converting advertising copy</p>
                </div>
            </a>
        </div>
    `;

    // Insert tools container after the main content
    const mainContainer = document.querySelector('.container') || document.querySelector('main');
    if (mainContainer) {
        mainContainer.appendChild(toolsContainer);
    }

    // Platform configurations
    const platformConfigs = {
        google: {
            maxTitleLength: 30,
            maxDescLength: 90,
            urlRequired: true
        },
        facebook: {
            maxTitleLength: 40,
            maxDescLength: 125,
            urlRequired: true
        },
        instagram: {
            maxTitleLength: 150,
            maxDescLength: 125,
            urlRequired: false
        },
        twitter: {
            maxTitleLength: 280,
            maxDescLength: 280,
            urlRequired: false
        },
        linkedin: {
            maxTitleLength: 150,
            maxDescLength: 600,
            urlRequired: true
        },
        tiktok: {
            maxTitleLength: 100,
            maxDescLength: 150,
            urlRequired: false
        }
    };

    // Professional CTA options
    const ctaOptions = {
        'buy-now': ['Purchase Now', 'Acquire Today', 'Secure Your Order'],
        'learn-more': ['Learn More', 'Discover Details', 'Explore Features'],
        'sign-up': ['Register Now', 'Create Account', 'Join Today'],
        'get-started': ['Get Started', 'Begin Journey', 'Start Today'],
        'shop-now': ['Shop Now', 'Browse Collection', 'View Products'],
        'download': ['Download Now', 'Get Application', 'Install Software']
    };

    // Professional tone templates
    const toneTemplates = {
        professional: {
            adjectives: ['enterprise-grade', 'premium', 'advanced', 'sophisticated', 'comprehensive'],
            phrases: ['Maximize efficiency', 'Enterprise-ready solution', 'Professional-grade performance'],
            powerWords: ['Optimize', 'Streamline', 'Enhance', 'Transform', 'Accelerate']
        },
        casual: {
            adjectives: ['intuitive', 'streamlined', 'user-friendly', 'efficient', 'reliable'],
            phrases: ['Experience the difference', 'Discover new possibilities', 'Simplify your workflow'],
            powerWords: ['Discover', 'Experience', 'Simplify', 'Elevate', 'Transform']
        },
        urgent: {
            adjectives: ['limited-time', 'exclusive', 'time-sensitive', 'priority', 'immediate'],
            phrases: ['Limited availability', 'Exclusive opportunity', 'Time-sensitive offer'],
            powerWords: ['Act', 'Secure', 'Reserve', 'Access', 'Claim']
        },
        authoritative: {
            adjectives: ['industry-leading', 'expert', 'premier', 'definitive', 'comprehensive'],
            phrases: ['Industry-best performance', 'Expert-crafted solution', 'Premier quality standards'],
            powerWords: ['Lead', 'Dominate', 'Excel', 'Master', 'Achieve']
        },
        inspirational: {
            adjectives: ['transformative', 'empowering', 'visionary', 'innovative', 'progressive'],
            phrases: ['Unlock potential', 'Achieve excellence', 'Drive innovation'],
            powerWords: ['Inspire', 'Empower', 'Transform', 'Elevate', 'Achieve']
        }
    };

    // Event Listeners
    generateBtn.addEventListener('click', generateAdCopy);
    regenerateBtn.addEventListener('click', generateAdCopy);
    copyAllBtn.addEventListener('click', copyAllToClipboard);
    saveBtn.addEventListener('click', saveAdCopy);

    // Generate ad copy function
    function generateAdCopy() {
        const productName = productNameInput.value.trim();
        const productDescription = productDescInput.value.trim();

        if (!productName) {
            alert('Please enter a product or service name');
            return;
        }

        if (!productDescription) {
            alert('Please describe your product or service');
            return;
        }

        setLoadingState(true);

        // Simulate processing delay
        setTimeout(() => {
            try {
                const adCopy = createAdCopy();
                displayResults(adCopy);
                setLoadingState(false);
            } catch (error) {
                console.error('Error generating ad copy:', error);
                alert('Error generating ad copy. Please try again.');
                setLoadingState(false);
            }
        }, 1500);
    }

    // Create ad copy based on form inputs
    function createAdCopy() {
        const platform = platformSelect.value;
        const tone = toneSelect.value;
        const targetAudience = targetAudienceSelect.value;
        const adFormat = adFormatSelect.value;
        const cta = ctaSelect.value;
        const keywords = keywordsInput.value.split(',').map(k => k.trim()).filter(k => k);
        
        const config = platformConfigs[platform];
        const toneTemplate = toneTemplates[tone];
        const ctaPhrases = ctaOptions[cta];

        // Generate multiple ad variations
        const variations = [];
        for (let i = 0; i < 3; i++) {
            variations.push(generateVariation(i, platform, toneTemplate, ctaPhrases, keywords, config));
        }

        // Generate hashtags
        const generatedHashtags = generateHashtags(productNameInput.value, keywords);

        return {
            platform: platform,
            platformName: getPlatformName(platform),
            title: generateTitle(productNameInput.value, toneTemplate, config),
            description: generateDescription(productDescInput.value, toneTemplate, ctaPhrases, config),
            variations: variations,
            hashtags: generatedHashtags,
            url: generateUrl(productNameInput.value)
        };
    }

    // Generate professional title
    function generateTitle(productName, toneTemplate, config) {
        const adjectives = toneTemplate.adjectives;
        const phrases = toneTemplate.phrases;
        const powerWords = toneTemplate.powerWords;
        
        const templates = [
            `${productName}: ${getRandomItem(phrases)}`,
            `${getRandomItem(adjectives)} ${productName} Solution`,
            `${getRandomItem(powerWords)} Your Results with ${productName}`,
            `${productName} - ${getRandomItem(adjectives)} Performance`,
            `Achieve ${getRandomItem(powerWords)} with ${productName}`
        ];

        let title = getRandomItem(templates);
        
        // Ensure title length is within limits
        if (title.length > config.maxTitleLength) {
            title = title.substring(0, config.maxTitleLength - 3) + '...';
        }
        
        return title;
    }

    // Generate professional description
    function generateDescription(productDesc, toneTemplate, ctaPhrases, config) {
        const adjectives = toneTemplate.adjectives;
        const phrases = toneTemplate.phrases;
        const powerWords = toneTemplate.powerWords;
        const cta = getRandomItem(ctaPhrases);
        
        const templates = [
            `${productDesc}. ${getRandomItem(phrases)}. ${cta} to ${getRandomItem(powerWords).toLowerCase()} your outcomes.`,
            `Discover our ${getRandomItem(adjectives)} solution designed for optimal performance. ${productDesc}. ${cta} for superior results.`,
            `${getRandomItem(phrases)} with our comprehensive ${productNameInput.value} platform. ${productDesc}. ${cta} to begin your transformation.`,
            `Experience ${getRandomItem(adjectives)} quality with ${productNameInput.value}. ${productDesc}. ${cta} to access premium features.`
        ];

        let description = getRandomItem(templates);
        
        // Ensure description length is within limits
        if (description.length > config.maxDescLength) {
            description = description.substring(0, config.maxDescLength - 3) + '...';
        }
        
        return description;
    }

    // Generate professional variation
    function generateVariation(index, platform, toneTemplate, ctaPhrases, keywords, config) {
        const productName = productNameInput.value;
        const adjectives = toneTemplate.adjectives;
        const powerWords = toneTemplate.powerWords;
        const cta = getRandomItem(ctaPhrases);
        
        const variationTemplates = [
            // Variation 1: Feature-focused
            `${getRandomItem(powerWords)} your performance with ${productName}.\n\n` +
            `Key features include:\n` +
            `• ${keywords[0] || 'Advanced functionality'}\n` +
            `• ${keywords[1] || 'Premium quality'}\n` +
            `• ${keywords[2] || 'Reliable performance'}\n\n` +
            `${cta} to experience the difference.`,

            // Variation 2: Benefit-oriented
            `Transform your workflow with our ${getRandomItem(adjectives)} ${productName} solution.\n\n` +
            `Designed specifically for ${targetAudienceSelect.options[targetAudienceSelect.selectedIndex].text.toLowerCase()}, ` +
            `this platform delivers measurable results and exceptional value.\n\n` +
            `${cta} to unlock your potential.`,

            // Variation 3: Problem-solution
            `Addressing critical challenges for modern professionals.\n\n` +
            `${productName} provides the ${getRandomItem(adjectives)} solution you need to ` +
            `${getRandomItem(powerWords).toLowerCase()} outcomes and drive success.\n\n` +
            `${cta} to implement this strategic advantage.`
        ];

        return variationTemplates[index] || variationTemplates[0];
    }

    // Generate professional hashtags
    function generateHashtags(productName, keywords) {
        const baseHashtags = [
            productName.replace(/\s+/g, ''),
            'Business',
            'Solution',
            'Professional'
        ];
        
        const keywordHashtags = keywords.slice(0, 3).map(k => k.replace(/\s+/g, ''));
        const platformHashtags = [getPlatformName(platformSelect.value).replace(/\s+/g, '')];
        const industryTags = ['Innovation', 'Technology', 'Growth', 'Success'];
        
        return [...new Set([...baseHashtags, ...keywordHashtags, ...platformHashtags, ...industryTags])]
            .map(tag => '#' + tag.replace(/[^a-zA-Z0-9]/g, ''))
            .slice(0, 8);
    }

    // Generate professional URL
    function generateUrl(productName) {
        const baseUrl = 'www.' + productName.toLowerCase().replace(/\s+/g, '') + '.com';
        return baseUrl.replace(/[^a-zA-Z0-9.-]/g, '');
    }

    // Get platform display name
    function getPlatformName(platform) {
        const names = {
            google: 'Google Ads',
            facebook: 'Facebook',
            instagram: 'Instagram',
            twitter: 'Twitter/X',
            linkedin: 'LinkedIn',
            tiktok: 'TikTok'
        };
        return names[platform] || platform;
    }

    // Get random item from array
    function getRandomItem(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    // Display results
    function displayResults(adCopy) {
        // Update platform badge
        platformBadge.textContent = adCopy.platformName;
        
        // Update ad preview
        adTitle.textContent = adCopy.title;
        adUrl.textContent = adCopy.url;
        adDescription.textContent = adCopy.description;
        
        // Update variations
        copyVariations.innerHTML = '';
        adCopy.variations.forEach((variation, index) => {
            const variationElement = document.createElement('div');
            variationElement.className = 'copy-variation';
            variationElement.innerHTML = `
                <div class="variation-header">
                    <span class="variation-number">Variation ${index + 1}</span>
                </div>
                <div class="variation-content">${variation.replace(/\n/g, '<br>')}</div>
            `;
            variationElement.addEventListener('click', () => copyToClipboard(variation));
            copyVariations.appendChild(variationElement);
        });
        
        // Update hashtags
        hashtagsContainer.innerHTML = '';
        adCopy.hashtags.forEach(hashtag => {
            const hashtagElement = document.createElement('div');
            hashtagElement.className = 'hashtag';
            hashtagElement.textContent = hashtag;
            hashtagElement.addEventListener('click', () => copyToClipboard(hashtag));
            hashtagsContainer.appendChild(hashtagElement);
        });
        
        // Show results
        resultsPlaceholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');
    }

    // Set loading state
    function setLoadingState(isLoading) {
        if (isLoading) {
            generateBtn.disabled = true;
            resultsPlaceholder.classList.add('hidden');
            resultsContent.classList.add('hidden');
            loadingIndicator.classList.remove('hidden');
            
            const btnText = generateBtn.querySelector('.btn-text');
            const btnLoading = generateBtn.querySelector('.btn-loading');
            if (btnText && btnLoading) {
                btnText.classList.add('hidden');
                btnLoading.classList.remove('hidden');
            }
        } else {
            generateBtn.disabled = false;
            loadingIndicator.classList.add('hidden');
            
            const btnText = generateBtn.querySelector('.btn-text');
            const btnLoading = generateBtn.querySelector('.btn-loading');
            if (btnText && btnLoading) {
                btnText.classList.remove('hidden');
                btnLoading.classList.add('hidden');
            }
        }
    }

    // Copy text to clipboard
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copied to clipboard!');
        }).catch(err => {
            console.error('Failed to copy: ', err);
            showNotification('Failed to copy to clipboard');
        });
    }

    // Copy all ad copy to clipboard
    function copyAllToClipboard() {
        const allText = [
            `Ad Title: ${adTitle.textContent}`,
            `Description: ${adDescription.textContent}`,
            `URL: ${adUrl.textContent}`,
            '',
            'Ad Variations:',
            ...Array.from(copyVariations.children).map(el => el.textContent),
            '',
            'Hashtags:',
            Array.from(hashtagsContainer.children).map(el => el.textContent).join(' ')
        ].join('\n');

        copyToClipboard(allText);
    }

    // Save ad copy (simulated)
    function saveAdCopy() {
        showNotification('Ad copy saved successfully');
    }

    // Show notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #10b981;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            z-index: 1000;
            font-weight: 600;
            font-size: 0.9rem;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }

    // Initialize with professional example data
    function initializeDemo() {
        productNameInput.value = 'Enterprise Analytics Suite';
        productDescInput.value = 'Comprehensive business intelligence platform with real-time analytics, predictive insights, and customizable dashboards for data-driven decision making.';
        keywordsInput.value = 'real-time analytics, predictive insights, customizable dashboards, data visualization, business intelligence';
    }

    // Initialize the demo
    initializeDemo();
});

// Add CSS for tools links
const toolsStyles = document.createElement('style');
toolsStyles.textContent = `
    .tools-links-container {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 2px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    
    .tools-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    
    .tools-header h3 {
        color: #1e293b;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: 700;
    }
    
    .tools-header p {
        color: #64748b;
        font-size: 0.9rem;
    }
    
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .tool-link {
        background: white;
        border: 2px solid #f1f5f9;
        border-radius: 12px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        text-decoration: none;
        transition: all 0.3s ease;
        color: inherit;
    }
    
    .tool-link:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
        text-decoration: none;
        color: inherit;
    }
    
    .tool-icon {
        font-size: 2rem;
        flex-shrink: 0;
    }
    
    .tool-content h4 {
        color: #1e293b;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        font-weight: 600;
    }
    
    .tool-content p {
        color: #64748b;
        font-size: 0.8rem;
        margin: 0;
        line-height: 1.4;
    }
`;
document.head.appendChild(toolsStyles);