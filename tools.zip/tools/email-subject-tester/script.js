document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const testBtn = document.getElementById('test-btn');
    const regenerateBtn = document.getElementById('regenerate-btn');
    const copyAllBtn = document.getElementById('copy-all-btn');
    const saveBtn = document.getElementById('save-btn');
    const subjectLineInput = document.getElementById('subject-line');
    const charCount = document.querySelector('.char-count');
    const wordCount = document.querySelector('.word-count');
    const resultsPlaceholder = document.getElementById('results-placeholder');
    const resultsContent = document.getElementById('results-content');
    const loadingIndicator = document.getElementById('loading-indicator');

    // Result Elements
    const scoreCircle = document.getElementById('score-circle');
    const scoreValue = document.getElementById('score-value');
    const scoreDescription = document.getElementById('score-description');
    const openRate = document.getElementById('open-rate');
    const spamScore = document.getElementById('spam-score');
    const clickRate = document.getElementById('click-rate');
    const mobileScore = document.getElementById('mobile-score');
    const strengthsList = document.getElementById('strengths-list');
    const improvementsList = document.getElementById('improvements-list');
    const spamStatus = document.getElementById('spam-status');
    const spamTriggers = document.getElementById('spam-triggers');
    const previewSender = document.getElementById('preview-sender');
    const previewSubject = document.getElementById('preview-subject');
    const suggestionsGrid = document.getElementById('suggestions-grid');

    // Create tools links container
    const toolsContainer = document.createElement('div');
    toolsContainer.className = 'tools-links-container';
    toolsContainer.innerHTML = `
        <div class="tools-header">
            <h3>🚀 More Content Tools</h3>
            <p>Enhance your content creation workflow</p>
        </div>
        <div class="tools-grid">
            <a href="../social-media-generator/index.html" class="tool-link" data-tool="social-media">
                <div class="tool-icon">📱</div>
                <div class="tool-content">
                    <h4>AI Social Media Generator</h4>
                    <p>Create engaging social media posts and captions</p>
                </div>
            </a>
            
            <a href="../headline-Analyzer/index.html" class="tool-link" data-tool="ai-writer">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Headline Analyzer</h4>
                    <p>Generate full articles and blog posts</p>
                </div>
            </a>
            
            <a href="../seo-meta-generator/index.html" class="tool-link" data-tool="seo-analyzer">
                <div class="tool-icon">🔍</div>
                <div class="tool-content">
                    <h4>SEO Meta Generator</h4>
                    <p>Optimize content for search engines</p>
                </div>
            </a>
            
             <a href="../value-proposition/index.html" class="tool-link" data-tool="video-generator">
                <div class="tool-icon">✉️</div>
                <div class="tool-content">
                    <h4>Value Proposition</h4>
                    <p>analyze and scores subject effectiveness.</p>
                </div>
            </a>
            
            
            <a href="../Ad-Copy-Generator/index.html" class="tool-link" data-tool="content-planner">
                <div class="tool-icon">📊</div>
                <div class="tool-content">
                    <h4>Ad Copy Generator</h4>
                    <p>create engaging, high-converting advertisements automatically.</p>
                </div>
            </a>
        </div>
    `;

    // Insert tools container after the main content
    const mainContainer = document.querySelector('.container') || document.querySelector('main');
    if (mainContainer) {
        mainContainer.appendChild(toolsContainer);
    }

    // Configuration
    const spamWords = [
        'free', 'guarantee', 'winner', 'prize', 'cash', 'money', 'income',
        'earn', 'extra', 'home based', 'work from home', 'make money',
        'million', 'billion', 'risk free', 'special promotion', 'click here',
        'subscribe', 'order now', 'buy now', 'discount', 'deal', 'offer',
        'limited time', 'act now', 'urgent', 'important', 'alert', 'warning',
        'congratulations', 'help', 'reminder', 'sale', 'clearance', 'bargain'
    ];

    const powerWords = [
        'you', 'your', 'discover', 'secret', 'proven', 'instant', 'easy',
        'simple', 'quick', 'fast', 'amazing', 'incredible', 'unbelievable',
        'exclusive', 'limited', 'new', 'improved', 'advanced', 'premium',
        'ultimate', 'complete', 'comprehensive', 'essential', 'must-have'
    ];

    const industryBenchmarks = {
        ecommerce: { openRate: 18.0, clickRate: 2.6 },
        saas: { openRate: 22.1, clickRate: 3.2 },
        education: { openRate: 20.5, clickRate: 2.8 },
        health: { openRate: 23.4, clickRate: 3.1 },
        finance: { openRate: 21.8, clickRate: 2.9 },
        entertainment: { openRate: 25.2, clickRate: 3.5 }
    };

    // Event Listeners
    testBtn.addEventListener('click', testSubjectLine);
    regenerateBtn.addEventListener('click', generateSuggestions);
    copyAllBtn.addEventListener('click', copyBestSuggestion);
    saveBtn.addEventListener('click', saveAnalysis);

    subjectLineInput.addEventListener('input', updateCharacterCount);
    subjectLineInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            testSubjectLine();
        }
    });

    // Update character and word count
    function updateCharacterCount() {
        const text = subjectLineInput.value;
        const characters = text.length;
        const words = text.trim() ? text.trim().split(/\s+/).length : 0;

        charCount.textContent = `${characters}/100 characters`;
        wordCount.textContent = `${words} words`;

        // Update character count color based on length
        charCount.className = 'char-count';
        if (characters > 60) {
            charCount.classList.add('danger');
        } else if (characters > 50) {
            charCount.classList.add('warning');
        }
    }

    // Test subject line function
    function testSubjectLine() {
        const subjectLine = subjectLineInput.value.trim();

        if (!subjectLine) {
            alert('Please enter a subject line to test');
            return;
        }

        setLoadingState(true);

        // Simulate API call delay
        setTimeout(() => {
            try {
                const analysis = analyzeSubjectLine(subjectLine);
                displayResults(analysis);
                setLoadingState(false);
            } catch (error) {
                console.error('Error analyzing subject line:', error);
                alert('Error analyzing subject line. Please try again.');
                setLoadingState(false);
            }
        }, 1500);
    }

    // Analyze subject line
    function analyzeSubjectLine(subjectLine) {
        const emailType = document.getElementById('email-type').value;
        const audience = document.getElementById('audience').value;
        const industry = document.getElementById('industry').value;
        const senderName = document.getElementById('sender-name').value || 'Your Company';

        // Basic metrics
        const charCount = subjectLine.length;
        const wordCount = subjectLine.split(/\s+/).length;
        const hasPersonalization = subjectLine.includes('{name}') || subjectLine.includes('{firstName}');
        const hasEmoji = /[\u{1F300}-\u{1F9FF}]/gu.test(subjectLine);
        const hasNumbers = /\d/.test(subjectLine);

        // Spam analysis
        const spamAnalysis = analyzeSpamWords(subjectLine);
        
        // Score calculation
        const overallScore = calculateOverallScore(subjectLine, charCount, wordCount, hasPersonalization, spamAnalysis);
        
        // Predicted metrics
        const predictedMetrics = calculatePredictedMetrics(overallScore, industry, emailType);
        
        // Generate suggestions
        const suggestions = generateSuggestionsFromAnalysis(subjectLine, overallScore, spamAnalysis);

        return {
            subjectLine: subjectLine,
            senderName: senderName,
            charCount: charCount,
            wordCount: wordCount,
            hasPersonalization: hasPersonalization,
            hasEmoji: hasEmoji,
            hasNumbers: hasNumbers,
            overallScore: overallScore,
            spamAnalysis: spamAnalysis,
            predictedMetrics: predictedMetrics,
            suggestions: suggestions,
            strengths: generateStrengths(hasPersonalization, hasEmoji, hasNumbers, charCount, spamAnalysis),
            improvements: generateImprovements(hasPersonalization, hasEmoji, hasNumbers, charCount, spamAnalysis)
        };
    }

    // Analyze spam words
    function analyzeSpamWords(subjectLine) {
        const lowerSubject = subjectLine.toLowerCase();
        const foundSpamWords = spamWords.filter(word => lowerSubject.includes(word.toLowerCase()));
        const spamWordCount = foundSpamWords.length;
        
        let spamRisk = 'low';
        if (spamWordCount >= 3) spamRisk = 'high';
        else if (spamWordCount >= 1) spamRisk = 'medium';

        return {
            foundWords: foundSpamWords,
            count: spamWordCount,
            risk: spamRisk
        };
    }

    // Calculate overall score
    function calculateOverallScore(subjectLine, charCount, wordCount, hasPersonalization, spamAnalysis) {
        let score = 0;

        // Length scoring (optimal: 28-39 characters)
        if (charCount >= 28 && charCount <= 39) {
            score += 30;
        } else if (charCount >= 20 && charCount <= 50) {
            score += 20;
        } else if (charCount >= 15 && charCount <= 60) {
            score += 10;
        } else {
            score += 5;
        }

        // Word count scoring (optimal: 3-7 words)
        if (wordCount >= 3 && wordCount <= 7) {
            score += 20;
        } else if (wordCount >= 2 && wordCount <= 10) {
            score += 15;
        } else {
            score += 5;
        }

        // Personalization bonus
        if (hasPersonalization) {
            score += 15;
        }

        // Spam word penalty
        if (spamAnalysis.risk === 'high') {
            score -= 30;
        } else if (spamAnalysis.risk === 'medium') {
            score -= 15;
        }

        // Power words bonus
        const powerWordCount = powerWords.filter(word => 
            subjectLine.toLowerCase().includes(word.toLowerCase())
        ).length;
        score += Math.min(powerWordCount * 5, 15);

        // Emoji consideration
        const hasEmoji = /[\u{1F300}-\u{1F9FF}]/gu.test(subjectLine);
        if (hasEmoji && charCount <= 35) {
            score += 5;
        }

        return Math.max(0, Math.min(100, score));
    }

    // Calculate predicted metrics
    function calculatePredictedMetrics(score, industry, emailType) {
        const benchmark = industryBenchmarks[industry] || industryBenchmarks.ecommerce;
        const baseOpenRate = benchmark.openRate;
        const baseClickRate = benchmark.clickRate;

        // Adjust based on score
        const scoreMultiplier = score / 100;
        const predictedOpenRate = baseOpenRate * (0.7 + (scoreMultiplier * 0.6));
        const predictedClickRate = baseClickRate * (0.6 + (scoreMultiplier * 0.8));

        // Spam score (inverse of open rate potential)
        const spamRisk = Math.max(0, 100 - (predictedOpenRate * 3));

        // Mobile optimization (based on length and simplicity)
        const mobileScore = Math.max(0, 100 - (Math.abs(35 - subjectLineInput.value.length) * 2));

        return {
            openRate: Math.min(40, Math.round(predictedOpenRate * 10) / 10),
            clickRate: Math.min(8, Math.round(predictedClickRate * 10) / 10),
            spamScore: Math.round(spamRisk),
            mobileScore: Math.min(100, Math.round(mobileScore))
        };
    }

    // Generate strengths
    function generateStrengths(hasPersonalization, hasEmoji, hasNumbers, charCount, spamAnalysis) {
        const strengths = [];

        if (charCount >= 28 && charCount <= 39) {
            strengths.push("Optimal length for email clients");
        }

        if (hasPersonalization) {
            strengths.push("Personalization increases engagement");
        }

        if (spamAnalysis.risk === 'low') {
            strengths.push("Low spam risk - good deliverability");
        }

        if (hasNumbers) {
            strengths.push("Numbers can increase open rates");
        }

        if (charCount <= 50) {
            strengths.push("Good length for mobile devices");
        }

        if (hasEmoji && charCount <= 35) {
            strengths.push("Strategic emoji use can stand out");
        }

        return strengths.length > 0 ? strengths : ["Good starting point - consider the suggestions below"];
    }

    // Generate improvements
    function generateImprovements(hasPersonalization, hasEmoji, hasNumbers, charCount, spamAnalysis) {
        const improvements = [];

        if (charCount > 60) {
            improvements.push("Consider shortening for mobile preview");
        } else if (charCount < 20) {
            improvements.push("Add more context to increase relevance");
        }

        if (!hasPersonalization) {
            improvements.push("Add personalization (e.g., {name})");
        }

        if (spamAnalysis.risk === 'high') {
            improvements.push("Remove spam trigger words");
        } else if (spamAnalysis.risk === 'medium') {
            improvements.push("Consider reducing spam trigger words");
        }

        if (hasEmoji && charCount > 35) {
            improvements.push("Consider removing emojis if length is an issue");
        } else if (!hasEmoji && charCount <= 35) {
            improvements.push("Test adding a relevant emoji to stand out");
        }

        if (!hasNumbers) {
            improvements.push("Consider adding numbers for specificity");
        }

        return improvements.length > 0 ? improvements : ["Subject line looks good! Test different variations"];
    }

    // Generate suggestions from analysis
    function generateSuggestionsFromAnalysis(originalSubject, score, spamAnalysis) {
        const suggestions = [];
        const baseSubject = originalSubject;

        // Suggestion 1: Personalization added
        if (!baseSubject.includes('{name}')) {
            suggestions.push({
                text: baseSubject.replace(/^/, "{name}, "),
                score: Math.min(100, score + 15),
                type: "personalized"
            });
        }

        // Suggestion 2: Shortened version
        if (baseSubject.length > 40) {
            const shortened = baseSubject.substring(0, 37) + "...";
            suggestions.push({
                text: shortened,
                score: Math.min(100, score + 10),
                type: "shortened"
            });
        }

        // Suggestion 3: Question format
        if (!baseSubject.includes('?')) {
            suggestions.push({
                text: baseSubject.replace(/\.$/, '?'),
                score: Math.min(100, score + 8),
                type: "question"
            });
        }

        // Suggestion 4: Urgency/benefit focused
        const words = baseSubject.split(' ');
        if (words.length > 3) {
            const focused = `Don't miss: ${words.slice(0, 3).join(' ')}...`;
            suggestions.push({
                text: focused,
                score: Math.min(100, score + 12),
                type: "urgent"
            });
        }

        // Suggestion 5: Clean version (remove spam words)
        if (spamAnalysis.foundWords.length > 0) {
            let cleanSubject = baseSubject;
            spamAnalysis.foundWords.forEach(word => {
                const regex = new RegExp(word, 'gi');
                cleanSubject = cleanSubject.replace(regex, '');
            });
            cleanSubject = cleanSubject.replace(/\s+/g, ' ').trim();
            if (cleanSubject.length > 10) {
                suggestions.push({
                    text: cleanSubject,
                    score: Math.min(100, score + 20),
                    type: "clean"
                });
            }
        }

        return suggestions.slice(0, 4); // Return top 4 suggestions
    }

    // Display results
    function displayResults(analysis) {
        // Update score
        scoreValue.textContent = analysis.overallScore;
        scoreCircle.style.background = `conic-gradient(var(--primary) ${analysis.overallScore}%, #e9ecef ${analysis.overallScore}%)`;
        
        // Update score description
        if (analysis.overallScore >= 80) {
            scoreDescription.textContent = "Excellent! This should perform very well.";
        } else if (analysis.overallScore >= 60) {
            scoreDescription.textContent = "Good! With some tweaks, it could be even better.";
        } else if (analysis.overallScore >= 40) {
            scoreDescription.textContent = "Average. Consider the suggestions below to improve.";
        } else {
            scoreDescription.textContent = "Needs improvement. Check the suggestions below.";
        }

        // Update metrics
        openRate.textContent = `${analysis.predictedMetrics.openRate}%`;
        openRate.className = `metric-value ${getMetricClass(analysis.predictedMetrics.openRate, 15, 25)}`;
        
        spamScore.textContent = `${analysis.predictedMetrics.spamScore}%`;
        spamScore.className = `metric-value ${getMetricClass(100 - analysis.predictedMetrics.spamScore, 70, 85)}`;
        
        clickRate.textContent = `${analysis.predictedMetrics.clickRate}%`;
        clickRate.className = `metric-value ${getMetricClass(analysis.predictedMetrics.clickRate, 2, 4)}`;
        
        mobileScore.textContent = `${analysis.predictedMetrics.mobileScore}%`;
        mobileScore.className = `metric-value ${getMetricClass(analysis.predictedMetrics.mobileScore, 70, 85)}`;

        // Update strengths and improvements
        updateList(strengthsList, analysis.strengths, 'strength');
        updateList(improvementsList, analysis.improvements, 'improvement');

        // Update spam check
        updateSpamCheck(analysis.spamAnalysis);

        // Update preview
        previewSender.textContent = analysis.senderName;
        previewSubject.textContent = analysis.subjectLine;

        // Update suggestions
        updateSuggestions(analysis.suggestions);

        // Show results
        resultsPlaceholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');
    }

    // Get metric class for styling
    function getMetricClass(value, goodThreshold, excellentThreshold) {
        if (value >= excellentThreshold) return 'good';
        if (value >= goodThreshold) return 'warning';
        return 'danger';
    }

    // Update list elements
    function updateList(listElement, items, type) {
        listElement.innerHTML = '';
        items.forEach(item => {
            const li = document.createElement('li');
            const icon = type === 'strength' ? '✓' : '💡';
            li.innerHTML = `<span class="${type}-icon">${icon}</span> ${item}`;
            listElement.appendChild(li);
        });
    }

    // Update spam check display
    function updateSpamCheck(spamAnalysis) {
        // Update status
        spamStatus.className = `spam-status ${spamAnalysis.risk}`;
        const statusIcon = spamAnalysis.risk === 'high' ? '🚫' : 
                          spamAnalysis.risk === 'medium' ? '⚠️' : '✅';
        const statusText = spamAnalysis.risk === 'high' ? 'High spam risk detected' :
                          spamAnalysis.risk === 'medium' ? 'Medium spam risk' :
                          'No spam triggers detected';
        
        spamStatus.innerHTML = `<span class="status-icon">${statusIcon}</span> <span class="status-text">${statusText}</span>`;

        // Update triggers
        spamTriggers.innerHTML = '';
        if (spamAnalysis.foundWords.length > 0) {
            spamAnalysis.foundWords.forEach(word => {
                const trigger = document.createElement('div');
                trigger.className = 'spam-trigger';
                trigger.textContent = word;
                spamTriggers.appendChild(trigger);
            });
        }
    }

    // Update suggestions
    function updateSuggestions(suggestions) {
        suggestionsGrid.innerHTML = '';
        suggestions.forEach(suggestion => {
            const card = document.createElement('div');
            card.className = 'suggestion-card';
            card.innerHTML = `
                <div class="suggestion-score">Score: ${suggestion.score}</div>
                <div class="suggestion-text">${suggestion.text}</div>
            `;
            card.addEventListener('click', () => {
                subjectLineInput.value = suggestion.text;
                updateCharacterCount();
                testSubjectLine();
            });
            suggestionsGrid.appendChild(card);
        });
    }

    // Generate new suggestions
    function generateSuggestions() {
        const currentSubject = subjectLineInput.value.trim();
        if (!currentSubject) {
            alert('Please test a subject line first');
            return;
        }

        const analysis = analyzeSubjectLine(currentSubject);
        updateSuggestions(analysis.suggestions);
        showNotification('New suggestions generated!');
    }

    // Copy best suggestion
    function copyBestSuggestion() {
        const bestSuggestion = document.querySelector('.suggestion-card');
        if (!bestSuggestion) {
            alert('No suggestions available to copy');
            return;
        }

        const suggestionText = bestSuggestion.querySelector('.suggestion-text').textContent;
        navigator.clipboard.writeText(suggestionText).then(() => {
            showNotification('Best suggestion copied to clipboard!');
        });
    }

    // Save analysis (simulated)
    function saveAnalysis() {
        showNotification('Analysis saved! (This is a demo)');
    }

    // Set loading state
    function setLoadingState(isLoading) {
        if (isLoading) {
            testBtn.disabled = true;
            resultsPlaceholder.classList.add('hidden');
            resultsContent.classList.add('hidden');
            loadingIndicator.classList.remove('hidden');
            
            const btnText = testBtn.querySelector('.btn-text');
            const btnLoading = testBtn.querySelector('.btn-loading');
            btnText.classList.add('hidden');
            btnLoading.classList.remove('hidden');
        } else {
            testBtn.disabled = false;
            loadingIndicator.classList.add('hidden');
            
            const btnText = testBtn.querySelector('.btn-text');
            const btnLoading = testBtn.querySelector('.btn-loading');
            btnText.classList.remove('hidden');
            btnLoading.classList.add('hidden');
        }
    }

    // Show notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            font-weight: 600;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }

    // Initialize with example
    function initializeDemo() {
        subjectLineInput.value = "Don't miss our exclusive weekend sale!";
        updateCharacterCount();
    }

    // Initialize the demo
    initializeDemo();
});
// Add CSS for tools links
const toolsStyles = document.createElement('style');
toolsStyles.textContent = `
    .tools-links-container {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 2px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    
    .tools-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    
    .tools-header h3 {
        color: #1e293b;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: 700;
    }
    
    .tools-header p {
        color: #64748b;
        font-size: 0.9rem;
    }
    
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .tool-link {
        background: white;
        border: 2px solid #f1f5f9;
        border-radius: 12px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        text-decoration: none;
        transition: all 0.3s ease;
        color: inherit;
    }
    
    .tool-link:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
        text-decoration: none;
        color: inherit;
    }
    
    .tool-icon {
        font-size: 2rem;
        flex-shrink: 0;
    }
    
    .tool-content h4 {
        color: #1e293b;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        font-weight: 600;
    }
    
    .tool-content p {
        color: #64748b;
        font-size: 0.8rem;
        margin: 0;
        line-height: 1.4;
    }
`;
document.head.appendChild(toolsStyles);